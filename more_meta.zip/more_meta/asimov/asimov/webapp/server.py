# -*- coding: utf-8 -*-
"""
Defines the ASIMOV Tornado server
"""
import os
import tornado
from mongoengine import connect
from tornado import httpserver
#from tornado.options import options
from sockjs.tornado import SockJSRouter


#importing handler classes
from asimov.webapp.app.handlers.main import MainHandler
from asimov.webapp.app.handlers.user import UserHandler
from asimov.webapp.app.handlers.project import ProjectHandler
from asimov.webapp.app.handlers.model import ModelHandler
from asimov.webapp.app.handlers.dag import DagHandler
from asimov.webapp.app.handlers.pipeline import PipelineHandler
from asimov.webapp.app.handlers.search import SearchHandler
from asimov.webapp.app.handlers.socket import Socket
from asimov.webapp import settings  # unused but initializes global variables
from asimov.webapp.option_parser import options


def main():
    '''
    Configures and runs the Tornado server
    '''
    options.parse_command_line()
    SocketRouter = SockJSRouter(Socket, '/ws')

    app = tornado.web.Application(handlers= SocketRouter.urls + [
      (r'/', MainHandler),
      (r'/user/.*', UserHandler),
      (r'/project/.*', ProjectHandler),
      (r'/model/.*', ModelHandler),
      (r'/dag/.*', DagHandler),
      (r'/search', SearchHandler),
      (r'/ws', Socket),
      (r'/public/(.*)', tornado.web.StaticFileHandler, {'path': options.public_path}),
      (r'/api/(\d\.\d)/pipeline/(.*)/(.*)', PipelineHandler)],
      template_path=os.path.join(os.path.dirname(__file__), "app/templates"),
      static_path= options.static_path,
      autoreload=True,
      debug=True,
      )

    server = httpserver.HTTPServer(app, xheaders=True)
    server.bind(options.port)
    server.start()

    io_loop = tornado.ioloop.IOLoop.instance()
    connect(options.mongodb_name, host=options.mongodb_host, port=options.mongodb_port)
    print ('Server running on http://localhost:{:}'.format(options.port))
    io_loop.start()


if __name__ == '__main__':
    main()
