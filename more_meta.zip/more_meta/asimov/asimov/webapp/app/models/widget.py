from motorengine.document import Document
from motorengine.fields import StringField, DateTimeField, EmailField, ListField, JsonField


class Widgets(Document):
    name = StringField(required=True)
    widget_id = StringField(required=True)
    group = StringField(required=True)
    description = StringField()
    image = StringField(required=True)
    status = StringField(required=True)
    parameters = ListField(JsonField(required=True))
    attributes = ListField(JsonField())
    sink_ports = ListField(JsonField())
    source_ports = ListField(JsonField())

def create(params):

    return 	Widgets.objects.create(
                name = params['name'],
                widget_id = params['widget_id'],
                group = params['group'],
                description = params['description'],
                image = params['image'],
                status = params['status'],
                parameters = params['parameters'],
                attributes = params['attributes'],
                sink_ports = params['sink_ports'],
                source_ports = params['source_ports']
            )

def list():
    return Widgets.objects.find_all()


