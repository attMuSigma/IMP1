from mongoengine import Document
from mongoengine import *
from mongoengine.fields import StringField
from mongoengine.fields import ReferenceField
from mongoengine.fields import DateTimeField
from mongoengine.fields import ListField
from mongoengine.fields import ObjectId
import datetime

class User(Document):
    """
    Returns a User document
    """
    username = StringField(required=True, unique=True)
    password = StringField(required=True)
    role = StringField(required=True)
    created_on = DateTimeField(default=datetime.datetime.now())
    projects = ListField(ReferenceField('Project'))

def authenticate(**kwargs):
    user_doc =  User.objects(username=kwargs['username'],password=kwargs['password']).exclude('password').get() #get picks a single user object from an array
    return user_doc

def add_doc(**kwargs):
    user_doc =  User(username=kwargs['username'], password=kwargs['password'], role=kwargs['role'], projects=kwargs['projects']).save()
    return user_doc

def find(**kwargs):
    user_docs =  User.objects(**kwargs).no_dereference().exclude('password')
    return user_docs

def get_doc_by_id(user_id):
    user_doc =  User.objects.no_dereference().exclude('password').get(id=ObjectId(user_id))
    return user_doc

def get_all_docs():
    user_docs = User.objects().no_dereference().exclude('password')
    return user_docs

def get_all_names():
    user_docs =  User.objects.no_dereference().only('username')
    return user_docs

def add_project_id_to_list(username,project_id):
	User.objects(username=username).update(add_to_set__projects=project_id)

def search(**kwargs):
    return User.objects(Q(username__icontains=kwargs['keyword']) | Q(role__icontains=kwargs['keyword'])).exclude('password')

