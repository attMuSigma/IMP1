from mongoengine import Document
from mongoengine.fields import ReferenceField
from mongoengine.fields import DictField
from mongoengine.fields import ObjectId
from mongoengine import CASCADE
import datetime
import json
from asimov.webapp.app.models.project import Project
from asimov.webapp.app.models.model import Model

class Dag(Document):
    model = ReferenceField(Model, reverse_delete_rule=CASCADE) #Delete dag when model is deleted
    widgets = DictField()
    conn_list = DictField()
    element_list = DictField()
    conn_map = DictField()

def add(**kwargs):
    dag_doc =  Dag(widgets={}, conn_list = {}, element_list = {}, conn_map = {}).save()
    return dag_doc

def find(**kwargs):
    dag_docs = Dag.objects(**kwargs)
    return dag_docs

def get_doc_by_model_id(model_id):
    dag_doc = Dag.objects(model=ObjectId(model_id)).get()
    return dag_doc

def update(**kwargs):
    dag_doc  = Dag.objects(id=ObjectId(kwargs['_id'])).get()
    update_status = dag_doc.update(
        widgets = kwargs['widgets'],
        conn_list = kwargs['conn_list'],
        element_list = kwargs['element_list'],
        conn_map = kwargs['conn_map']
    )

    return update_ref_doc({'status' : update_status}, str(dag_doc['model']['id']))

def delete(**kwargs):
    delete_status = Dag.objects.delete(id=ObjectId(kwargs['_id']))
    return delete_status

def get_doc_by_id(**kwargs):
    dag_doc = Dag.objects.get(id=ObjectId(kwargs['_id']))
    return dag_doc

def update_ref_doc(result, model_id):
    if result['status']:
        model_doc = Model.objects(id=model_id).get()
        model_doc.update(last_modified=datetime.datetime.now())
        Project.objects(id=model_doc.project.id).update(last_modified=datetime.datetime.now())
    #last_modified is not required as the dashboard refreshes data from database on page load
    return result

def flush(**kwargs):
    dag_doc = Dag.objects.get(id=ObjectId(kwargs['_id']))
    dag_doc.widgets = dag_doc.conn_list = dag_doc.conn_map = dag_doc.element_list = {}
    dag_doc.save()
    return dag_doc