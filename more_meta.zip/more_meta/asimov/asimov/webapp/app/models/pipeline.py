# -*- coding: utf-8 -*-
"""
Provides the Pipeline ODM
"""
import pickle
import io
import sys
from mongoengine import CASCADE
from mongoengine import PULL
from mongoengine import Document
from mongoengine.fields import StringField
from mongoengine.fields import BinaryField
from mongoengine.fields import ReferenceField
from mongoengine.fields import ListField
from mongoengine.fields import ObjectId
from mongoengine.fields import BooleanField
from asimov.webapp.app.models.model import Model
from asimov.webapp.app.models.dag import Dag  # unused but registers document


class PipelineException(Exception):
    pass


class NoDocuments(PipelineException):
    pass


class MultipleDocuments(PipelineException):
    pass


class Pipeline(Document):
    name = StringField(required=True)
    backend = StringField(required=True)
    model = ReferenceField(Model, reverse_delete_rule=CASCADE, required=True)
    binary = BinaryField(required=True)
    signature = ListField(required=True)
    domain = StringField(required=True)
    published = BooleanField(default=False)
    classes = ListField()


Pipeline.register_delete_rule(Model, 'pipelines', PULL)


def delete_pipeline_by_id(pipeline_id):
    '''
    Deletes the pipeline from the database
    '''
    Pipeline.objects(id=ObjectId(pipeline_id)).delete()


def delete_pipeline_by_name(pipeline_name, model_id):
    '''
    Deletes the pipeline from the database
    '''
    model_doc = _get_doc_by_id(Model, model_id)
    Pipeline.objects(name=pipeline_name, model=model_doc).delete()


def delete_model_pipelines(model_id):
    '''
    Deletes all pipelines under a given model
    '''
    model_doc = _get_doc_by_id(Model, model_id)
    Pipeline.objects(model=model_doc).delete()


def document_exists(doc_class, doc_id):
    '''
    Returns True if the document exists, else False
    '''
    return True if doc_class.objects(id=ObjectId(doc_id)) else False


def get_pipeline_docs_by_model(model_id, include_binary=False):
    '''
    Returns a list of pipeline documents which belong to the specified model ID
    '''
    model_doc = _get_doc_by_id(Model, model_id)
    if include_binary:
        query = Pipeline.objects(model=model_doc)
    else:
        query = Pipeline.objects(model=model_doc).exclude('binary')
    return list(query)

def get_pipeline_by_id(pipeline_id):
    '''
    Returns an asimov.sklearn_backend.widgets.data_types.Pipeline object
    '''
    pipeline_doc = _get_doc_by_id(Pipeline, pipeline_id)
    return _bytes_to_pipeline(pipeline_doc.binary)


def get_pipeline_by_name(pipeline_name, model_id):
    '''
    Returns an asimov.sklearn_backend.widgets.data_types.Pipeline object
    '''
    pipeline_doc = get_pipeline_doc_by_name(pipeline_name, model_id)
    return _bytes_to_pipeline(pipeline_doc.binary)


def get_pipeline_doc_by_name(pipeline_name, model_id, include_binary=True):
    '''
    Returns a Pipeline by its name and model ID
    '''
    model_doc = _get_doc_by_id(Model, model_id)
    if include_binary:
        query = Pipeline.objects(name=pipeline_name, model=model_doc)
    else:
        query = Pipeline.objects(name=pipeline_name, model=model_doc).exclude('binary')
    return _one_from_query(query)


def update_pipeline_doc(pipeline, model_id):
    '''
    Creates a new pipeline or updates an exisitng one
    '''
    model_doc = _get_doc_by_id(Model, model_id)
    try:
        pipeline_doc = get_pipeline_doc_by_name(pipeline.name, model_id)
        _build_pipeline_doc(pipeline, pipeline_doc, model_doc)
    except NoDocuments:
        pipeline_doc = Pipeline()
        _build_pipeline_doc(pipeline, pipeline_doc, model_doc)
        model_doc.update(add_to_set__pipelines=pipeline_doc)
    return pipeline_doc


def _build_pipeline_doc(pipeline, pipeline_doc, model_doc):
    '''
    Builds a pipeline document from a pipeline and saves
    '''
    pipeline_doc.signature = [(feature, str(dtype)) for feature, dtype in pipeline.signature.iteritems()]
    pipeline_doc.name = pipeline.name
    pipeline_doc.binary = _pipeline_to_bytes(pipeline)
    pipeline_doc.backend = 'sklearn'
    pipeline_doc.domain = str(pipeline.domain)
    pipeline_doc.model = model_doc
    if pipeline.classes is not None: 
        pipeline_doc.classes = [str(entry) for entry in pipeline.classes]
    try:
        pipeline_doc.save()
    except Exception as e:
        raise PipelineException(e).with_traceback(sys.exc_info()[2])


def _get_doc_by_id(doc_class, doc_id):
    '''
    Returns the specified document
    '''
    return _one_from_query(doc_class.objects(id=ObjectId(doc_id)))


def _one_from_query(query):
    '''
    Returns a document from a query or raises PipelineException on error
    '''
    if not query:
        raise NoDocuments('Query resulted in no documents')
    elif query.count() > 1:
        raise MultipleDocuments('Query resulted in more than one document')
    return query[0]
    

def _pipeline_to_bytes(pipeline):
    '''
    Pickles and byte-encodes a Python object
    '''
    buffer = io.BytesIO()
    pickle.dump(pipeline, buffer)
    return buffer.getvalue()


def _bytes_to_pipeline(byte_data):
    '''
    Unpickles a byte-encoded Python object
    '''
    read_buffer = io.BytesIO(byte_data)
    return pickle.load(read_buffer)
