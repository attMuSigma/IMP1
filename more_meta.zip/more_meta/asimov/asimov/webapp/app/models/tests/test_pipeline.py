# -*- coding: utf-8 -*-
"""
Tests the Pipeline ODM
"""
import unittest
import pandas as pd
from mongoengine import connect
from sklearn.linear_model import LogisticRegression
from sklearn.datasets import load_iris
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.utils.testing import assert_array_almost_equal
from asimov.sklearn_backend.widgets import data_types as adt
from asimov.webapp.app.models import pipeline as pl
from asimov.webapp.app.utils.mock_documents import mocked_docs


class BasicTest(unittest.TestCase):

    def setUp(self):
        connect("example-db", host="localhost", port=27017)
        
    def test_save_load(self):
        '''
        Saves a pipeline to the database and reloads it
        '''
        with mocked_docs(create_pipeline=False, store_pipeline=False) as docs:
            model_doc = docs.model_doc

            # train the pipeline and predict
            iris = load_iris()
            X, y = iris.data, iris.target
            pipeline_sk = Pipeline([('scaler', StandardScaler()), ('logistic', LogisticRegression())])
            pipeline_sk.fit(X, y)
            pred, pred_proba = pipeline_sk.predict(X), pipeline_sk.predict_proba(X)
    
            # save the pipeline
            signature = pd.DataFrame(X, columns=list(iris.feature_names)).dtypes
            pipeline_adt = adt.Pipeline('logistic', pipeline_sk, adt.Domain.CLASSIFICATION, signature)
            pl.update_pipeline_doc(pipeline_adt, model_doc.id)

            # verify pipeline document content
            pipeline_doc = pl.get_pipeline_docs_by_model(model_doc.id)[0]
            self.assertEqual(pipeline_doc.signature, [['sepal length (cm)', 'float64'], ['sepal width (cm)', 'float64'], ['petal length (cm)', 'float64'], ['petal width (cm)', 'float64']])

            # load the pipeline and predict
            pipeline_adt_loaded = pl.get_pipeline_by_name('logistic', model_doc.id)
            pipeline_sk_loaded = pipeline_adt_loaded.estimator
            pred_loaded, pred_proba_loaded = pipeline_sk_loaded.predict(X), pipeline_sk_loaded.predict_proba(X)
            
            # results better match
            self.assertTrue((pred == pred_loaded).all())
            assert_array_almost_equal(pred_proba, pred_proba_loaded)
            
            # deleting the parent model should delete the pipeline
            model_doc.delete()
            with self.assertRaises(pl.NoDocuments):
                pl.get_pipeline_by_name('logistic', model_doc.id)


    def test_pipeline_pull(self):
        '''
        Tests that the pipeline is pulled from the model upon deletion
        '''
        with mocked_docs(create_pipeline=False, store_pipeline=False) as docs:
            model_doc = docs.model_doc
            
            # train the pipeline and predict
            iris = load_iris()
            X, y = iris.data, iris.target
            pipeline_sk = Pipeline([('scaler', StandardScaler()), ('logistic', LogisticRegression())])
            pipeline_sk.fit(X, y)
    
            # save the pipeline
            signature = pd.DataFrame(X, columns=list(iris.feature_names)).dtypes
            pipeline_adt = adt.Pipeline('logistic', pipeline_sk, adt.Domain.CLASSIFICATION, signature)
            pl.update_pipeline_doc(pipeline_adt, model_doc.id)
            model_doc.reload()
            self.assertEqual(len(model_doc.pipelines), 1)  # pipeline reference added
    
            # deleting the pipeline should pull the reference from the parent list
            pl.delete_pipeline_by_name('logistic', model_doc.id)
            model_doc.reload()
            self.assertEqual(len(model_doc.pipelines), 0)  # pipeline reference removed


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
