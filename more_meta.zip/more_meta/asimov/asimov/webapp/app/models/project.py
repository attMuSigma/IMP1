from mongoengine import NULLIFY
from mongoengine import PULL
from mongoengine import Document
from mongoengine import *
from mongoengine.fields import StringField
from mongoengine.fields import BinaryField
from mongoengine.fields import ReferenceField
from mongoengine.fields import DateTimeField
from mongoengine.fields import ListField
from mongoengine.fields import ObjectId
from asimov.webapp.app.models.user import User
import datetime
import re

class Project(Document):
    name = StringField(required=True)
    description = StringField()
    user = ReferenceField(User, required=True, reverse_delete_rule=NULLIFY) 
    created_on = DateTimeField(default=datetime.datetime.now())
    last_modified = DateTimeField(default=datetime.datetime.now())
    tags = ListField()
    models = ListField(ReferenceField('Model'))
    #reference field documents which haven't created yet doesn't support rever_delete_rule directly


# when a project is deleted, PULL form the user document
Project.register_delete_rule(User, 'projects', PULL)

# creates a new project with data given and adds to user list
def add(**kwargs):
    project_doc = Project(name = kwargs['name'], description = kwargs['description'], user = kwargs['user'], models = kwargs['models'], tags = kwargs['tags'], created_on = datetime.datetime.now(), last_modified = datetime.datetime.now()).save()
    User.objects(id=ObjectId(kwargs['user'])).update(add_to_set__projects=ObjectId(project_doc.id))
    return project_doc

def add_replace(**kwargs):
    return Project(id=ObjectId(kwargs['_id']),
                name = kwargs['name'], 
                description = kwargs['description'], 
                user = kwargs['user'], 
                models =  kwargs['models'], 
                tags = kwargs['tags'], 
                created_on = datetime.datetime.now(), 
                last_modified = datetime.datetime.now()).save()

# returns documents with any parameter except user_id
def find(**kwargs):
    project_docs = Project.objects(**kwargs)
    return project_docs

# returns documents by user_id
def find_by_user_id(**kwargs):
    project_doc = Project.objects(user=ObjectId(kwargs['user_id'])).order_by('-last_modified').select_related(max_depth=1)
    return project_doc

# return documents by project id
def find_by_id(**kwargs):
    project_doc = Project.objects.get(id=ObjectId(kwargs['project_id']))
    return project_doc

# updates the project information and returns modification time and status
def update(**kwargs):
    update_status =  Project.objects(id=ObjectId(kwargs['project']['_id'])).update(
        name=kwargs['project']['name'],
        description=kwargs['project']['description'],
        last_modified=datetime.datetime.now(),
        tags=kwargs['project']['tags'])
    result = {'last_modified' : datetime.datetime.now(), 'status' : update_status}
    return result

# deletes the project and models associated with the project
def delete(**kwargs):
    delete_status =  Project.objects(id=ObjectId(kwargs['_id'])).delete()
    return delete_status

def search(**kwargs):
    return Project.objects(
        Q(name__icontains=kwargs['keyword']) | 
        Q(description__icontains=kwargs['keyword']) | 
        Q(__raw__={'tags' : {'$in' : [re.compile('.*'+kwargs['keyword']+'.*', re.IGNORECASE)]}}))

   