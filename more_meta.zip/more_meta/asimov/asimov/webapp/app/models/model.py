from mongoengine import CASCADE
from mongoengine import PULL
from mongoengine import Document
from mongoengine import *
from mongoengine.fields import StringField
from mongoengine.fields import ReferenceField
from mongoengine.fields import DateTimeField
from mongoengine.fields import DictField
from mongoengine.fields import ListField
from mongoengine.fields import ObjectId
from asimov.webapp.app.models.project import Project
import datetime
import re


class Model(Document):
    name = StringField(required=True)
    username = StringField(required=True)
    description = StringField()
    project = ReferenceField(Project, required=True, reverse_delete_rule=CASCADE) #Delete Model when Project is deleted
    tags = ListField()
    dag = ReferenceField('Dag')
    status = StringField(required=True)
    created_on = DateTimeField(default=datetime.datetime.now())
    last_modified = DateTimeField(default=datetime.datetime.now())
    pipelines = ListField(ReferenceField('Pipeline'))


#When model is deleted, PULL from the referenced project document
Model.register_delete_rule(Project, 'models', PULL)

def add(dag_id, **kwargs):
    model_doc = Model(
                name=kwargs['name'],
                username=kwargs['username'],
                description=kwargs['description'],
                project=kwargs['project'],
                dag=ObjectId(dag_id),
                tags=kwargs['tags'],
                status=kwargs['status'],
                created_on=datetime.datetime.now(),
                last_modified=datetime.datetime.now(),
                pipelines = []
            ).save()
    Project.objects(id=ObjectId(kwargs['project'])).update(add_to_set__models=ObjectId(model_doc.id), last_modified=datetime.datetime.now())
    return model_doc

def find(**kwargs):
    model_docs =  Model.objects(**kwargs).no_dereference()
    return model_docs

def find_model_doc_by_id(**kwargs):
    model_doc = Model.objects.get(id=ObjectId(kwargs['model_id']))
    return model_doc

def find_model_docs_by_project_id(**kwargs):
    model_docs = Model.objects(project=ObjectId(kwargs['project_id']))

def update(**kwargs):
    update_status = Model.objects(id=ObjectId(kwargs['model']['_id'])).update(
        name=kwargs['model']['name'],
        description=kwargs['model']['description'],
        tags=kwargs['model']['tags'],
        last_modified=datetime.datetime.now())

    return update_ref_doc({'status' : update_status}, ObjectId(kwargs['model']['project']))

def delete(**kwargs):
    result = { 'status' : Model.objects(id=ObjectId(kwargs['_id'])).delete()}
    return update_ref_doc(result, kwargs['project'])

def delete_by_project(project_id):
    return Model.objects(project=ObjectId(project_id)).delete()

def update_ref_doc(result, project_id):
    if result['status']:
        Project.objects(id=project_id).update(last_modified=datetime.datetime.now())
        result['last_modified'] = datetime.datetime.now()
    return result

def search(**kwargs):
    return Model.objects(
            Q(name__icontains=kwargs['keyword']) | 
            Q(description__icontains=kwargs['keyword']) | 
            Q(username__icontains=kwargs['keyword']) | 
            Q(status__icontains=kwargs['keyword']) | 
            Q(__raw__={'tags' : {'$in' : [re.compile('.*'+kwargs['keyword']+'.*', re.IGNORECASE)]}}))
