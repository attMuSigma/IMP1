# -*- coding: utf-8 -*-
"""
Tests pipeline handler methods
"""
import unittest
import tempfile
import pandas as pd
import os
from sklearn.datasets import load_iris
from sklearn.utils.testing import assert_array_almost_equal
from asimov.webapp.app.utils.mock_documents import mocked_docs
from asimov.webapp.app.handlers.methods.pipeline import PredictMethod
from asimov.webapp.app.models import pipeline as pl


class BasicTest(unittest.TestCase):

    def setUp(self):
        self.data_dir = '/asimov/data'
        iris = load_iris()
        self.iris = iris
        self.X = iris.data
        self.y = iris.target_names[iris.target]
        self.input_pdf = pd.DataFrame(self.X, columns=list(iris.feature_names))
        self.input_file = None
        self.output_file = None

    def tearDown(self):
        try: os.remove(self.input_file)
        except: pass
        try:  os.remove(self.output_file)
        except: pass

    def test_predict_basic(self):
        '''
        Tests the prediction method
        '''
        with mocked_docs() as docs:
            
            # get some file paths
            with tempfile.NamedTemporaryFile(dir=self.data_dir, suffix='.csv') as input_file:
                with tempfile.NamedTemporaryFile(dir=self.data_dir, suffix='.csv') as output_file:
                    self.input_file = input_file.name
                    self.output_file = output_file.name
            # execute the method
            self.input_pdf.to_csv(input_file.name)
            pred_method = PredictMethod(input_filepath=input_file.name, output_filepath=output_file.name, pipeline_id=docs.pipeline_doc.id)
            pred_method.execute()
            # read pipeline used for predicting from database
            pipeline_adt = pl.get_pipeline_by_id(docs.pipeline_doc.id)
            pipeline_sk = pipeline_adt.estimator
            pred = pipeline_sk.predict(self.X)
            pred_proba = pipeline_sk.predict_proba(self.X)
            # verify prediction
            output_pdf = pd.read_csv(output_file.name)
            target_ps = output_pdf.ix[:, 0]
            self.assertEqual(target_ps.name, 'Target')
            self.assertTrue((pred == target_ps).all())
            # verify probabilities
            pred_proba_pdf = output_pdf.ix[:, 1:]
            self.assertEqual(list(pipeline_sk.classes_), list(pred_proba_pdf.columns))
            assert_array_almost_equal(pred_proba, pred_proba_pdf.as_matrix())


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
