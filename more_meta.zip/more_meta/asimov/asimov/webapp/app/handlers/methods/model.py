# -*- coding: utf-8 -*-
"""
Provides methods for model management
"""
import os
import sys
import mongoengine
from mongoengine.fields import ObjectId
from asimov.webapp.app.handlers.methods.base import BaseMethod
from asimov.webapp.app.handlers.methods.base import MissingArgs
import asimov.webapp.app.models.model as model
import asimov.webapp.app.models.dag as dag
import asimov.webapp.app.models.pipeline as pipeline
from asimov.webapp.app.handlers.methods.base import MethodException

class ModelMethod(BaseMethod):

    _required = tuple()
    _optional = {}
    _params = {}

    def _verify_args(self, **kwargs):
        self._params = kwargs #Temporary assignment before required params are set for all methods
        if 'project' in self._params:
            self._params['project'] = ObjectId(self._params['project'])

    def _verify_method_args(self, **kwargs):
        try:
            for req_param in self._required:
                self._params[req_param] = kwargs[req_param]
        except KeyError as e:
            raise MissingArgs("Required parameter {:} was not provided".format(e))
        finally:
            for opt_param in self._optional:
                self._params[opt_param] = getattr(kwargs, opt_param, self._optional[opt_param])

    @classmethod
    def parse_doc_to_obj(cls,doc):
        try:
            obj = doc.to_mongo().to_dict()
            obj['_id'] = str(obj['_id'])
            obj['created_on'] = obj['created_on'].strftime("%Y-%m-%d %H:%M:%S")
            obj['last_modified'] = obj['last_modified'].strftime("%Y-%m-%d %H:%M:%S")
            obj['dag'] = str(obj['dag'])
            obj['project'] = str(obj['project'])

        except Exception as e:
            print(e)
        else:
            return obj

    @classmethod
    def parse_pipeline_doc_to_obj(cls,doc):
        try:
            obj = doc.to_mongo().to_dict()
            obj['_id'] = str(doc['id'])
            obj['model'] =str(doc['model']['id'])

        except Exception as e:
            print(e)
        else:
            return obj

    def find(self, **kwargs):
        '''

        :param kwargs:
        :return: list of dict
        '''

        self._required = tuple()
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            model_docs = model.find(**self._params)
            result = [self.parse_doc_to_obj(model_doc) for model_doc in model_docs]
        except Exception as e:
            raise MethodException("Error while fetching models {:}".format(e))
        else:
            return result

    def find_by_project_id(self, **kwargs):
        '''

        :param kwargs:
        :return: list of dict
        '''

        self._required = tuple()
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            model_docs = model.find_model_docs_by_project_id(**self._params)
            result = [self.parse_doc_to_obj(model_doc) for model_doc in model_docs]
        except Exception as e:
            raise MethodException("Error while fetching models {:}".format(e))
        else:
            return result

    def get_pipelines_by_model_id(self, **kwargs):

        self._required = ('model_id',)
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            pipeline_docs = pipeline.get_pipeline_docs_by_model(self._params['model_id'])
            result = [self.parse_pipeline_doc_to_obj(pipeline_doc) for pipeline_doc in pipeline_docs]
        except Exception as e:
            raise MethodException("Error while fetching pipeline {:}".format(e))
        else:
            return result

    def update(self, **kwargs):
        '''
        :param kwargs:
        :return: {'status' : Bool ,'last_modified' : '%Y-%m-%d %H:%M:%S'}
        '''

        self._required = ('model',)
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            result = model.update(**self._params)
            result['last_modified'] = result['last_modified'].strftime("%Y-%m-%d %H:%M:%S")
        except Exception as e:
            raise MethodException("Error while updating model {:}".format(e))
        else:
            return result



    def delete(self, **kwargs):
        '''

        :param kwargs:
        :return: Bool
        '''

        self._required = ('_id','project',)
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            result = model.delete(**self._params)
            result['last_modified'] = result['last_modified'].strftime("%Y-%m-%d %H:%M:%S")
        except Exception as e:
            raise MethodException("Error while deleting model {:}".format(e))
        else:
            return result

    def search(self, **kwargs):
        '''

        :param kwargs:
        :return: list of dict
        '''

        self._required = tuple()
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            result = model.search(**self._params)
        except Exception as e:
            raise MethodException("Error while fetching models {:}".format(e))
        else:
            return result