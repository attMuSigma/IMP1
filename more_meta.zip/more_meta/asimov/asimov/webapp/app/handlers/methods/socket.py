# -*- coding: utf-8 -*-
"""
Provides methods for project management
"""
import asimov.webapp.app.models.model as model
import asimov.webapp.app.models.dag as dag
from asimov.webapp.backend_import import async, logic
from asimov.webapp.app.handlers.methods.base import BaseMethod
from asimov.webapp.app.handlers.methods.base import MethodException
from asimov.webapp.app.handlers.methods.base import MissingArgs
from asimov.webapp.app.handlers.methods.model import ModelMethod
from asimov.webapp.app.handlers.methods.dag import DagMethod

class SocketMethod(BaseMethod):
    _socket = None
    _required = tuple()
    _optional = {}
    _params = {}

    def _verify_args(self, **kwargs):
        self._params = kwargs #Temporary assignment before all required params are set
        self._socket = self._params.pop('socket')

    def _verify_method_args(self, **kwargs):
        try:
            for req_param in self._required:
                self._params[req_param] = kwargs[req_param]
        except KeyError as e:
            raise MissingArgs("Required parameter {:} was not provided".format(e))
        finally:
            for opt_param in self._optional:
                self._params[opt_param] = getattr(kwargs, opt_param, self._optional[opt_param])

    def begin_session(self, **kwargs):
        try:
            yield logic.async_method('begin_session', project_id=kwargs['project_id'], model_id=kwargs['model_id'])
            #logic.begin_session(kwargs['project_id'],kwargs['model_id'])
        except Exception as e:
            print("BEGIN SESSION EXCEPTION : ", e)
            raise MethodException("Error while starting session - {:}".format(e))
        else:
            socket_key = (kwargs['project_id'],kwargs['model_id'])
            async.add_socket(socket_key, self._socket)


    @classmethod
    def end_session(cls, **kwargs):
        try:
            yield logic.async_method('end_session', project_id=kwargs['project_id'], model_id=kwargs['model_id'])
            #logic.end_session(kwargs['project_id'],kwargs['model_id'])
        except Exception as e:
            print("SESSION END EXCEPTION : " , e)
            raise MethodException("Error while ending session - {:}".format(e))
        finally:
            socket_key = (kwargs['project_id'],kwargs['model_id'])
            async.remove_socket(socket_key)

    def parse_doc_to_obj(cls,doc):
        try:
            obj = doc.to_mongo().to_dict()
            obj['_id'] = str(doc['id'])
            obj['project'] = str(obj['project'])
            obj['dag'] = str(obj['dag'])
            obj['created_on'] = doc['created_on'].strftime("%Y-%m-%d %H:%M:%S")
            obj['last_modified'] = doc['last_modified'].strftime("%Y-%m-%d %H:%M:%S")

        except Exception as e:
            print(e)
        else:
            return obj

    def add_model(self, **kwargs):
        self._required = ('name',)
        self._optional = {}
        self._verify_method_args(**kwargs)
        try:
            dag_doc =  dag.add() #Handle dag exception separately
            model_doc = model.add(dag_doc.id, **self._params)
            dag_doc.model = model_doc
            dag_doc.save()
            model_obj = ModelMethod.parse_doc_to_obj(model_doc)
            result = model_obj
        except Exception as e:
            raise MethodException("Error while creating model - {:}".format(e))
        else:
            yield from self.begin_session(project_id=model_obj['project'], model_id=model_obj['_id'])
            return result

    def load_model(self, **kwargs):
        self._required = ()
        self._optional = {}
        self._verify_method_args(**kwargs)

        try:
            socket_key = (kwargs['project_id'],kwargs['model_id'])
            async.add_socket(socket_key, self._socket)
            dag_doc = dag.get_doc_by_model_id(kwargs['model_id'])
            dag_obj = DagMethod.parse_doc_to_obj(dag_doc)
            print('project_id : ', kwargs['project_id'], ', model_id : ', kwargs['model_id'])
            session_model = {'project_id' : kwargs['project_id'], 'model_id' : kwargs['model_id'], 'widgets' : dag_obj['widgets']}
            yield logic.async_method('load_session', session_model=session_model)
            #logic.load_session(session_model)
        except Exception as e:
            raise MethodException("Error while loading model - {:}".format(e))

    def interrupt(self, **kwargs):
        try:
            yield logic.async_method('interrupt_session', project_id=kwargs['project_id'], model_id=kwargs['model_id'])
            #logic.end_session(kwargs['project_id'],kwargs['model_id'])
        except Exception as e:
            print("INTERRUPT SESSION EXCEPTION : " , e)
            raise MethodException("Error while interrupting session - {:}".format(e))

    def add_widget(self, **kwargs):
        self._required = ()
        self._optional = {}
        self._verify_method_args(**kwargs)
        try:
            result = yield logic.async_method('create_widget', project_id=kwargs['project_id'], model_id=kwargs['model_id'],
                                              widget_id=kwargs['widget_id'], widget_uid=kwargs['widget_uid'])
            #result = logic.create_widget(kwargs['project_id'], kwargs['model_id'], kwargs['widget_id'], kwargs['widget_uid'])
        except Exception as e:
            print("ADD WIDGET EXCEPTION : ", e)
            raise MethodException("Error while adding widget - {:}".format(e))
        else:
            return result

    def delete_widget(self, **kwargs):
        self._required = ()
        self._optional = {}
        self._verify_method_args(**kwargs)
        try:
            yield logic.async_method('delete_widget', project_id=kwargs['project_id'], model_id=kwargs['model_id'],
                                     widget_uid=kwargs['widget_uid'])
            #logic.delete_widget(kwargs['project_id'], kwargs['model_id'], kwargs['widget_uid'])
        except Exception as e:
            print("WIDGET DELETE EXCEPTION : ", e)
            raise MethodException("Error while deleting widget - {:}".format(e))

    def apply_parameters(self, **kwargs):
        self._required = ()
        self._optional = {}
        self._verify_method_args(**kwargs)
        try:
            result = yield logic.async_method('apply_parameters', project_id=kwargs['project_id'], model_id=kwargs['model_id'],
                                              widget_uid=kwargs['widget_uid'], parameters=kwargs['parameters'])
            #result = logic.apply_parameters(kwargs['project_id'], kwargs['model_id'], kwargs['widget_uid'], kwargs['parameters'])
        except Exception as e:
            print("WIDGET EVALUATE EXCEPTION : ", e)
            raise MethodException("Error while applying parameters - {:}".format(e))
        else:
            return result

    def create_connection(self, **kwargs):
        self._required = ()
        self._optional = {}
        self._verify_method_args(**kwargs)
        try:
            result = yield logic.async_method('create_connection', project_id=kwargs['project_id'], model_id=kwargs['model_id'],
                                              connection=kwargs['connection'])
            #result= logic.create_connection(kwargs['project_id'], kwargs['model_id'], kwargs['connection'])
        except Exception as e:
            print("WIDGET EVALUATE EXCEPTION : ", e)
            raise MethodException("Error while creating connection - {:}".format(e))
        else:
            return result

    def delete_connection(self, **kwargs):
        self._required = ()
        self._optional = {}
        self._verify_method_args(**kwargs)
        try:
            result = yield logic.async_method('delete_connection', project_id=kwargs['project_id'], model_id=kwargs['model_id'],
                                              connection=kwargs['connection'])
            #result= logic.delete_connection(kwargs['project_id'], kwargs['model_id'], kwargs['connection'])
        except Exception as e:
            print("WIDGET EVALUATE EXCEPTION : ", e)
            raise MethodException("Error while deleting connection - {:}".format(e))
        else:
            return result

