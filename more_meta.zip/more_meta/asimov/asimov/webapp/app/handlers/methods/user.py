# -*- coding: utf-8 -*-
"""
Provides methods for user management
"""
import os
import sys
import mongoengine
from asimov.webapp.app.handlers.methods.base import BaseMethod
from asimov.webapp.app.handlers.methods.base import MissingArgs
import asimov.webapp.app.models.user as user
from asimov.webapp.app.handlers.methods.base import MethodException

class UserMethod(BaseMethod):

    _required = tuple()
    _optional = {}
    _params = {}

    def _verify_args(self, **kwargs):
        self._params = kwargs #Temporary assignment before required params are set for all methods

    def _verify_method_args(self, **kwargs):
        try:
            for req_param in self._required:
                self._params[req_param] = kwargs[req_param]
        except KeyError as e:
            raise MissingArgs("Required parameter {:} was not provided".format(e))
        finally:
            for opt_param in self._optional:
                self._params[opt_param] = getattr(kwargs, opt_param, self._optional[opt_param])

    @classmethod
    def parse_doc_to_obj(cls,doc):
        try:
            obj = doc.to_mongo().to_dict()
            obj['_id'] = str(doc['id'])
            obj['created_on'] = doc['created_on'].strftime("%Y-%m-%d %H:%M:%S")
        except Exception as e:
            raise MethodException("Invalid document {:}".format(e))
        else:
            return obj


    def login(self, **kwargs):
        self._required = ('username', 'password')
        self._optional = {}
        self._verify_method_args(**kwargs)
        try:
            user_doc =  user.authenticate(**self._params)
            result = self.parse_doc_to_obj(user_doc)
        except Exception as e:
            raise MethodException("Incorrect credentials") #How to pass messages better to account for no record
        else:
            return result


    def register(self, **kwargs):
        self._required = ('username', 'password')
        self._optional = {'role' : 'user', 'projects' : []}
        self._verify_method_args(**kwargs)
        try:
            user_doc = user.add_doc(**self._params).save()
            result = self.parse_doc_to_obj(user_doc)
        except mongoengine.errors.NotUniqueError:
            raise MethodException("User already exists")
        else:
            return result

    def find(self, **kwargs):
        self._required = tuple()
        self._optional = {}
        self._verify_method_args(**kwargs)
        try:
            user_docs = user.find(**self._params)
            result = [self.parse_doc_to_obj(user_doc) for user_doc in user_docs]
        except Exception as e:
            raise MethodException("Error while fetching users {:}".format(e))
        else:
            return result

    def search(self, **kwargs):
        self._required = tuple()
        self._optional = {}
        self._verify_method_args(**kwargs)
        try:
            result = user.search(**self._params)
        except Exception as e:
            raise MethodException("Error while fetching users {:}".format(e))
        else:
            return result