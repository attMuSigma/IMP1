# -*- coding: utf-8 -*-
"""
Provides methods for dag operations
"""
import os
import sys
import mongoengine
from mongoengine.fields import ObjectId
from asimov.webapp.app.handlers.methods.base import BaseMethod
from asimov.webapp.app.handlers.methods.base import MissingArgs
import asimov.webapp.app.models.dag as dag
from asimov.webapp.app.handlers.methods.base import MethodException

class DagMethod(BaseMethod):

    _required = tuple()
    _optional = {}
    _params = {}

    def _verify_args(self, **kwargs):
        self._params = kwargs
        if 'id' in self._params:
            self._params['id'] = ObjectId(self._params['id'])

    def _verify_method_args(self, **kwargs):
        try:
            for req_param in self._required:
                self._params[req_param] = kwargs[req_param]
        except KeyError as e:
            raise MissingArgs("Required parameter {:} was not provided".format(e))
        finally:
            for opt_param in self._optional:
                self._params[opt_param] = getattr(kwargs, opt_param, self._optional[opt_param])

    @classmethod
    def parse_doc_to_obj(cls,doc):
        try:
            obj = doc.to_mongo().to_dict()
            obj['_id'] = str(doc['id'])
            obj['model'] = str(doc['model']['id'])
        except Exception as e:
            print(e)
        else:
            return obj


    def add(self, **kwargs):
        '''

        :param kwargs:
        :return: dict
        '''

        self._required = ('name',)
        self._optional = {}

        self._verify_method_args(**kwargs)
        try:

            dag_doc = dag.add(**self._params)
            result = self.parse_doc_to_obj(dag_doc)
        except Exception as e:
            raise MethodException("Error while adding dag - {:}".format(e))
        else:
            return result


    def find(self, **kwargs):
        '''

        :param kwargs:
        :return: list of dict
        '''

        self._required = tuple()
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            project_docs = dag.find(**self._params)
            result = [self.parse_doc_to_obj(project_doc) for project_doc in project_docs]
        except Exception as e:
            raise MethodException("Error while fetching dag {:}".format(e))
        else:
            return result

    def get_by_id(self, **kwargs):
        self._required = tuple()
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            dag_doc = dag.get_doc_by_id(**self._params)
            result = self.parse_doc_to_obj(dag_doc)
        except Exception as e:
            raise MethodException("Error while fetching dag {:}".format(e))
        else:
            return result

    def save(self, **kwargs):
        '''
        :param kwargs:
        :return: {'status' : Bool ,'last_modified' : '%Y-%m-%d %H:%M:%S'}
        '''

        self._required = tuple()
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            result = dag.update(**self._params)
        except Exception as e:
            raise MethodException("Error while updating dag {:}".format(e))
        else:
            return result

    def delete(self, **kwargs):
        '''

        :param kwargs:
        :return: Bool
        '''

        self._required = ('dag_id',)
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            result = dag.delete(**self._params)
        except Exception as e:
            raise MethodException("Error while deleting dag {:}".format(e))
        else:
            return result

