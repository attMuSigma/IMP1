# -*- coding: utf-8 -*-
"""
Provides methods for project management
"""
import os
import sys
import mongoengine
from mongoengine.fields import ObjectId
from asimov.webapp.app.handlers.methods.base import BaseMethod
from asimov.webapp.app.handlers.methods.base import MissingArgs
import asimov.webapp.app.models.project as project
import asimov.webapp.app.models.model as model
from asimov.webapp.app.handlers.methods.base import MethodException

class ProjectMethod(BaseMethod):

    _required = tuple()
    _optional = {}
    _params = {}

    def _verify_args(self, **kwargs):
        self._params = kwargs #Temporary assignment before required params are set for all methods
        if 'user' in self._params:
            self._params['user'] = ObjectId(self._params['user'])

    def _verify_method_args(self, **kwargs):
        try:
            for req_param in self._required:
                self._params[req_param] = kwargs[req_param]
        except KeyError as e:
            raise MissingArgs("Required parameter {:} was not provided".format(e))
        finally:
            for opt_param in self._optional:
                self._params[opt_param] = getattr(kwargs, opt_param, self._optional[opt_param])

    @classmethod
    def parse_doc_to_obj(cls,doc):
        try:
            user = doc.user.to_mongo().to_dict()
            obj = doc.to_mongo().to_dict()
            obj['user'] = {}
            obj['user']['_id'] = str(user['_id'])
            obj['user']['username'] = user['username']
            obj['_id'] = str(obj['_id'])
            obj['created_on'] = obj['created_on'].strftime("%Y-%m-%d %H:%M:%S")
            obj['last_modified'] = obj['last_modified'].strftime("%Y-%m-%d %H:%M:%S")
        except Exception as e:
            print(e)
        else:
            return obj


    def add(self, **kwargs):
        '''

        :param kwargs:
        :return: dict
        '''

        self._required = ('name',)
        self._optional = {}

        self._verify_method_args(**kwargs)
        try:

            project_doc = project.add(**self._params)
            result = self.parse_doc_to_obj(project_doc)
        except Exception as e:
            raise MethodException("Error while adding projects - {:}".format(e))
        else:
            return result

    def add_replace(self, **kwargs):
        '''

        :param kwargs:
        :return: dict
        '''

        self._required = ('name',)
        self._optional = {}

        self._verify_method_args(**kwargs)
        try:
            delete_models = model.delete_by_project(self._params['_id'])
            project_doc = project.add_replace(**self._params)
            result = self.parse_doc_to_obj(project_doc)
        except Exception as e:
            raise MethodException("Error while adding projects - {:}".format(e))
        else:
            return result


    def find(self, **kwargs):
        '''

        :param kwargs:
        :return: list of dict
        '''

        self._required = tuple()
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            project_docs = project.find(**self._params)
            result = [self.parse_doc_to_obj(project_doc) for project_doc in project_docs]
        except Exception as e:
            raise MethodException("Error while fetching projects {:}".format(e))
        else:
            return result

    def find_by_user_id(self, **kwargs):
        '''

        :param kwargs:
        :return: list of dict
        '''

        self._required = ()
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            project_docs = project.find_by_user_id(**self._params)
            result = [self.parse_doc_to_obj(project_doc) for project_doc in project_docs]
        except Exception as e:
            raise MethodException("Error while fetching projects {:}".format(e))
        else:
            return result

    def update(self, **kwargs):
        '''

        :param kwargs:
        :return: {'status' : Bool ,'last_modified' : '%Y-%m-%d %H:%M:%S'}
        '''

        self._required = ('project',)
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            result = project.update(**self._params)
            result['last_modified'] = result['last_modified'].strftime("%Y-%m-%d %H:%M:%S")
        except Exception as e:
            raise MethodException("Error while updating project {:}".format(e))
        else:
            return result

    def delete(self, **kwargs):
        '''

        :param kwargs:
        :return: Bool
        '''

        self._required = ('_id',)
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            result = project.delete(**self._params)
        except Exception as e:
            raise MethodException("Error while deleting project {:}".format(e))
        else:
            return result

    def search(self, **kwargs):
        '''

        :param kwargs:
        :return: list of dict
        '''

        self._required = tuple()
        self._optional = {}

        self._verify_method_args(**kwargs)

        try:
            result = project.search(**self._params)
        except Exception as e:
            raise MethodException("Error while fetching projects {:}".format(e))
        else:
            return result