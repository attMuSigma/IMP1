# -*- coding: utf-8 -*-
"""
Provides a method for prediction with adt pipelines
"""
import os
import sys
import csv
import pandas as pd
import numpy as np
import asimov.webapp.app.models.pipeline as pl
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.webapp.app.handlers.methods.base import BaseMethod
from asimov.webapp.app.handlers.methods.base import MissingArgs
from asimov.webapp.app.handlers.methods.base import MethodException


class PredictMethod(BaseMethod):
    _required = ('input_filepath', 'output_filepath')
    _optional = tuple()
    _data_dir = '/asimov/data'
    
    def _verify_args(self, **kwargs):
        try:
            self.input_filepath = kwargs['input_filepath']
            self.output_filepath = kwargs['output_filepath']
            self.pipeline_id = kwargs['pipeline_id']
        except KeyError as e:
            raise MissingArgs("Required parameter {:} was not provided".format(e))

    def execute(self):
        '''
        Loads the input data and pipeline, predicts, and writes results to disk
        '''
        self._verify_paths()
        # read pipeline from database
        try:
            pipeline_adt = pl.get_pipeline_by_id(self.pipeline_id)
        except pl.PipelineException as e:
            raise MethodException(e).with_traceback(sys.exc_info()[2])
        # read input data
        sep = self._infer_delim(self.input_filepath)
        data_pdf = pd.read_csv(self.input_filepath, sep=sep)
        try:
            ordered_data_pdf = data_pdf[pipeline_adt.signature.index]
        except KeyError as e:
            raise MethodException("Input CSV was missing feature {:}".format(e))
        # predict
        data_nd = ordered_data_pdf.as_matrix()
        estimator = pipeline_adt.estimator
        if pipeline_adt.domain is adt.Domain.CLASSIFICATION:
            pred_pdf = self._predict_class(data_nd, estimator)
        else:
            pred_pdf = self._predict_reg(data_nd, estimator)
        # write results
        pred_pdf.to_csv(self.output_filepath, sep=sep, index=False)
        return dict()
    
    def _verify_paths(self):
        '''
        Raises if something is wrong with provided filepaths
        '''
        if not self.input_filepath.find(self._data_dir) == 0:
            raise MethodException("Input file must be in directory {:}".format(self._data_dir))
        if not self.output_filepath.find(self._data_dir) == 0:
            raise MethodException("Output file must be in directory {:}".format(self._data_dir))
        if not os.path.isfile(self.input_filepath):
            raise MethodException("Input file {:} does not exist".format(self.input_filepath))
        if os.path.isfile(self.output_filepath):
            raise MethodException("Output file {:} already exists; will not overwrite".format(self.output_filepath))

    def _infer_delim(self, filepath):
        '''
        Returns the inferred delimiter character
        '''
        try:
            with open(filepath, 'r') as file:
                return csv.Sniffer().sniff(next(file)).delimiter
        except Exception as e:
            raise MethodException("Could not infer CSV delimiter: {:}".format(e)).with_traceback(sys.exc_info()[2])

    def _predict_class(self, data_nd, estimator):
        '''
        Returns a prediction pdf for classification
        '''
        pred = estimator.predict(data_nd)
        pred = pred.reshape((pred.size, 1))
        pred_proba = estimator.predict_proba(data_nd)
        preds = np.hstack((pred, pred_proba))
        preds_pdf = pd.DataFrame(preds, columns=['Target'] + list(estimator.classes_))
        return preds_pdf
    
    def _predict_reg(self, data_nd, estimator):
        '''
        Returns a prediction pdf for regression
        '''
        pred = estimator.predict(data_nd)
        return pd.DataFrame(pred, columns=['Target'])


class PublishMethod(BaseMethod):
    _required = ('publish')
    _optional = tuple()
    
    def execute(self):
        pass
