# -*- coding: utf-8 -*-
"""
Provides a base handler
"""

import jsonpickle
import traceback
from tornado.web import HTTPError, RequestHandler
from tornado.log import logging

class BaseHandlerException(HTTPError):
    pass


class BaseHandler(RequestHandler):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.log = logging.getLogger()

    def write_error(self, status_code, **kwargs):
        self.set_header('Content-Type', 'text/json')
        if self.settings.get("serve_traceback") and "exc_info" in kwargs:
            lines = [line for line in traceback.format_exception(*kwargs["exc_info"])]
            self.finish({'error': {'code': status_code, 'message': self._reason, 'traceback': lines}})
        else:
            self.finish({'error': {'code': status_code, 'message': self._reason}})

    def send(self, message):
        self.write(jsonpickle.encode(message))

