import tornado.web
from tornado.web import *
from tornado import gen
import sys
import json
import time
from asimov.webapp.app.handlers.base import BaseHandler
from asimov.webapp.app.handlers.base import BaseHandlerException
from asimov.webapp.app.handlers.methods.project import ProjectMethod
from asimov.webapp.app.handlers.methods.base import MethodException

class ProjectHandler(BaseHandler):

    def set_params(self):
        data = self.request.body.decode('utf-8')
        self.params = json.loads(data)

    def get_param_value(self,key):
        try:
            param_value =  self.params[key]
        except KeyError:
            raise BaseHandlerException(400, reason="Missing Parameter {:}".format(key))
        else:
            return param_value

    def get_method(self):

        try:
            method = self.request.uri.split('/')[2].replace('-', '_')
        except KeyError:
            raise BaseHandlerException(400, reason="Method not provided")
        else:
            return method


    def handle_request(self):
        method = self.get_method()
        try:
            result = getattr(ProjectMethod(**self.params), method)(**self.params)
        except MethodException as e:
            raise BaseHandlerException(400, reason="{:}".format(e)).with_traceback(sys.exc_info()[2])
        else:
            self.send(result)

    def post(self):
        self.set_params() # extract parameters from request and set to self
        self.handle_request()

    def get(self):
        self.handle_request()

    def delete(self):
        self.handle_request()
