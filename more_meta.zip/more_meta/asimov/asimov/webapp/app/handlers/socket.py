import json
from sockjs.tornado import SockJSConnection
from tornado import gen
from asimov.webapp.backend_import import async
from asimov.webapp.app.handlers.methods.socket import SocketMethod
from asimov.webapp.app.handlers.methods.base import MethodException


clients = set()


class Socket(SockJSConnection):

    def on_open(self, request):
        """
        Request the client to authenticate and add them to client pool.
        """
        #self.authenticated = False
        #self.channel = None
        #self.send_message({}, 'request_auth')
        clients.add(self)

    @gen.coroutine
    def on_message(self, msg):
        try:
            params = json.loads(msg)
        except ValueError:
            self.send_error("Invalid parameter data")
            return

        method_name = params.pop('method')
        try:
            method_class = SocketMethod(socket=self, **params)
            method = getattr(method_class, method_name.split('-')[0])
            result = yield from method(**params)
        except MethodException as e:
            self.send_error(e, method_name)
        else:
            self.send_message(result, method_name)

    @gen.coroutine
    def on_close(self):
        """
        Remove client from pool. Connections are not
        re-used on e.g. browser refresh.
        """
        socket_key = async.get_socket_key(self)
        if self._session_exists(socket_key):
            project_id, model_id = socket_key
            yield from SocketMethod.end_session(project_id=project_id, model_id=model_id)

        clients.remove(self)
        return super(Socket, self).on_close()

    def _session_exists(self, socket_key):
        return isinstance(socket_key, tuple)

    def send_message(self, message, method):
        """
        Standard format for all messages
        """
        return self.send({
            'method': method,
            'data': message,
        })

    def send_error(self, message, error_type=None):
        """
        Standard format for all errors
        """
        return self.send({
            'method': 'error' if not error_type else '%s_error' % error_type,
            'data': str(message)
        })
