# -*- coding: utf-8 -*-
"""
Tests PipelineHandler
"""
import os
import tempfile
import unittest
import pandas as pd
from urllib.parse import urlencode
from sklearn.datasets import load_iris
from tornado.testing import AsyncHTTPTestCase
from tornado.web import Application
from tornado.escape import to_unicode
from tornado.escape import json_decode
from asimov.webapp.app.handlers.pipeline import PipelineHandler
from asimov.webapp.app.utils.mock_documents import mocked_docs


class PipelineHandlerTests(AsyncHTTPTestCase):
    
    def get_app(self):
        return Application([(r'/api/(\d\.\d)/pipeline/(.*)/(.*)', PipelineHandler)])

    def setUp(self):
        super().setUp()
        self.data_dir = '/asimov/data'
        iris = load_iris()
        self.iris = iris
        self.X = iris.data
        self.y = iris.target_names[iris.target]
        self.input_pdf = pd.DataFrame(self.X, columns=list(iris.feature_names))
        self.input_file = None
        self.output_file = None
    
    def tearDown(self):
        super().tearDown()
        try: os.remove(self.input_file)
        except: pass
        try:  os.remove(self.output_file)
        except: pass
    
    def test_csv_prediction(self):
        with mocked_docs() as docs:
            # get some file paths
            with tempfile.NamedTemporaryFile(dir=self.data_dir, suffix='.csv') as input_file:
                with tempfile.NamedTemporaryFile(dir=self.data_dir, suffix='.csv') as output_file:
                    self.input_file = input_file.name
                    self.output_file = output_file.name
            # write the data to disk
            self.input_pdf.to_csv(input_file.name)
            args = {'input_filepath': self.input_file, 'output_filepath': self.output_file}
            response = self.fetch("/api/1.0/pipeline/{:}/predict".format(docs.pipeline_doc.id), method='POST', body=urlencode(args))
            response_dict = json_decode(to_unicode(response.body))
            self.assertEqual(response.code, 200)
            self.assertEqual(response_dict, dict())

    def test_pipeline_publish(self):
        pass


if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(PipelineHandlerTests)
    unittest.TextTestRunner(verbosity=2).run(suite)
