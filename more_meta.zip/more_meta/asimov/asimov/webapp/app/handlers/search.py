import tornado.web
from tornado.web import *
from tornado import gen
import sys
import json
import time
from mongoengine import *
from asimov.webapp.app.handlers.base import BaseHandler
from asimov.webapp.app.handlers.base import BaseHandlerException
from asimov.webapp.app.handlers.methods.project import ProjectMethod
from asimov.webapp.app.handlers.methods.model import ModelMethod
from asimov.webapp.app.handlers.methods.user import UserMethod
from asimov.webapp.app.models.pipeline import Pipeline
from asimov.webapp.app.handlers.methods.base import MethodException

class SearchHandler(BaseHandler):

    def set_params(self):
        data = self.request.body.decode('utf-8')
        print('data',data)
        self.params = json.loads(data)

    def post(self):
        self.method = 'search'
        self.set_params() # extract parameters from request and set to self
        self.get_items()
        result = self.parse_doc()
        print('result******',result)
        self.send(result)

    def get_items(self):
        self.user_docs = self.search_users()
        self.project_docs = self.search_projects()
        self.model_docs = self.search_models()
        self.pipeline_docs = self.search_pipelines(**self.params)
        self.remove_items()
        self.arrange_items()


    def search_users(self):
        return getattr(UserMethod(**self.params), self.method)(**self.params)

    def search_projects(self):
        return getattr(ProjectMethod(**self.params), self.method)(**self.params)

    def search_models(self):
        return getattr(ModelMethod(**self.params), self.method)(**self.params)

    def search_pipelines(self,**kwargs):
        pipeline_docs = Pipeline.objects(
                                Q(name__icontains=kwargs['keyword']) | 
                                Q(backend__icontains=kwargs['keyword']) | 
                                Q(domain__icontains=kwargs['keyword']))
        return pipeline_docs

    def remove_items(self):
        self.remove_user_items()
        self.remove_project_items(self.project_docs)
        self.remove_model_items(self.model_docs)

    def remove_user_items(self):
        for user_doc in self.user_docs:
            self.project_docs = list(set(self.project_docs) - (set(user_doc.projects) & set(self.project_docs)))
            self.remove_project_items(user_doc.projects)

    def remove_project_items(self,project_docs):
        for project_doc in project_docs:
            self.model_docs = list(set(self.model_docs) - (set(project_doc.models) & set(self.model_docs)))
            self.remove_model_items(project_doc.models)

    def remove_model_items(self,model_docs):
        for model_doc in model_docs:
            self.pipeline_docs = list(set(self.pipeline_docs) - (set(model_doc.pipelines) & set(self.pipeline_docs)))

    def arrange_items(self):
        self.model_docs = list(set(self.model_docs) | set(self.get_nodes_by_level(self.pipeline_docs,'model','pipelines')))
        self.project_docs = list(set(self.project_docs) | set(self.get_nodes_by_level(self.model_docs,'project','models'))) 
        self.user_docs = list(set(self.user_docs) | set(self.get_nodes_by_level(self.project_docs,'user','projects'))) 

    def get_nodes_by_level(self,docs,node,level):
        nodes = {}
        for doc in docs:
            id = str(doc[node].id)
            if id in nodes:
                nodes[id][level].append(doc)
            else:
                nodes[id] = {}
                nodes[id][node] = doc[node]
                nodes[id][level] = [doc]
        nodes_by_level = []
        for key,value in nodes.items():
            print('nodes before call',nodes[key][node][level])
            nodes[key][node][level] = nodes[key][level]
            print('nodes after call',nodes[key][node][level])
            nodes_by_level.append(nodes[key][node])
        return nodes_by_level

    def parse_doc(self):
        user_docs = [self.parse_user_doc(user_doc) for user_doc in self.user_docs]
        return user_docs

    def parse_user_doc(self,doc):
        if len(doc.projects) > 0:
            projects = [self.parse_project_doc(project_doc) for project_doc in doc.projects]
        else:
            projects = []
        obj = UserMethod.parse_doc_to_obj(doc)
        obj['projects'] = projects
        return obj

    def parse_project_doc(self,doc):
        if len(doc.models) > 0:
            models = [self.parse_model_doc(model_doc) for model_doc in doc.models]
        else:
            models = []
        obj = ProjectMethod.parse_doc_to_obj(doc)
        obj['models'] = models
        return obj

    def parse_model_doc(self,doc):
        if len(doc.pipelines) > 0:
            pipelines = [ModelMethod.parse_pipeline_doc_to_obj(pipeline_doc) for pipeline_doc in doc.pipelines]
        else:
            pipelines = []
        obj = ModelMethod.parse_doc_to_obj(doc)
        obj['pipelines'] = pipelines
        return obj