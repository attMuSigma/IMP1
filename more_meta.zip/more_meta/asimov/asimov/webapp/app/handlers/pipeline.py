# -*- coding: utf-8 -*-
"""
Provides the PredictionHandler class
"""
import sys
from concurrent.futures import ProcessPoolExecutor
from tornado import gen
from asimov.webapp.app.handlers.base import BaseHandler 
from asimov.webapp.app.handlers.base import BaseHandlerException
from asimov.webapp.app.handlers.methods.pipeline import PredictMethod
from asimov.webapp.app.handlers.methods.pipeline import PublishMethod
from asimov.webapp.app.handlers.methods.base import MethodException


method_lookup = {'predict': PredictMethod, 'publish': PublishMethod}


class PipelineHandler(BaseHandler):

    @gen.coroutine
    def post(self, version, pipeline_id, method):
        # get method class
        try:
            method_class = method_lookup[method]
        except KeyError:
            raise BaseHandlerException(400, reason="Method {:} is not supported".format(method))
        # extract parameters from request
        req_list, opt_list = method_class.params()
        params = {name: self.get_argument(name) for name in req_list}
        opt_params = {name: self.get_argument(name, default) for name, default in opt_list}
        uri_params = {'pipeline_id': pipeline_id, 'version': version}
        params.update(opt_params)
        params.update(uri_params)
        # submit the prediction job
        try:
            method = method_class(**params)
            with ProcessPoolExecutor(max_workers=1) as exector:
                result = yield exector.submit(method.execute)
                self.write(result)
        except MethodException as e:
            raise BaseHandlerException(400, reason="Method {:} failed: {:}".format(method, e)).with_traceback(sys.exc_info()[2])