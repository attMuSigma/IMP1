# -*- coding: utf-8 -*-
"""
Provides utilities for creating mock documents
"""
import pandas as pd
from mongoengine import connect
from sklearn.linear_model import LogisticRegression
from sklearn.datasets import load_iris
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from asimov.sklearn_backend.widgets import data_types as adt

from asimov.webapp.app.models.user import User
from asimov.webapp.app.models.project import Project
from asimov.webapp.app.models.model import Model
from asimov.webapp.app.models.dag import Dag
from asimov.webapp.app.models import pipeline as pl


class mocked_docs(object):
    '''
    Context manager which creates mock documents and objects surrounding pipelines
    '''
    def __init__(self, db="mock-db", host="localhost", port=27017, create_pipeline=True, store_pipeline=True):
        self.db = db
        self.host = host
        self.port = port
        self.create_pipeline = create_pipeline
        self.store_pipeline = store_pipeline
    
    def __enter__(self):
        connect(self.db, host=self.host, port=self.port)
        # create dummy project and model
        user_doc = User(username='mock-user', password='mock-password', role='mock-role')
        user_doc.save()
        project_doc = Project(name='mock-project', user=user_doc)
        project_doc.save()
        model_doc = Model(username='mock-username', status='mock-status', name='mock-name', project=project_doc)
        model_doc.save()
        project_doc.models.append(model_doc)
        project_doc.save()
        user_doc.reload()
        project_doc.reload()
        model_doc.reload()
        self.user_doc = user_doc
        self.project_doc = project_doc
        self.model_doc = model_doc

        if self.create_pipeline:
            # train the pipeline and predict
            iris = load_iris()
            X, y = iris.data, iris.target_names[iris.target]
            pipeline_sk = Pipeline([('scaler', StandardScaler()), ('logistic', LogisticRegression())])
            pipeline_sk.fit(X, y)
            # save the pipeline
            X_pdf = pd.DataFrame(X, columns=list(iris.feature_names))
            y_ps = pd.Series(y, name='species')
            X_adf = adt.DataFrame(X_pdf, y_ps, adt.Domain.CLASSIFICATION)
            pipeline_adt = adt.Pipeline('logistic', pipeline_sk, adt.Domain.CLASSIFICATION, X_adf.signature)
            self.pipeline_adt = pipeline_adt
            self.pipeline_sk = pipeline_sk
            self.dataframe_adt = X_adf
        
        if self.store_pipeline:
            pipeline_doc = pl.update_pipeline_doc(pipeline_adt, model_doc.id)
            pipeline_doc.reload()
            self.pipeline_doc = pipeline_doc
            self.model_doc.reload()
        return self
    
    def __exit__(self, type, value, tb):
        self.user_doc.delete()
        self.project_doc.delete()
        self.model_doc.delete()
        try: self.pipeline_doc.delete()
        except AttributeError: pass
