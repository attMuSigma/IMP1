# -*- coding: utf-8 -*-
"""
Imports global instances of machine learning backend objects
"""
#from tornado.options import options
from asimov.ml_logic.ml_logic import MlLogic, LogicException
from asimov.webapp.option_parser import options
from asimov.webapp import settings  # unused but initializes global variables


class Async(object):

    def __init__(self):
        self._sockets = dict()

    def add_socket(self, key, socket):
        if key not in self._sockets:
            self._sockets[key] = socket
        else:
            raise LogicException("Model is in use".format(key[0]))

    def remove_socket(self, key):
        del self._sockets[key]

    def get_socket_key(self, socket):
        for key,value in self._sockets.items():
            if self._sockets[key] == socket:
                return key

    def notify_widget_state(self, project_id, model_id, widget_uid, state, message):
        print("Widget : ", widget_uid, "\n State : ", state )
        data = {'widget_uid' : widget_uid, 'state' : state, 'message' : message}
        self._sockets[(project_id, model_id)].send_message(data, 'widget_state')

    def notify_widget_model(self, project_id, model_id, widget_uid, widget_model):
        data = {'widget_uid' : widget_uid, 'widget_model' : widget_model}
        self._sockets[(project_id, model_id)].send_message(data, 'widget_model')


class MockPersistence(object):

    def create_widget(self, *args):
        print("PERSISTENCE CALLBACK: create_widget")

    def update_widget(self, *args):
        print("PERSISTENCE CALLBACK: update_widget")

    def delete_widget(self, *args):
        print("PERSISTENCE CALLBACK: delete_widget")


options.parse_command_line()
context = {'db_name': options.mongodb_name, 'db_host':options.mongodb_host, 'db_port':options.mongodb_port}
persist = MockPersistence()
async = Async()
logic = MlLogic(async, persist, context=context)
