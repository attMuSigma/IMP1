app.controller('EditorController', ['$rootScope', '$scope', '$http', '$location', '$timeout', '$socket', 'Model', 'Dag', 'Widget', 'Notify', 'Loader', 'ModalService', 'Plumb',
                                     function($rootScope, $scope, $http, $location, $timeout, $socket, Model, Dag, Widget, Notify, Loader, ModalService, Plumb) {

    $rootScope.is_project_page=false;
    $rootScope.is_login_page = false; 
    $rootScope.is_model_page = true;
    $rootScope.save_prompted = false;

    var currentModel = Model.get();
    var currentDag = {};
    Dag.clean(true);
    var widget_count = 0, loaded_widget_count = 0,loaded_widget_array = [];
    var modalsOpened = [];
    $scope.this_connection = {};

    var screen_width = angular.element("#canvas-container").width() - 10;
    var screen_height =  angular.element("#canvas-container").height() - 50;
    console.log(screen_width,' ',$(window).width(),' ',screen_height,' ', $(window).height());
    angular.element('#canvas').css({"min-width":screen_width,"min-height":screen_height});

    $('.widget-panel-header').click(function(){
        if(angular.element('#collapseOne').css('display') === 'block') {
            angular.element('#collapseOne').slideUp(500);
        }
        else {
            angular.element('#collapseOne').slideDown(500);
        }
    });

    var vph = $(window).height();
    $('#collapseOne').css({'height':vph});

    //To show the necessary widget popup
    var show_menu = function(widget_uid, widgetName) {
        if(modalsOpened.indexOf(widget_uid)<0){
            Loader.show();
            console.log("Showing menu")
            ModalService.showModal({
                templateUrl: '/public/views/modals/' + widgetName + '.html',
                controller: "MenuController"
            }).then(function(modal) {
                Loader.hide();
                modalsOpened.push(widget_uid);
                modal.element.modal().draggable();
                $('.modal-backdrop').remove();
                $('.modal').on('hidden', function(){
                    modalsOpened.splice(modalsOpened.indexOf(widget_uid, 1));
                })
            });
        }
    };

    //To open Delete modal
    var show_delete_prompt = function() {
        ModalService.showModal({
            templateUrl: '/public/views/modals/deleteModal.html',
            controller: "deleteController"
        }).then(function(modal) {
            modal.element.modal().draggable();
        });
    };

    //To open Save modal
    show_save_prompt = function() {
        ModalService.showModal({
            templateUrl: '/public/views/modals/saveModal.html',
            controller: "saveController"
        }).then(function(modal) {
            modal.element.modal({backdrop: 'static', keyboard: false}).draggable();
        });

    };

    //To update widget state
    $socket.add_callback('widget_state', function(statusInfo){
        console.log('Widget State : ')
        console.log(statusInfo);
        var icon = statusInfo.state.split(".")[1];
        /*
        if(icon=='working'){
            Loader.show();
        } else {
            Loader.hide();
        }
        */

        $('#status-'+statusInfo.widget_uid).remove();
        angular.element('<img id="status-'+ statusInfo.widget_uid + '" class="status-icon" title="'+ statusInfo.message +'" src="../static/img/' + icon + '.gif">').appendTo('#'+statusInfo.widget_uid);
        Widget.setStatus(statusInfo.widget_uid, statusInfo)
    });


    /************************jsPlumb code begins here*************************/
    var plumb = jsPlumb.getInstance();

    //jsPlumb initialization function
    plumb.ready(function(){
        //Wipes previous data
        plumb.reset();

        //Stores the connection to delete
        var conn_del,delConnEvent=false;

        //Endpoint definitions
        var leftEndPoint = {
                    endpoint: "Dot",
                    isSource: false,
                    isTarget: true,
                    reattach:true,
                    maxConnections: -1,
                    deleteEndpointsOnDetach:false,
                    connector:["Bezier", { curviness:70 }],
                    connectorStyle: {lineWidth: 4, strokeStyle: '#000'},
                    connectorOverlays:[
                        [ "Arrow", { width:14, length:14, location:1, id:"arrow" } ]
                        ],
                    anchor:"Left"
        };

        var rightEndPoint = {
                    endpoint: "Dot",
                    isSource: true,
                    isTarget: false,
                    detachable : true,
                    deleteEndpointsOnDetach:false,
                    maxConnections: -1,
                    connector:["Bezier", { curviness:70 }],
                    connectorStyle: {lineWidth: 4, strokeStyle: '#000'},
                    connectorOverlays:[
                        [ "Arrow", { width:14, length:14, location:1, id:"arrow" } ]
                        ],
                    anchor:"Right"
        };

         /*Jsplumb handler to color valid endpoints
            Operation : Listen for connection drag operation and highlights the endpoints while the user is dragging
                        Calls the startEpHighlight function to color the necessary the endpoints
        */
        plumb.bind("connectionDrag",function(info){
            var possible_sinks = Dag.get_possible_sinks(info.sourceId);
            startEpHighlight(possible_sinks);
        })

        var endpoint_to_recolor = [];
        /*  Helper function to color the endpoints on connection drag start
            Input : An array of valid widget port objects (retrieved from the Model service)
            Output : None
            Operation : Checks if the length of widget port array is non zero, retrieves the endpoints for
                        every widget in the array, highlights the target endpoints and pushes into another array
                        for recoloring
        */
        var startEpHighlight = function(ep_array){
            //Check if the array is not empty
            if(ep_array.length){
                //Iterate through the list of possible target endpoints
                for(i=0;i<ep_array.length;i++){
                    var source_end = ep_array[i].widget_uid.toString();
                    var endpoints = plumb.getEndpoints(source_end);
                    for(j=0;j<endpoints.length;j++){
                        if(endpoints[j].isTarget){
                            endpoints[j].setPaintStyle({fillStyle:'#66CD00'})
                            endpoint_to_recolor.push(endpoints[j]);
                        }
                    }
                }
            }
        }
        /*  Helper function to restore endpoints to origin color on connection drag stop
            Input : An array of valid and highlighted enpoint objects
            Output : None
            Operation : Iterates through the list of highlighted endpoints and restores the original endpoint color
        */
        var endEpHighlight = function(){
            for(i=0;i<endpoint_to_recolor.length;i++){
                endpoint_to_recolor[i].setPaintStyle({fillStyle:'#445566'})
            }
            endpoint_to_recolor = [];
        }
        /*
            return_source - Helper function to return source endpoint for a given widget ID
            Input: Widget ID
            Output: Source endpoint
            Operation: Iterates through the list of endpoints of a given widget,
                       checks for the isSource flag and returns the endpoint
        */
        var return_source = function(widget){
            var endpoints = plumb.getEndpoints(widget);
            for(var i=0;i<endpoints.length;i++){
                if(endpoints[i].isSource){
                    break;
                }
            }
            return endpoints[i];
        }

        /*
            return_target - Helper function to return target endpoint for a given widget ID
            Input: Widget ID
            Output: Target endpoint
            Operation: Iterates through the list of endpoints of a given widget,
                       checks for the isTarget flag and returns the endpoint
        */
        var return_target = function(widget){
            var endpoints = plumb.getEndpoints(widget);
            for(var i=0;i<endpoints.length;i++){
                if(endpoints[i].isTarget){
                    break;
                }
            }
            return endpoints[i];
        }

        /*
            bind_del_icon_widget - Helper function to bind the trash icon to a given widget for deletion
            Input: Widget ID
            Output: None
            Operation: On mouseenter : Binds the icon to the widget and on clicking the icon, it displays the delete
                                       confirmation prompt
                       On mouseleave : Removes the delete icon from the widget
        */
        var bind_del_icon_widget = function(widget){
            //Code to delete widget
            angular.element('#' + widget).on('mouseenter',function(){
                angular.element('<img class="delete-widget delete-icon-position"  src="../static/img/delete.png">').appendTo('#'+widget);

                angular.element('.delete-widget').click(function(event){

                    $rootScope.deleteItem = 'widget';
                    $rootScope.deleteItemId = widget;
                    $scope.widgetToDelete = event.target.parentNode;
                    show_delete_prompt();
                })
            });

            angular.element('#' + widget).on('mouseleave',function(){
                angular.element('.delete-widget').remove();
            });
        }
        /*
            bind_del_icon_connection - Helper function to bind delete(trash) icon to the connections
            Input: connection object
            Output: None
            Operation: On mouseenter : Binds the delete icon as an overlay on the appropriate connection
                                       and on clicking the delete icon, calls the appropriate service method
                                       and deletes the connection on success
                       On mouseleave : Removes the delete icon from the connection
        */
        var bind_del_icon_connection = function(connectionInfo){
            var overlay = connectionInfo.addOverlay(["Custom",{
                            create:function(){
                                return $('<img class="delete-connection delete-icon-position" src="../static/img/delete.png">');
                            },
                            location:0.5,
                            id:"delete-connection-new",
                            cssClass : "delete-connection",
                            events:{
                                click:function(connection,originalEvent){
                                    var thisConnection = {};
                                    var plumb_conn_id = connection.component.id;
                                    delConnEvent = true;
                                    plumb.detach(connection.component);
                                    Dag.delete_connection(plumb_conn_id);
                                }
                            }
                        }]);

            overlay.setVisible(false);

            //Shows the overlay on connection and adds the connection information to be deleted
            connectionInfo.bind('mouseover',function(connection,originalEvent){
                    overlay.setVisible(true);
                    conn_del = connection;
            });

            //Hides the overlay
            connectionInfo.bind('mouseout',function(connection,originalEvent){
                    overlay.setVisible(false);
            });
        }
        /*
            Event handler for connection detach events
        */
        plumb.bind("beforeDetach",function(info,originalEvent){
            console.log(info)
            if(delConnEvent){
                delConnEvent = false;
                return true;
            }
            else{
                return false;
            }
        })
        //Code to add bindings for newly formed connections
        plumb.bind("connectionDragStop", function (info, originalEvent) {
            endEpHighlight();
            //Stores connection information
            $scope.connectionInfo = info;

            var retrieved_object = Dag.get_connection($scope.connectionInfo.id);
            if(!retrieved_object && $scope.connectionInfo.endpoints==null){
                //For New connections onto the canvas without endpoints
            }
            else if(retrieved_object){
                //For existing connections onto the canvas without endpoints
                var retrieved_source = retrieved_object.source.widget_uid.toString(),
                    retrieved_target = retrieved_object.sink.widget_uid.toString();
                if($scope.connectionInfo.sourceId==retrieved_source && $scope.connectionInfo.targetId==retrieved_target){
                    Notify.info("Cannot modify existing connections")
                }
                else if(!$scope.connectionInfo.suspendedElement){
                    validate_connection();
                }
            }
            else{
                    validate_connection();
                }
        });
        var validate_connection = function(){
            //For New connections with endpoints
            bind_del_icon_connection($scope.connectionInfo);

            //For new connections (Manual connections)
            if($rootScope.loaded_model===false){
                //Connection validation
                Plumb.validate_connection($scope.connectionInfo, $scope.break_connection,
                function(source_ports, sink_ports) {
                    $scope.$apply(function(){
                        $scope.source_ports = source_ports;
                        $scope.sink_ports = sink_ports;
                    })
                    angular.element('#port_options_modal').modal({backdrop: 'static', keyboard: false}).draggable();
                })
            }
        }
        /******************************* Drag and Drop Code ***********************************/
        /*
            Handler that makes the icons on the side panel to be draggable
        */
        angular.element(".widget-panel-icon").draggable({
            helper: 'clone'
        });
        /*
            Handler to make the canvas droppable and call the necessary widget creation function
        */
        angular.element("#canvas").droppable({
            drop:function(event,ui){
                console.log(ui);
                if(ui.helper.context.children[0].id)
                    drag_to_canvas(ui);
            }
        })
        /*
            drag_to_canvas - Helper function to add widgets to canvas on drag and drop 
                            (called by the droppable handler on canvas)
            Input Parameter - Object containing html context and offset information
            Output Parameter - None
            Operation - Adds the necessary widget on the canvas based on information constructed from context and positioned appropriately
        */
        var drag_to_canvas = function (element) {
            widget_count++;
            console.log(element.helper.context.children[0])
            var thisWidgetData = element.helper.context.children[0];
            var thisWidget = {
                'id' : thisWidgetData.id,
                'uid' : widget_count,
                'name' : thisWidgetData.alt,
                'type' : thisWidgetData.id.split('.')[1],
            }
            console.log(thisWidget);

            console.log('widget-data'+JSON.stringify(currentModel._id));
            $scope.addWidgetData = {
                'method' : 'add_widget',
                'project_id' : $rootScope.currentProjectId,
                'model_id' : currentModel._id,
                'widget_id' : thisWidget.id,
                'widget_uid' : thisWidget.uid
            }
            console.log(element.offset.left)
            //create new window and add it to the body
            angular.element('<div id="'+ thisWidget.uid +'"  class="drag_enabler open_panel canvas-widget"><img class="canvas-widget-size open_modal" id="'+ thisWidget.id +'" title="'+ thisWidget.name +'" src="../static/img/widget_icons/' + thisWidget.type + '.png" alt="'+ thisWidget.name +'"></div>').appendTo('#canvas').innerHTML;
            angular.element("#"+thisWidget.uid).offset({top:element.offset.top,left:element.offset.left});

            Dag.add_widget($scope.addWidgetData, function(widgetJson){

                //set jsplumb properties
                plumb.draggable($('#' + thisWidget.uid),{containment:"#canvas"});

                //Binds the delete icon to the widget
                bind_del_icon_widget(thisWidget.uid);

                if(widgetJson.source_ports[0])
                    var right_endpoint = plumb.addEndpoint($('#' + widgetJson.widget_uid),rightEndPoint);
                if(widgetJson.sink_ports[0]){
                    var left_endpoint = plumb.addEndpoint($('#' + widgetJson.widget_uid),leftEndPoint);
                        left_endpoint.setParameters({maxConnections:Object.keys(widgetJson.sink_ports).length});
                }

            });
            

         }
        /*****************************************************************/
        
        plumb.bind("connection",function(info,originalEvent){
            if($rootScope.loaded_model===true){
                //Binds the delete icon to the connections
                bind_del_icon_connection(info.connection);
            }
        });
        $scope.break_connection = function(){
            delConnEvent = true;
            plumb.detach($scope.connectionInfo)
        }

        $scope.create_connection = function() {
            Plumb.create_connection($scope.connectionInfo, $scope.source_ports[$scope.source_port_index], $scope.sink_ports[$scope.sink_port_index]);

        }

        //Jsplumb code to remove widget
        var remove_widget = function(){
            Dag.remove_widget($scope.widgetToDelete.id);
            plumb.remove($scope.widgetToDelete);
        }


        Dag.add_callback('remove_widget', remove_widget);

        //New widget add function
        //Contains functions for opening the necessary popups, deleting widgets and setting data in service

        var add_to_canvas = function (e) {
            widget_count++;

           var thisWidgetData = $(this.childNodes[0]).context;
            var thisWidget = {
                'id' : thisWidgetData.id,
                'uid' : widget_count,
                'name' : thisWidgetData.alt,
                'type' : thisWidgetData.id.split('.')[1],
            }
            console.log(thisWidget.name, " clicked!")

            console.log('widget-data'+JSON.stringify(currentModel._id));
            $scope.addWidgetData = {
                'method' : 'add_widget',
                'project_id' : $rootScope.currentProjectId,
                'model_id' : currentModel._id,
                'widget_id' : thisWidget.id,
                'widget_uid' : thisWidget.uid
            }

            //create new window and add it to the body
            angular.element('<div id="'+ thisWidget.uid +'"  class="drag_enabler open_panel canvas-widget"><img class="canvas-widget-size open_modal" id="'+ thisWidget.id +'" title="'+ thisWidget.name +'" src="../static/img/widget_icons/' + thisWidget.type + '.png" alt="'+ thisWidget.name +'"></div>').appendTo('#canvas').innerHTML;

            Dag.add_widget($scope.addWidgetData, function(widgetJson){

                //set jsplumb properties
                plumb.draggable($('#' + thisWidget.uid),{containment:"#canvas"});

                //Binds the delete icon to the widget
                bind_del_icon_widget(thisWidget.uid);

                if(widgetJson.source_ports[0])
                    var right_endpoint = plumb.addEndpoint($('#' + widgetJson.widget_uid),rightEndPoint);
                if(widgetJson.sink_ports[0]){
                    var left_endpoint = plumb.addEndpoint($('#' + widgetJson.widget_uid),leftEndPoint);
                        left_endpoint.setParameters({maxConnections:Object.keys(widgetJson.sink_ports).length});
                }

            });


         }

        Widget.add_callback('add_to_canvas', add_to_canvas);
        $(".widget-panel-icon").on('dblclick', add_to_canvas);

        //Double click handler for each widget on canvas
        $(document.body).on('dblclick', '.canvas-widget' ,function(){
           $rootScope.thisWidgetId = $(this.childNodes)[0].id;
           $rootScope.thisWidgetUId = parseInt(this.id);
           show_menu($rootScope.thisWidgetUId, $(this.childNodes)[0].id.split('.')[1]);
        })

        //Code to load widgets on screen
         load_widgets = function(thisWidgetJson,pos_array){

            widget_count++;
            var xpos,
                ypos;

             var thisWidget = {
                'id' : thisWidgetJson.widget_id,
                'uid' : thisWidgetJson.widget_uid,
                'name' : thisWidgetJson.widget_id.split(".")[1].split("_").join(" "),
                'type' : thisWidgetJson.widget_id.split('.')[1],
                'attributes' : thisWidgetJson.attributes,
                'parameters' : thisWidgetJson.parameters

            }


            angular.element('<div id="'+ thisWidget.uid +'"  class="drag_enabler open_panel"><img class="canvas-widget-size open_modal" title="'+ thisWidget.name +'" src="../static/img/widget_icons/' + thisWidget.type + '.png" alt="'+ thisWidget.name +'"></div>').appendTo('#canvas').innerHTML;

            //Positions the elements on the screen
            for(var i=0;i<Object.keys(pos_array).length;i++){
                if(pos_array[i].ele==thisWidget.uid){
                    var current_ele = pos_array[i];

                    loaded_widget_array.push(current_ele.ele);
                    var canvas_offset = angular.element("#canvas").offset();
                    var canvas_bottom = canvas_offset.top + angular.element("#canvas").innerHeight(),
                        canvas_right = canvas_offset.left + angular.element("#canvas").innerWidth(),
                        xpos = current_ele.xpos*($(window).width()/current_ele.window_width),
                        ypos = current_ele.ypos*($(window).height()/current_ele.window_height),
                        widget_width = angular.element(".open_panel").width(),
                        widget_height = angular.element(".open_panel").height();
                    
                    xpos = canvas_offset.left+xpos;
                    ypos = canvas_offset.top+ypos;

                    angular.element("#"+thisWidget.uid).offset({left:xpos,top:ypos})
                    
                    if(xpos>canvas_right){
                        var right_adjust = xpos - canvas_right;
                        right_adjust = xpos - right_adjust;
                        right_adjust = right_adjust - widget_width;
                        angular.element("#"+thisWidget.uid).offset({left: right_adjust});
                        xpos = right_adjust;
                    }
                    
                    if(Math.abs(xpos-canvas_right)<widget_width){
                        var right_adjust = xpos - Math.abs(xpos-canvas_right);
                        right_adjust = right_adjust - 2 * widget_width;
                        angular.element("#"+thisWidget.uid).offset({left: right_adjust})    
                    }

                    if(ypos>canvas_bottom){
                        var bottom_adjust = ypos - canvas_bottom;
                        bottom_adjust = ypos - bottom_adjust;
                        bottom_adjust = bottom_adjust - widget_height;
                        angular.element("#"+thisWidget.uid).offset({ top: bottom_adjust});   
                        ypos = bottom_adjust;
                    }
                    
                    if(Math.abs(ypos-canvas_bottom)<widget_height){
                        var bottom_adjust = ypos - Math.abs(ypos-canvas_bottom);
                        bottom_adjust =  bottom_adjust - 2 * widget_height;
                        angular.element("#"+thisWidget.uid).offset({top: bottom_adjust})    
                    }

                    xpos = angular.element("#"+thisWidget.uid).offset().left;
                    ypos = angular.element("#"+thisWidget.uid).offset().top;

                    for(i = 0; i < loaded_widget_array.length; i++) {
                        if(current_ele.ele !== loaded_widget_array[i]){
                            var source_xpos = angular.element("#"+loaded_widget_array[i]).offset().left,
                                source_ypos = angular.element("#"+loaded_widget_array[i]).offset().top;
                            var left,left_diff,top_diff,top;
                            xpos = angular.element("#"+thisWidget.uid).offset().left;
                            ypos = angular.element("#"+thisWidget.uid).offset().top;
                            left_diff = xpos-source_xpos;
                            top_diff = ypos-source_ypos;
                            if(Math.abs(left_diff) < widget_width + 10 && Math.abs(top_diff) < widget_height + 10){
                                console.log(left_diff,'  :',top_diff);
                                if(Math.abs(left_diff) > Math.abs(top_diff)) {
                                    if(left_diff > 0) {
                                        left = xpos + (widget_width - Math.abs(left_diff)) + 10;
                                    }
                                    else {
                                        left = xpos - (widget_width - Math.abs(left_diff)) - 10;
                                    }

                                    if(left > canvas_right) {
                                        left = canvas_right - widget_width;
                                        left_diff = Math.abs(left - source_xpos);
                                        if(left_diff < (widget_width + 5)) {
                                            angular.element("#" + loaded_widget_array[i]).offset({left: (source_xpos - left_diff - 5)});
                                        }
                                    }
                                    angular.element("#"+thisWidget.uid).offset({left:left});  
                                }
                                else {
                                    if(top_diff > 0) {
                                        top = ypos + (widget_height - Math.abs(top_diff)) + 10;
                                    }
                                    else {
                                        top = ypos - (widget_height - Math.abs(top_diff)) - 10;
                                    }

                                    if(top > canvas_bottom) {
                                        top = canvas_bottom - widget_height;
                                        top_diff = Math.abs(top - source_ypos);
                                        if(top_diff < (widget_height + 5)) {
                                            angular.element("#" + loaded_widget_array[i]).offset({top: (source_ypos - top_diff - 5)});
                                        }

                                    }
                                        
                                    else if(top < canvas_offset.top) {
                                        top = canvas_offset.top;
                                        top_diff = Math.abs(top - source_ypos);
                                        if(top_diff < (widget_height + 5)) {
                                            angular.element("#" + loaded_widget_array[i]).offset({top: (source_ypos + top_diff + 5)});
                                        }
                                    }  
                                    angular.element("#"+thisWidget.uid).offset({top: top}); 
                                }
                                
                            }    
                        }
                    }

                }
            }
            //set jsplumb properties
            plumb.draggable($('#' + thisWidget.uid),{containment:"#canvas"});

            //Binds the appropriate widget popup on double click
            angular.element('#' + thisWidget.uid).dblclick(function() {
               $rootScope.thisWidgetId =  thisWidget.id;
               $rootScope.thisWidgetUId =  thisWidget.uid;

               show_menu(thisWidget.uid, thisWidget.type);

            })

            //Binds the delete icon to the widget
            bind_del_icon_widget(thisWidget.uid);

            if(thisWidgetJson.source_ports[0])
                var right_endpoint = plumb.addEndpoint($('#' + thisWidget.uid),rightEndPoint);
            if(thisWidgetJson.sink_ports[0]){
                var left_endpoint = plumb.addEndpoint($('#' + thisWidget.uid),leftEndPoint);
               // left_endpoint.setParameters({maxConnections:Object.keys(thisWidgetJson.sink_ports).length});
            }
        }

        //Save function
        //Computing the connections, elements and widgets and setting the entire model in model service
        update_dag = function(){
            var dag = {}, saveFlag;

            /*Retrieving connection pairs*/
            var connections = plumb.getAllConnections();
            var conn_list = [];
            for(var i = 0;i<connections.length;i++){
                conn_list[i] = new Array(4);
                conn_list[i][0] = connections[i].sourceId;
                conn_list[i][1] = connections[i].targetId;
                conn_list[i][2] = $.map(connections[i].endpoints, function(endpoint) {
                                    return [[endpoint.anchor.x,
                                    endpoint.anchor.y,
                                    endpoint.anchor.orientation[0],
                                    endpoint.anchor.orientation[1],
                                    endpoint.anchor.offsets[0],
                                    endpoint.anchor.offsets[1]]];
                                })
                conn_list[i][3] = connections[i].id;
            }


            /*Retrieving connected elements*/
            var element_list = [],
                cache = [],
                element={},xpos = 0,ypos = 0;
            var canvas_offset = angular.element('#canvas').offset();
            for(var i = 0;i<conn_list.length;i++){
                for(var j = 0;j<=1;j++){
                    if(cache.indexOf(conn_list[i][j])===-1){
                        cache.push(conn_list[i][j]);

                        var temp = $('#'+conn_list[i][j]);
                        var temp_offset = temp.offset();

                        element.ele = conn_list[i][j];
                        element.xpos = temp_offset.left-canvas_offset.left;
                        element.ypos = temp_offset.top-canvas_offset.top;
                        element.window_height = $(window).height();
                        element.window_width = $(window).width();
                        element_list.push(element);
                        element = {};
                    }
                }
            }

            element = {};
            //Retrieving unconnected elements
            var plumb_elem = angular.element(".open_panel");
            
            for(var i =0;i<plumb_elem.length;i++){
                if(cache.indexOf(plumb_elem[i].id)===-1){
                        element = {};
                        element.ele = plumb_elem[i].id;
                        var temp_offset = $("#"+plumb_elem[i].id).offset();
                        element.xpos = temp_offset.left-canvas_offset.left;
                        element.ypos = temp_offset.top-canvas_offset.top;
                        element.window_height = $(window).height();
                        element.window_width = $(window).width();
                        element_list.push(element);
                }
            }

            //Making conn_list into object of objects
            var conn_json = {};
            for(var i=0;i<conn_list.length;i++){
                conn_json[i] = {};
                conn_json[i].source = conn_list[i][0];
                conn_json[i].target = conn_list[i][1];
                conn_json[i].anchors = conn_list[i][2];
                conn_json[i].id = conn_list[i][3];
            }

            //Generating element list into object of objects
            var element_json = {};
            for(var i=0;i<element_list.length;i++){
                element_json[i] = element_list[i];
            }

            //Updating the Dag object
            var current_dag = Dag.current_dag();
            Dag.clean(!(Dag.dirty() || ! _.isEqual(current_dag.element_list, element_json)));
            var dag = current_dag;
            dag.conn_list = conn_json;
            dag.element_list = element_json;

            Dag.update(dag);
        }

        $rootScope.dashboard = function(){
            if(Dag.is_active()){
               angular.element('#busy_modal').modal({backdrop: 'static', keyboard: false}).draggable();
            } else {
               $location.path('/dashboard');
            }
        }

        $scope.interrupt = function(next) {
            Model.interrupt(function(){
               Dag.inactive()
               if(next=='dashboard') {
                    $timeout(function () {
                        $location.path('/dashboard');
                    }, 0);
               }
            })
        }

        $scope.$on('$locationChangeStart', function (event, next, current) {

            update_dag();

            //Closes any open popup
            angular.element('.modal').hide();

            //Session object to be sent
            var session_data = {
                'method' : 'end_session',
                'project_id' : $rootScope.currentProjectId,
                'model_id' : $rootScope.currentModelId
            }

            //Call to end session
            $socket.send(session_data, function(){});

            if(Dag.dirty()){
                event.preventDefault();
                $rootScope.next = $('<a></a>').attr('href', next)[0].pathname;
                show_save_prompt();
            }
        });

        //Function for model button handler
        $scope.saveButtonHandler = function(){
            update_dag();
            if(Dag.dirty()) {
                Dag.save();
            } else if (!Dag.is_active()){
                toastr.info('No changes made');
            }
        }

        //Code for drawing connections on screen        
        draw_connections = function(){
            var connection, source_node,target_node,final_source,final_target;
            if(Object.keys(currentDag.conn_list).length>0){
                //var parsed_conn_list = JSON.parse(currentDag.conn_list);
                for(var j=0;j<Object.keys(currentDag.conn_list).length;j++){
                    
                    //Retrieve endpoints of source and target of a given connection
                    final_source = return_source(currentDag.conn_list[j].source);
                    final_target = return_target(currentDag.conn_list[j].target);

                    //Make the connection with the necessary properties
                    connection = plumb.connect({
                                    source:final_source, 
                                    target:final_target,
                                    paintStyle:{lineWidth: 4, strokeStyle: '#000'},
                                    connector: ["Bezier", { curviness: 70 }],
                                    deleteEndpointsOnDetach:false,
                                    overlays:[ 
                                        [ "Arrow", { width:14, length:14, location:0.93, id:"arrow" } ]
                                    ]
                    });
                    
                    //Sets connection id based on stored ID    
                    connection.id = currentDag.conn_list[j].id;
                }
            }
            $rootScope.loaded_model = false;
        }

        if($rootScope.loaded_model) {
            Loader.show()
            Dag.get(function(dag){
                currentDag = dag;
                widget_count = 0;
                if(Object.keys(currentDag.widgets).length>0) {
                    //Places the widgets on the canvas
                    for(id in currentDag.widgets) {
                        //Sets the appropriate count for the new widgets to be added
                        widget_count = Math.max(widget_count, id);

                        //Calls the function to create the widgets on screen
                        load_widgets(currentDag.widgets[id],currentDag.element_list);
                        loaded_widget_count++;

                        //Checks if all the widgets have been created and then draws connections between them
                        if(loaded_widget_count===Object.keys(currentDag.widgets).length){
                            draw_connections();
                        }
                    }
                }
                else {
                    $rootScope.loaded_model = false;
                    Loader.hide();
                }
                Dag.active()
                Model.load();
            })
        } else {
            $rootScope.currentModelId = currentModel._id;
        }

    });
    var canvasAdjust = function(id,xpos,ypos,canvas,canvas_right,canvas_bottom){
        if(xpos<canvas.left){
            var left_adjust = xpos + (canvas.left-xpos);
            angular.element("#"+id).offset({left: left_adjust});
        }
        else if(ypos<canvas.top){
            var top_adjust = ypos + (canvas.top-ypos);
            angular.element("#"+id).offset({ top: top_adjust});
        }
        else if(xpos>canvas_right){
            var right_adjust = xpos - (xpos - canvas_right);
            angular.element("#"+id).offset({left: right_adjust});
        }
        else if(ypos>canvas_bottom){
            var bottom_adjust = ypos - (ypos - canvas_bottom);
            angular.element("#"+id).offset({ top: bottom_adjust});
        }
    }

}])