app.factory('Plumb', ['$http', '$rootScope', '$socket', 'Dag', 'Notify', function($http, $rootScope, $socket, Dag, Notify) {

    console.log("Service : Plumb");
    var port_options = {};
    var dtype_matches = function(source_dtype, sink_dtype) {
        source_dtype = source_dtype.split('.')[1];
        sink_dtype = sink_dtype.split('.')[1];
        if (!((source_dtype.indexOf(sink_dtype) > -1) ||  (sink_dtype.indexOf(source_dtype) > -1))) {
            return false;
        } else {
            return true;
        }
    }

    String.prototype.prettify = function(){
        return this.split(" ").map(function(word){return word.charAt(0).toUpperCase() + word.slice(1);}).join(" ");
    }

    var service = {

        create_connection : function(connectionInfo, source_port, sink_port){

            var this_connection = {
                "source": {
                    "widget_uid": parseInt(connectionInfo.sourceId),
                    "port_id": parseInt(source_port.port_id)
                },
                "sink": {
                    "widget_uid": parseInt(connectionInfo.targetId),
                    "port_id": parseInt(sink_port.port_id)
                }
            }

            var connection_data = {
                'connection_id' : connectionInfo.id +"_"+this_connection.source.widget_uid+"_"+this_connection.sink.widget_uid,
                'connection' : this_connection
            }
            connectionInfo.id = connection_data.connection_id;
            console.log("Creating connection : ");
            console.log(connection_data)

            Dag.create_connection(connection_data, function(){
                var sourceWidgetName = connectionInfo.source.children[0].alt;
                var sinkWidgetName = connectionInfo.target.children[0].alt;
                Notify.success('Connected -  ' +  sourceWidgetName + ' to ' + sinkWidgetName);
            });


        },
        validate_connection : function(connectionInfo, break_connection, prompt_port_options) {
            var source_ports = Dag.get_widget(connectionInfo.sourceId)['source_ports'];
            var sink_ports = Dag.get_widget(connectionInfo.targetId)['sink_ports'];

            if (connectionInfo.sourceId == connectionInfo.targetId) {
                Notify.error('Invalid Connection - A widget cannot be connected to itself');
                $rootScope.delConnEvent = true;
                detach_connection();
            }

            var this_widget_match = 0;
            var this_widget_vacancy = 0;

            for (i in source_ports) {
                if(source_ports.hasOwnProperty(i)) {
                    source_port = source_ports[i];

                    var this_port_match = 0;
                    var this_port_vacancy = 0;
                    for (i in sink_ports) {
                        if(sink_ports.hasOwnProperty(i)) {
                            sink_port = sink_ports[i];

                            if (dtype_matches(source_port.dtype, sink_port.dtype)) {
                                this_port_match++;
                                if(sink_port.source == null || sink_port.type != 'single') {
                                    this_port_vacancy++;
                                    var source_port_to_connect = source_port;
                                    var sink_port_to_connect = sink_port;
                                }
                            }
                        }
                    }
                    this_widget_match += this_port_match;
                    this_widget_vacancy += this_port_vacancy;
                }
            }

            var source_widget_name = connectionInfo.source.children[0].alt.prettify();
            var sink_widget_name = connectionInfo.target.children[0].alt.prettify();

            if(this_widget_match == 0) {
                Notify.error(source_widget_name +  " and " + sink_widget_name + " widgets are not compatible");
                break_connection();
            } else if (this_widget_vacancy ==0) {
                Notify.error(sink_widget_name + " widget cannot accept more connections");
                break_connection();
            } else if (this_widget_match == 1) {
                this.create_connection(connectionInfo, source_port_to_connect, sink_port_to_connect)
            } else if (this_widget_match > 1) {
                //port_options = {'source_ports' : source_ports, 'sink_ports' : sink_ports};
                prompt_port_options(source_ports, sink_ports);
            }

        },
        port_options : function() {
            return port_options;
        }
    }

    return service;

}])