app.directive("tree" , function(RecursionHelper, $rootScope, $timeout) {
    return {
        restrict: "E",
        scope: {selectedItems: '@selectedItems', treecontent: '=', onSelection: '=', clickHandler: '=', getData: '=', expandedNodes: '=', getSelectedNode: '='},
        template: 
         '<ul>' +
            '<li ng-repeat="node in children track by $index" ng-init="setNodeDetails(node);aItem = setItem();aItem[nodeType] = getNodeId(node);checkNode(node,aItem,nodeType,level);" ng-class="headClass(node);">' +
              '<div class="tree-item" id="{{node._id}}" sglclick="selectNode(node,aItem,nodeType,level);"  ng-dblclick="nodeType === \'models\' ? clickHandler(node,aItem,\'load\',nodeType,$event):selectNode(node,aItem,nodeType,level);">' +
                '<i class="tree-has-children" ng-click="toggleNode(node,nodeType,level,false); $event.stopPropagation();"></i>' +
                '<i ng-show="nodeType !== \'pipelines\'" class="tree-normal"></i>' +
                '<div class="tree-label" title="{{node[name]}}">' +
                  '<span>{{node[name]}}</span>' +   
                '</div>' +
                  '<div class="controls" ng-if="showControls(node._id) && nodeType !== \'users\' && nodeType !== \'pipelines\';" ng-init="titleLevel = level.slice(0, -1); titleNode = nodeType.slice(0, -1);">' +
                    '<img src="../static/img/delete.png" ng-click="clickHandler(node,aItem,\'delete\',nodeType,$event);" title="Delete {{titleNode}}"></img>' +
                    '<img src="../static/img/update_info.png" ng-click="clickHandler(node,aItem,\'update\',nodeType,$event);" title="Update {{titleNode}}"></img>' +
                    '<img ng-if="nodeType === \'models\';" src="../static/img/edit.png" ng-click="clickHandler(node,aItem,\'load\',nodeType,$event);" title="Load model"></img>' +
                    '<img ng-if="nodeType === \'projects\'" src="../static/img/add_model.png" style="margin-right: 8px;" ng-click="clickHandler(node,aItem,\'add\',level,$event);" title="New {{titleLevel}}" ></img>' +
                  '</div>' +
                  '<img class="add-icon" ng-if="addCreateIcon(node)" src="../static/img/add.png" ng-click="clickHandler(node,aItem,\'add\',level,$event);" title="New Project" ></img>' +
              '</div>' +
              '<tree ng-if="nodeExpanded(node)" selected-items="{{aItem}}" treecontent="node" on-selection="onSelection" click-handler="clickHandler" get-data="getData" expanded-nodes="expandedNodes" get-selected-node="getSelectedNode"></tree>' +
            '</li>' +
          '</ul>',
        compile: function(element) {
            return RecursionHelper.compile(element, function(scope, iElement, iAttrs,controller, transcludeFn){
              scope.selectedItems = scope.selectedItems || {};
              scope.expandedNodes = scope.expandedNodes || {};
              var findChildren = function(node) {
                return node.hasOwnProperty('projects') ? 'projects' : node.hasOwnProperty('models') ? 'models' : node.hasOwnProperty('pipelines') ? 'pipelines': false;
              };
              
              var treeContentIsArray = function(node) {
                if(angular.isArray(node)) {
                  return node;
                }
                else {
                  var children = findChildren(node);
                  return children !== false ? node[children] : []; 
                }
              }; 

              scope.getNodeId = function(node) {
                  return node._id;
              } 

              scope.setNodeDetails = function(node) {
                var children = findChildren(node);
                scope.level = children;
                scope.name = children === 'projects' ? 'username' : 'name';
                scope.nodeType = children === 'projects' ? 'users' : children === 'models' ? 'projects' : children === 'pipelines' ? 'models' : 'pipelines';
              }

              scope.headClass = function(node) {
                var children = findChildren(node);
                if (children && node[children].length && !scope.expandedNodes[node._id])
                  return "tree-collapsed";
                else if (children && node[children].length && scope.expandedNodes[node._id])
                  return "tree-expanded";
                else
                  return "tree-normal";
              };

              scope.addCreateIcon = function(node) {
                return node._id === $rootScope.current_user_details._id
              };

              scope.nodeExpanded = function(node) {
                return scope.expandedNodes[node._id];
              };

              // selecting a node which is already opened should not toggle on first selection behaviour

               scope.toggleNode = function(node,nodeType,level,callback) {
                callback = callback || function() {};
                if(scope.expandedNodes[node._id]) {
                  scope.expandedNodes[node._id] = !scope.expandedNodes[node._id];
                  callback();
                }
                else {
                  scope.getData(node,nodeType,level,function(node) {
                    scope.expandedNodes[node._id] = !scope.expandedNodes[node._id];
                    callback();
                  });
                }
              };

              scope.selectNode = function(node,selected_items,nodeType,level) {
                if(nodeType !== 'pipelines') {
                    var selectedNode = scope.getSelectedNode();
                    if(selectedNode && selectedNode._id === node._id) {
                      scope.expandedNodes[node._id] = !scope.expandedNodes[node._id];
                    }
                    else {
                      setSelected(node);
                      if(node[level] && node[level].length && node[level][0].hasOwnProperty('name')) {
                        scope.expandedNodes[node._id] = true;
                        scope.onSelection(node,selected_items,nodeType,level);
                      }
                      else {
                        scope.getData(node,nodeType,level,function() {
                          scope.expandedNodes[node._id] = true;
                          scope.onSelection(node,selected_items,nodeType,level);
                        });
                      }
                    }
                }
                else {
                  setSelected(node);
                  scope.onSelection(node,selected_items,nodeType,level);
                }

              };

              scope.setItem = function() {
                if(typeof(scope.selectedItems) != 'object')
                  scope.selectedItems = JSON.parse(scope.selectedItems);
                var newObj = {};
                if(Object.keys(scope.selectedItems).length >= 0) {
                  for(key in scope.selectedItems)
                    newObj[key] = scope.selectedItems[key];
                }
                return newObj;
              };

              scope.showControls = function(nodeId) {
                return angular.element('.tree-selected').attr('id') === nodeId ? true : false;
              };

              scope.checkNode = function(node, selected_items, nodeType, level) {
                var selectedNode = scope.getSelectedNode();
                if(scope.expandedNodes[node._id] && node[level].length && !node[level][0].hasOwnProperty('name')) {
                    scope.expandedNodes[node._id] = !scope.expandedNodes[node._id];
                    scope.getData(node,nodeType,level,function(node) {
                      scope.expandedNodes[node._id] = !scope.expandedNodes[node._id];
                    });
                }
                if(selectedNode && selectedNode._id === node._id) {
                      $timeout(function() {
                        setSelected(node);
                        scope.onSelection(node,selected_items,nodeType,level);
                      },10)
                };
              };

              var setSelected = function(node) {
                angular.element('.tree-selected').removeClass('tree-selected');
                angular.element('#' + node._id).addClass('tree-selected');
                scope.selectedNode = node;
              };
              scope.children = treeContentIsArray(scope.treecontent); 
            });
        }
    };
  });