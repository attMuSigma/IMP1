app.factory('Delete', ['Project' , 'Model', 'Dag', function(Project, Model, Dag){

	return{
	    project : function(project_id) {
	        Project.delete(project_id)
	    },
		model: function(model_id) {
            Model.delete(model_id)
		},
		widget : function(widget_uid){
		    Dag.delete_widget(widget_uid)
		}

	}
}]);