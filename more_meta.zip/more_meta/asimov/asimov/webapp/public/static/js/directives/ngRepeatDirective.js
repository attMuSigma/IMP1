app.directive('ngRepeatFinished', function() {
  return function(scope, element, attrs) {
    if (scope.$last){
         scope.$emit('renderComplete');
    }
  };
});


app.directive('modalReady', ['Loader', function(Loader) {
  return function(scope, element, attrs) { 
    scope.$on('renderComplete', function () {
          Loader.hide();
      });
  };
}]);

