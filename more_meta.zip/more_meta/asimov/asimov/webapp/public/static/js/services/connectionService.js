app.factory('connService', [function(Project, Model, Widget){

	var conn_port_array = [];


	return{
	    get:function(id){
	    	var temp_conn_object;
	    	for(var i=0;i<conn_port_array.length;i++){
	    		if(conn_port_array[i].id===id){
	    			temp_conn_object = conn_port_array[i]
	    		}
	    	}
	    	return temp_conn_object;
	    },
	    add:function(conn_object){
	    	Model.addConnMap(conn_object);
	    },
	    delete:function(conn_id){
	    	var temp;
	    	//Iterates through the list of connection objects and removes one matching the ID
        	for(var i=0;i<conn_port_array.length;i++){
                if(conn_port_array[i].id===conn_id){
                    temp = conn_port_array[i];
                }
            }
            conn_port_array.splice(conn_port_array.indexOf(temp),1);
	    },
	    load:function(loaded_map){
	    	conn_port_array = loaded_map;
	    },
	    getAllMappings:function(){
	    	return conn_port_array
	    }

	}
}]);