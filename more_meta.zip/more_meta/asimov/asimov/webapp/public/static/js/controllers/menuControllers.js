app.controller('MenuController', function($rootScope, $scope, $http, filterFilter, Model, Dag, Widget, Loader) {
       
       $scope.thisWidgetId = $rootScope.thisWidgetId;
       $scope.thisWidgetUId = $rootScope.thisWidgetUId;
       var widget_type =  $scope.thisWidgetId.split(".")[1];
       $scope.thisWidget = Dag.get_widget($scope.thisWidgetUId);
       //$scope.thisWidgetStatus = Widget.getStatus($scope.thisWidgetUId);
       $scope.thisWidgetParameters = Widget.parameters[widget_type]($scope.thisWidget);
       $scope.thisWidgetAttributes = Widget.attributes[widget_type]($scope.thisWidget);

       Dag.add_callback('updateWidgetAttributes-'+$scope.thisWidgetUId, function(widgetModel){
            $scope.$apply(function(){
                $scope.thisWidgetAttributes = Widget.attributes[widget_type](widgetModel);
            })
       });

       $scope.apply_parameters = function() {
            console.log('Submitting params - ', widget_type);

            $scope.apply_parameters_data = {
                'method' : 'apply_parameters-' + $scope.thisWidgetUId ,
                'project_id' : $rootScope.currentProjectId,
                'model_id' : $rootScope.currentModelId,
                'widget_id' : $scope.thisWidgetId,
                'widget_uid' : $scope.thisWidgetUId,
                'parameters' : $scope.thisWidgetParameters
            }
            console.log("Applying Parameters : ", widget_type );
            console.log($scope.apply_parameters_data);

            Widget.apply($scope.apply_parameters_data, function(widgetJson){
                $scope.$apply(function(){
                    $scope.thisWidgetAttributes = Widget.attributes[widget_type](widgetJson);
                })
                console.log("Evaluated - Attributes : ");
                console.log($scope.thisWidgetAttributes);
            });
       }

       $scope.dc_apply_parameters = function() {
            console.log('Drop Columns - submit  ');
            var dropCols= [];
            $.each($scope.thisWidgetAttributes.dropColSelection, function(col, sel) {
                if(sel==true)
                    dropCols.push(col);
            })
            $scope.thisWidgetParameters = {'drop_cols' : dropCols}
            $scope.apply_parameters();

       }

       $scope.sp_apply_parameters = function() {
            console.log('Scatter plot - submit  ');
            var plotVars = [];
            $.each($scope.thisWidgetAttributes.plotVarSelection, function(col, sel) {
                if(sel==true)
                    plotVars.push(col);
            })
            $scope.thisWidgetParameters = {'columns' : plotVars}
            $scope.apply_parameters();

       }

       $scope.ee_apply_parameters = function() {
            console.log('Estimator Evaluator - metrics : ');
            metrics = [];
            $.each($scope.metricSelection, function(metric, sel) {
                if(sel==true)
                    metrics.push(metric);
            })
            $scope.thisWidgetParameters.metrics = metrics;
            $scope.apply_parameters();
       }

       $scope.gbc_apply_parameters = function() {
            $scope.thisWidgetParameters.max_features = ($scope.thisWidgetParameters.max_features == 'value') ? $scope.max_features_value : $scope.thisWidgetParameters.max_features;
            $scope.apply_parameters();
       }
       
});

