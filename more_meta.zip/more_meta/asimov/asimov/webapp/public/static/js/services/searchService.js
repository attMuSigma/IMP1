app.factory('Search', function($http,Loader) {
    console.log("Service : User");

     var search_service =  {
        search : function(query,success_callback,error_callback) {
            Loader.show();
            $http.post('/search',query)
            .success(function(response) {
                Loader.hide();
                success_callback(response);
            })
            .error(function(err){
                Loader.hide();
                console.log(err);
                toastr.error('Error while searching keyword');
                error_callback();
            })
        }
    }

    return search_service;
});