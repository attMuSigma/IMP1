app.controller('LoginController', ['$rootScope', '$scope', '$http', '$location', function($rootScope, $scope, $http, $location) {

	console.log("Controller : LoginController");

	$scope.form = { method : 'login'};
	$rootScope.is_login_page = true;
    $rootScope.is_model_page = false;
      

	$scope.login = function() {

		$http.post('/user/login', $scope.form)
            .success(function(user) {
                $rootScope.current_user = user.username;
                $rootScope.current_user_details = user;
                $location.path('/dashboard');
            })
            .error(function(response){
                message =  response.error.message
                toastr.error(message);
            });
	}

	$scope.register = function() {

		$http.post('/user/register', $scope.form)
            .success(function(response) {
                    message = 'Registered successfully - Please Login!';
                    toastr.success(message);
                    $scope.form.method = 'login';
            })
            .error(function(response){
                message = response.error.message
                toastr.error(message);
            });
    }

}])


