app.config( function ( $routeProvider,$locationProvider ) {
  $routeProvider
  	.when( '/', {
  		templateUrl : 'public/views/login.html',
  		controller : 'LoginController'
  	})
  	.when( '/home', { templateUrl: 'public/views/home.html' } )
    .when( '/admin', { 
    	templateUrl: 'public/views/admin.html',
    	controller : 'AdminController'
    })
    .when( '/modelEditor', { 
      templateUrl: 'public/views/modelEditor.html',
      controller : 'EditorController'
    })
    .when( '/dashboard', { 
      templateUrl: 'public/views/dashboard.html',
      controller : 'DashboardController' 
    })
    .otherwise( { redirectTo: '/' } );

     $locationProvider.html5Mode(true);
});

