app.factory('Project', ['$http', function($http) {

    console.log("Service : Project");

    var project_service = {

        add : function(project, callback){
            $http.post('/project/add', project)
            .success(function(response){
                callback(response);
            })
            .error(function(error){
                console.log(error);
                toastr.error('Failed to create project: '+ project.name);
            })
        },
        add_replace : function(project, callback){
            $http.post('/project/add-replace', project)
            .success(function(response){
                console.log(response);
                callback(response);
            })
            .error(function(error){
                console.log(error);
                toastr.error('Failed to replace project: '+ project.name);
            })
        },
        
        find : function(query, response_callback, error_callback){
            $http.post('/project/find', query)
            .success(function(response){
                response_callback(response);
            })
            .error(function(error){
                toastr.error('Error while fetching projects');
                error_callback(error);
            })
        },
        update : function(project, callback){
            console.log(project);
            $http.post('/project/update', {'project' : project})
            .success(function(response) {
                if(response.status) {   
                    callback(response);
                }
            })
            .error(function(error){
                toastr.error('Project not updated');
            })
        },
        delete : function(project_id, callback){
            $http.post('/project/delete', {'_id' : project_id})
            .success(function(response){
                if(response) {
                    callback(response);
                }
            })
            .error(function(response){
                toastr.error('Project not deleted');
                console.log(response);
            })
        }

    }

    return project_service;
}]);
