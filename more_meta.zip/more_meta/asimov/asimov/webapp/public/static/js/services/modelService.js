app.factory('Model',['$rootScope', '$http', '$location', '$timeout', '$socket', 'Loader', 'Notify', 'Dag', function($rootScope, $http, $location, $timeout, $socket, Loader, Notify, Dag){

	console.log("Service : Model");

	var currentModel = {};
	var allModels = [];
	var callbacks = {} ;

    var error_handlers = {
        'add_model_error' : function(message){
            console.log(message);
            toastr.error('Model creation failed!');
        },
        'load_model_error' : function(message){
            console.log(message);
            $timeout(function () {
                $location.path('/dashboard');
            }, 0);
            toastr.error('Model load failed!');
            Loader.hide();
        },
        'save_model_error' : function(message){
            console.log(message);
            toastr.error('Model save failed!');
        },
        'end_session_error' : function(message){
            console.log(message);
            toastr.error(message);
            Loader.hide();
        },
        'interrupt_error' : function(message){
            console.log(message);
            toastr.info("Cannot interrupt");
            Loader.hide();
        }
    }

    $socket.addErrorCallbacks(error_handlers);

	return{
	    add_callback  : function(name, callback){
           callbacks[name] = callback;
        },
        getAllModels : function() {
            return allModels;
        },
		get : function(){
			return currentModel;
		},
        set : function(modelJson){
            currentModel = modelJson;
            Dag.add(modelJson.dag)
            $rootScope.currentProjectId = modelJson.project;
            $rootScope.currentModelId = modelJson._id;
        },
        add : function(model_data){
            Loader.show();
            $socket.send(model_data, function(model){
                console.log('New model : ');
                console.log(model);
                currentModel = model;
                Dag.add(model.dag);
                $rootScope.loaded_model = false;
                $rootScope.currentProjectId = currentModel.project;
                $rootScope.currentModelId = currentModel._id;
                toastr.success('New Model Created!')
                Loader.hide();
                $timeout(function () {
                    $location.path('/modelEditor');
                }, 0);
            });
        },
        update : function(model, callback){
            $http.post('/model/update', {'model' : model})
            .success(function(response) {
                if(response.status) {
                    callback(response);
                }
            })
            .error(function(error) {
                toastr.error('Model not updated');
                console.log(error);
            })
        },
        delete : function(query, callback){
            $http.post('/model/delete', query)
            .success(function(response){
                if(response.status) {
                    toastr.success('Model deleted');
                    callback(response);
                }
            })
            .error(function(error) {
                toastr.error('Model not deleted');
                console.log(error);
            })
        },
        find : function(query, response_callback, error_callback){
            $http.post('/model/find', query)
            .success(function(response){
                response_callback(response);
            })
            .error(function(error){
                toastr.error('Error while fetching models');
                error_callback(error);
            })
        },
        load : function(){
             var load_model_data = {
                'method' : 'load_model',
                'project_id' : currentModel.project,
                'model_id' : currentModel._id
             }
             Dag.active();
             $socket.send(load_model_data, function(){
                Loader.hide();
                Dag.inactive()
             });
        },
        interrupt : function(callback) {
            var interrupt_data = {
                'method' : 'interrupt',
                'project_id' : currentModel.project,
                'model_id' : currentModel._id
            }
            $socket.send(interrupt_data, function(){
               Loader.hide();
               toastr.info("Process interrupted")
               callback()
            });
        },
        find_by_project_id : function(project_id, callback) {
            $http.post('/model/find-by-project-id/' , {'project_id': project_id}).success(function(model_list){
                allModels = model_list;
                callback(allModels);
            });
        },
        get_pipelines_by_model_id : function(model_id, callback){
            $http.post('/model/get-pipelines-by-model-id', {'model_id' : model_id}).success(function(pipelines){
                callback(pipelines);
            }).error(function(response){
                toastr.error("Error getting pipelines")
                console.log(response)
            })
        },
        update_pipeline : function(pipeline, callback){ //to be moved to pipeline service
            $http.post('/model/update-pipeline', {'pipeline' : pipeline}).success(function(status){
                callback(status);
            }).error(function(response){
                toastr.error("Error updating pipelines")
                console.log(response)
            })
        }
	}
}]);

