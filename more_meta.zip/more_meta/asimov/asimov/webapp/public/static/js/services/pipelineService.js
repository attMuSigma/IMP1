app.factory('Pipeline', ['$http', function($http) {

    var pipeline_service = {

        find : function(query, response_callback, error_callback) {
            $http.post('/model/get-pipelines-by-model-id', {'model_id' : query.model})
            .success(function(pipelines){
                response_callback(pipelines);
            })
            .error(function(error){
                toastr.error("Error getting pipelines");
                error_callback(error);
            })
        },
        update : function(pipeline, callback) { //to be moved to pipeline service
            $http.post('/model/update-pipeline', {'pipeline' : pipeline}).success(function(status){
                callback(status);
            }).error(function(response){
                toastr.error("Error updating pipelines");
                console.log(response);
            })
        },
        predict : function(pipeline_uri,callback){
            $http.post(pipeline_uri).success(function(response){
                console.log(response);
                callback("Output file created with predictions");
            }).error(function(response){
                console.log(response);
                var status = response.error.message.split(':')[1] || response.error.message.split(':')[0];
                toastr.error(status);
            })
        }

    }

    return pipeline_service;
}]);