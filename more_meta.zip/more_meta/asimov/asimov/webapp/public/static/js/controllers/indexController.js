app.controller('IndexController', function($rootScope, $scope, $http, $location) {

	console.log("This is index controller");
      $rootScope.current_user = '';
      $scope.current_user = $rootScope.current_user;
	  $rootScope.is_project_page=false;
})