app.controller('DashboardController', ['$rootScope', '$scope', '$http', '$location', '$timeout', 'User', 'Project', 'Model', 'Pipeline', 'Search', 'Notify',
                                     function($rootScope, $scope, $http, $location, $timeout, User, Project, Model, Pipeline, Search, Notify) {

    console.log("Controller : Dashboard");
    $rootScope.is_project_page=true;
    $rootScope.is_login_page = false;
    $rootScope.is_model_page = false;
    $scope.templateURL = '';
    var query = {};
    $scope.selected_node = {};
    $scope.expanded = {};
    $scope.search_word = '';
    $scope.create_side_view = true;
    /*get the user Lists*/
    var services = {'user':User,'project': Project,'model': Model,'pipeline': Pipeline};
    
    if($(window).width()>800){
        var screen_width = $(window).width() - 150;
        var screen_height =  $(window).height() - 150;
        angular.element('.pageView').css({"min-width":screen_width,"min-height":screen_height});
        angular.element('#mainProject').css({"overflow":"auto"});
    }
    $scope.init = function() {
        $scope.create_tree = false;
        User.get_all(function(response){
            console.log(response);
            var current_user_index = response.map(function(x) {return x._id; }).indexOf($rootScope.current_user_details._id);
            response.splice(0, 0, response.splice(current_user_index, 1)[0]);
            $scope.users_list = response;
            Project.find({user:$rootScope.current_user_details._id},function(response) {
                $scope.users_list[0].projects = response;
                $scope.create_tree = true;
                set_new_user(response);
            });
        });
    };

    var set_new_user = function(projects) {
        if(projects.length)
            trigger_tree_click_event($rootScope.current_user_details._id);
        else {
            $scope.selected_node = $scope.users_list[0];
            angular.element('#' + $scope.selected_node._id).addClass('tree-selected');
            set_view_contents($scope.selected_node,{'users': $rootScope.current_user_details._id},'users','projects');
        }
    };

    /* method to find whether the item with given value is present in the passed array*/
    var find_index_in_array = function(array,key,value) {
        return array.map(function(item) {return item[key]; }).indexOf(value);
    };


    var find_nested_item_position = function() {
        var array = $scope.users_list;
        var index = {};
        index.users = find_index_in_array(array,'_id', $scope.selected_items.users);
        var nextLevelObj = array[index.users];
        for(key in $scope.selected_items) {
            if(key !== 'users') {
                array = nextLevelObj[key];
                console.log(array);
                found_index = find_index_in_array(array,'_id', $scope.selected_items[key]);
                found_index !== -1 ? (index[key] = found_index,  nextLevelObj = array[index[key]]) : delete $scope.selected_items[key];
                console.log($scope.selected_items);
            }
        }
        return index;
    };

    var set_path = function(array,selected_index,node_type) {
        var last_node = false;
        var path = array[selected_index.users].username;
        var nextLevelObj = array[selected_index.users];
        for(key in selected_index) {
            key === node_type ? last_node = true : false; 
            console.log(path);
            key !== 'users'  ? (array = nextLevelObj[key], path = path + '\\' + array[selected_index[key]].name, nextLevelObj = array[selected_index[key]]): false; 
            if(last_node)
                break;
        }    
        return path;
    };

    var count_array_items = function(array,key) {
        var count = 0;
        angular.forEach(array, function(item) {
            if(item[key])
                count += item[key].length;
        });
        return count;
    };

    var set_view_contents = function(selected_node,items,node_type,show_level) {
        $scope.templateURL = "";
        $scope.selected_items = items;
        var selected_index = find_nested_item_position();
        console.log(selected_index);
        $scope.path = set_path($scope.users_list,selected_index,node_type);
        node_type !== "pipelines" ? false : ($scope.selected_node.username = $scope.users_list[selected_index.users].projects[selected_index.projects].models[selected_index.models].username, $scope.publish_show = selected_node.username === $rootScope.current_user_details.username);
        node_type === 'projects' ? ($scope.pipelinesCount = count_array_items($scope.selected_node.models, 'pipelines')): node_type === 'users' ? ($scope.modelsCount = count_array_items($scope.selected_node.projects, 'models')): false;
        $timeout(function(){
            $scope.templateURL = "public/views/" + node_type + ".html";
        },10)
    };

    var format_pipeline_signature = function() {
        if($scope.selected_node.signature instanceof Array) {
            var signature = {};
            $scope.selected_node.signature.map(function(d){
                signature[d[0]] = d[1];
            });
            $scope.selected_node.signature = signature;
        }
    }

    $scope.set_model = function(model){
        $scope.selected_node = model;
    }
    
    $scope.show_selected = function(selected_node,items,type,show_level) {
        items[type] = selected_node._id;
        $scope.selected_node = selected_node;
        set_view_contents(selected_node,items,type,show_level);
    };

     $scope.get_data = function(selected_node,type,show_level,callback) {
        if(show_level && !$scope.search_word.length) {
            var service_name = show_level.slice(0, -1);
            var query_parameter_name = type.slice(0, -1);
            query = {};
            query[query_parameter_name] = selected_node._id;
            services[service_name].find(query,function(response){
                selected_node[show_level] = response;
                callback(selected_node);
            },function(err){
                console.log(err);
            });
        }
        else {
            callback(selected_node);
        } 
    };

    $scope.select_in_sideview = function(selected_node,node_type,show_level) {
        if(show_level && !selected_node[show_level].length)
            toastr.info('No ' + show_level + ' in ' + selected_node.name +' to show');
        else {
            $scope.set_selected(selected_node,node_type);
            if ( angular.element('#' + selected_node._id).length ) {
                trigger_tree_click_event(selected_node._id);
            }
            else {
                $scope.get_data(selected_node,node_type,show_level,function(node) {
                    $scope.show_selected(node, $scope.selected_items, node_type, show_level);
                    angular.element('.tree-selected').removeClass('tree-selected');
                });   
            }
        }
        
    };

    $scope.get_selected_node = function() {
        return $scope.selected_node;
    }

    $scope.click_handler = function(selected_node,items,operation,node_type,$event) {
        $event.stopPropagation();
        items[node_type] = selected_node._id;
        node_type = node_type.slice(0, -1);
        var method = operation.concat('_').concat(node_type);
        method !== 'add_project' ? ($scope.selected_node = selected_node, $scope.selected_items = items) : false;
        $scope[method]();

    };

    $scope.set_selected = function(value,node_type) {
        console.log(value,' ',node_type);
        $scope.selected_items[node_type] = value._id;
        console.log($scope.selected_items);
    };

    $scope.close_modal = function(modalId) {
        angular.element('#' + modalId).modal('hide');
    };

    $scope.show_submit = function() {
        $scope.show_replace = false;
    };

    var create_project_template = function() {
        var project = {
                    name: $scope.project_data.name,
                    description: $scope.project_data.description,
                    user: $rootScope.current_user_details._id,
                    tags: $scope.project_data.tags,
                    models: []
        };
        return project;
    };

    $scope.add_project=function(){
        $scope.show_replace = false;
        $scope.project_data = {
            'name':'',
            'description':'',
            'tags': []
        };
        $('#add_project_modal').modal('show').draggable({handle: ".modal-dialog"}); 
    };

    var create_find_existing = function(item_type,query,existing_item,modal_name,callback) {
        services[item_type].find(query,function(response) {
            if(response.length > 1) {
                $scope.close_modal(modal_name);
                toastr.error('Multiple ' + item_type + 'exists with the same name');
            }
            else if(response.length) {
                $scope[existing_item] = response[0];
                $scope.show_replace = true;
            }
            else {
                callback();
                $scope.close_modal(modal_name);
            }
        }, function(err) {
            $scope.close_modal(modal_name);
        });
    };
    
    /* Creates a new project and push the result into the $scope.projects */
    $scope.create_project = function() {
        $scope.current_user_index = find_index_in_array($scope.users_list,'_id',$rootScope.current_user_details._id);
        var query = {'user':$rootScope.current_user_details._id,'name': $scope.project_data.name};
        create_find_existing('project',query,'existing_project','add_project_modal',function() {
            var project = create_project_template();
            Project.add(project, function(project){
                toastr.success('Project: '+ project.name +' created');
                $scope.users_list[$scope.current_user_index].projects.push(project);
            });
        });
    };

    $scope.create_project_replace = function(){
        $scope.close_modal('add_project_modal');
        var project = create_project_template();
        project._id = $scope.existing_project._id;
        //Project overwrite call
        Project.add_replace(project, function(project){
            console.log(project);
            toastr.success('Project: '+ project.name +' replaced');
            var project_index = find_index_in_array($scope.users_list[$scope.current_user_index].projects,'_id', project._id);
            $scope.users_list[$scope.current_user_index].projects[project_index] = project;
            if($scope.selected_node._id === project._id) {
                $scope.selected_node = project;
            }
            $scope.modelsCount = count_array_items($scope.users_list[$scope.current_user_index].projects,'models');
        });
    };

    /* stores the currently selected project through setProject() and shows the modal for the update project */
    $scope.update_project = function() {
        var selected_index = find_nested_item_position();
        $scope.selected_project = $scope.users_list[selected_index.users].projects[selected_index.projects];
        copy_details('project_data','selected_project');
        $scope.show_replace = false;
        $('#update_project_modal').modal('show');
        $('#update_project_modal').draggable({
            handle: ".modal-dialog"
        });
    };



    /* update the project in the db and change the selected project to updated project in GUI */
    $scope.modify_project = function() {
        if($scope.selected_project.name === $scope.project_data.name && $scope.selected_project.description === $scope.project_data.description && $scope.selected_project.tags.toString() === $scope.project_data.tags.toString()) {
            toastr.info('No modifications are there to update');
            return;
        }
        var current_user_index = find_index_in_array($scope.users_list,'_id',$scope.selected_items.users);
        Project.find({'user':$scope.selected_items.users,'name': $scope.project_data.name},function(response) {
                if(response.length > 1) {
                    $scope.close_modal('update_project_modal');
                    toastr.error('Multiple projects exists with the same name');
                    return;
                }
                else if(response.length) {
                    if($scope.selected_project._id !== response[0]._id) {
                        $scope.existing_project = response[0];
                        $scope.show_replace = true;
                        return;
                    }
                }
                update_project_to_db(function() {
                    toastr.success('Project: ' + $scope.selected_project.name + ' updated');
                });
            }, function(err) {
                $scope.close_modal('update_project_modal');
        })
        
    };

    $scope.modify_project_replace = function() {
        var selected_index = find_nested_item_position();
        Project.delete($scope.existing_project._id,function(response){
            update_project_to_db(function() {
                toastr.success('Project: '+ $scope.existing_project.name + ' replaced');
                var existing_project_index = find_index_in_array($scope.users_list[selected_index.users].projects, '_id', $scope.existing_project._id)
                $scope.users_list[selected_index.users].projects.splice(existing_project_index, 1);
                if($scope.selected_node._id === $scope.selected_project._id)
                    trigger_tree_click_event($scope.selected_project._id);
                $scope.modelsCount = count_array_items($scope.users_list[selected_index.users].projects,'models');
            });
        });
    }

    var update_project_to_db = function(callback){
        $scope.close_modal('update_project_modal');
        var project = copy_item($scope.selected_project,$scope.project_data);
        Project.update(project, function(response){
            project.last_modified = $scope.project_data.last_modified = response.last_modified;
            var selected_index = find_nested_item_position();
            if($scope.selected_node._id === project._id) {
                copy_details('selected_node','project_data');
                $scope.path = set_path($scope.users_list,selected_index,'projects');
            }
            else {
                $scope.selected_node.projects[selected_index.projects] = project;
            }
            callback();
        });
    };

    var copy_item = function(selected_item,replace_item) {
        var item = angular.copy(selected_item);
        item.name = replace_item.name;
        item.description = replace_item.description;
        item.tags = replace_item.tags;
        return item;
    };

    var copy_details = function(modal_variable,selected_item) {
        $scope[modal_variable].name = $scope[selected_item].name;
        $scope[modal_variable].description = $scope[selected_item].description;
        $scope[modal_variable].tags = angular.copy($scope[selected_item].tags);
        $scope[modal_variable].last_modified = $scope[selected_item].last_modified;
    }

    var create_model_template = function(project_id){
        var model_template = {
            'method' : 'add_model',
            'name': '',
            'description': '',
            'tags': [],
            'username' :  $rootScope.current_user,
            'project' : project_id,
            'description' : '',
            'name' : '',
            'tags' : [],
            //'flows' : {},
            'status' : 'New'
        }
        return model_template;
    };

    $scope.add_model = function() {
        $scope.show_replace = false;
        $scope.model_data = create_model_template($scope.selected_items.projects);
        $rootScope.currentProjectId = $scope.selected_items.projects;
        $('#add_model_modal').modal('show').draggable({
            handle: ".modal-header"
        });
    };

    $scope.create_model = function() {
        var query = {'project':$scope.selected_items.projects,'name': $scope.model_data.name};
        create_find_existing('model',query,'existing_model','add_model_modal',function() {
            Model.add($scope.model_data);
        });
    };


    $scope.create_model_replace = function(){
        Model.delete({'_id':$scope.existing_model._id,'project':$scope.existing_model.project},function(response){
            Model.add($scope.model_data);
        });
    };

    $rootScope.modelinfo = {};

    $scope.update_model = function(){
        $scope.show_replace = false;
        var selected_index = find_nested_item_position();
        $scope.selected_model = $scope.users_list[selected_index.users].projects[selected_index.projects].models[selected_index.models];
        $scope.selected_project = $scope.users_list[selected_index.users].projects[selected_index.projects];
        copy_details('model_data','selected_model');
        $('#update_model_modal').modal('show').draggable();
    };

    /* function name : $scope.update_model_info
        Middleware   : Model.find - to find whether the model name to be updated is already present
                        with paramaters project and model name
        description  : if no modifications are done on the fields name, description, tags then shows message
                        otherwise find whether the same name is already present if present shows the 
                        model exists message otherwise call the update_model_to_db function with toastr message showing 
                        function as callback
    */

    $scope.update_model_info = function(){
        if($scope.selected_model.name === $scope.model_data.name && $scope.selected_model.description === $scope.model_data.description && $scope.selected_model.tags.toString() === $scope.model_data.tags.toString()) {
            toastr.info('No modifications are there to update');
            return;
        }
        Model.find({'project':$scope.selected_items.projects,'name': $scope.model_data.name},function(response) {
            if(response.length > 1) {
                $scope.close_modal('update_modelinfo_modal');
                toastr.error('Multiple projects exists with the same name');
                return;
            }
            else if(response.length) {
                if($scope.selected_model._id !== response[0]._id) {
                    $scope.existing_model = response[0];
                    $scope.show_replace = true;
                    return;
                }
            }
            update_model_to_db(function() {
                toastr.success('Model: '+ $scope.selected_model.name + ' updated');
            });
        }, function(err) {
            $scope.close_modal('update_model_modal');
        });
    };

    /* function name: $scope.update_model_replace
        Middleware  : Model.delete to delete the existing model
        description : replace the model when the model is updated with the same name as another model in the
                      same project (deletes the existing model and then call update_model_to_db), count the number of
                      pipelines in the array of models after model replaced

    */
    
    $scope.update_model_replace = function(){
        var selected_index = find_nested_item_position();
        Model.delete({'_id':$scope.existing_model._id,'project':$scope.existing_model.project},function(response){
            update_model_to_db(function() {
                toastr.success('Model: '+ $scope.existing_model.name + ' replaced');
                var existing_model_index = find_index_in_array($scope.users_list[selected_index.users].projects[selected_index.projects].models, '_id', $scope.existing_model._id)
                $scope.users_list[selected_index.users].projects[selected_index.projects].models.splice(existing_model_index, 1);
                if($scope.selected_node._id === $scope.selected_model._id)
                    trigger_tree_click_event($scope.selected_model._id);
                $scope.pipelinesCount = count_array_items($scope.users_list[selected_index.users].projects[selected_index.projects].models,'pipelines');
            });
        });
    }

    /* function name: update_model_to_db
        parameters  : callback - callback function to be executed after model update
        Middleware  : Model.update - to update the model name,description and tags
        description : update the selected model, updates the last_modified field of the project to which selected
                      model belongs to, if the model is the selected one in the tree then updates the path in
                      the breadcrumbs
    */
    var update_model_to_db = function(callback){
        $scope.close_modal('update_model_modal');
        var model = copy_item($scope.selected_model,$scope.model_data);
        Model.update(model, function(response){
            $scope.selected_project.last_modified = model.last_modified = $scope.model_data.last_modified = response.last_modified;
            var selected_index = find_nested_item_position();
            if($scope.selected_node._id === model._id) {
                copy_details('selected_node','model_data');
                $scope.path = set_path($scope.users_list,selected_index,'models');
            }
            else {
                $scope.selected_node.models[selected_index.models] = model;
            }
            callback();
        });
    }

    /* function name : $scope.set_model
        description  : when the load icon for the model in the side view is selected
                        set the model to selected_node
    */

    $scope.set_model = function(model) {
        $scope.selected_node = model;
    };

    /*  function name : $scope.load_model
        Middleware    : Model.set to set the selected model
        description   : sets the selected model in the Model service to get the model in editor screen and 
                        redirect to editor screen
    */

    $scope.load_model = function(){
        var model = $scope.selected_node;
        $rootScope.loaded_model = true;
        Model.set(model);
        $timeout(function() {
           $location.path('/modelEditor'); 
        }); 
    };

    /* function name : $scope.delete_project
        description  : sets the selected project to deleteitem and shows the delete popup
    */
    $scope.delete_project = function() {
        $scope.deleteItem = 'project';
        $('#delete_selected').modal('show').draggable();
    };

    /* function name : $scope.delete_model
        description  : sets the selected model to deleteitem and shows the delete popup
    */

    $scope.delete_model = function() {
        $scope.deleteItem = 'model';
        $('#delete_selected').modal('show').draggable();
    };


    /* function name: $scope.delete_selected
       description  : deletes the selected project or model from the db and if the node which is selected in the
                      tree got deleted then call trigger_click_event to select node in the tree
        Middleware  : call the Project.delete or model.delete with the needed parameters
    */
    $scope.delete_selected = function() {
        var selected_index = find_nested_item_position();
        if($scope.deleteItem === 'project') {
            var project = $scope.users_list[selected_index.users].projects[selected_index.projects];
            Project.delete(project._id,function(response){
                $scope.users_list[selected_index.users].projects.splice(selected_index.projects,1);
                $scope.modelsCount = count_array_items($scope.users_list[selected_index.users].projects,'models');
                toastr.success('Project: ' + project.name + ' deleted');
                if($scope.selected_node._id === project._id)
                    tree_auto_selection($scope.users_list[selected_index.users],$scope.users_list[selected_index.users].projects,selected_index.projects);
            });
        }
        else {
            var model = $scope.users_list[selected_index.users].projects[selected_index.projects].models[selected_index.models];
            Model.delete({'_id':model._id,'project':model.project},function(response){
                $scope.users_list[selected_index.users].projects[selected_index.projects].models.splice(selected_index.models,1);
                $scope.users_list[selected_index.users].projects[selected_index.projects].last_modified = response.last_modified;
                $scope.pipelinesCount = count_array_items($scope.users_list[selected_index.users].projects[selected_index.projects].models,'pipelines');
                toastr.success('Model: ' + model.name + ' deleted');
                if($scope.selected_node._id === model._id)
                    tree_auto_selection($scope.users_list[selected_index.users].projects[selected_index.projects], $scope.users_list[selected_index.users].projects[selected_index.projects].models, selected_index.models);
            });
        }
    };

    /* function name: tree_auto_selection
        parameters  : parent - parent of the node on which delete opertion is carried out
                      siblings - siblings of the node on which delete opertion is carried out
                      deleted_index - array index of the node which got deleted
        description : when the selected node in the tree got deleted the selection should be automatically 
                      transfered to next node if siblings are there else to parent node
    */

    var tree_auto_selection = function(parent,siblings,deleted_index) {
        item_id = siblings.length ? siblings[(deleted_index % siblings.length)]._id : parent._id;
        trigger_tree_click_event(item_id);
    }

    /* function name: trigger_tree_click_event
        parameters  : tree_item_id - node_id to be selected
        description : When any node is clicked in the side view the event will be
                      passed to the tree directive to set the node as selected one in the tree
    */

    var trigger_tree_click_event = function(tree_item_id) {
        $timeout(function() {
            var el = document.getElementById(tree_item_id);
            angular.element(el).triggerHandler('click');
        },100);
    };

    $scope.publish = function(pipeline) {
        console.log(pipeline)
    }

    $scope.predict = function(input_filepath,output_filepath) {
        var pipeline_uri  = '/api/1.0/pipeline/' + $scope.selected_node._id + '/predict?input_filepath=' + input_filepath + '&output_filepath=' + output_filepath;
        Pipeline.predict(pipeline_uri, function(status){
            toastr.success(status);
        });
    }

    /* set property ond order for sort */
   $scope.set_order_property = function(propertyName,id) {
        angular.element('.sortable').css('visibility','hidden');
        if ($scope.order_property === propertyName) {
            angular.element('#'+id).attr('src','../static/img/up-arrow.png');
            $scope.order_property = '-' + propertyName;
        } else if ($scope.order_property === '-' + propertyName) {
            angular.element('#'+id).attr('src','../static/img/arrow.png');
            $scope.order_property = propertyName;
        } else {
            angular.element('#'+id).attr('src','../static/img/arrow.png');
            $scope.order_property = propertyName;
        }
        angular.element('#'+id).css('visibility','visible');
    };

    $scope.search_keyword = function() {
        if(!$scope.search_word || !$scope.search_word.length) 
            toastr.info('No keyword is entered to search');
        else {
            $scope.create_tree = false;
            $scope.create_side_view = false;
            Search.search({'keyword': $scope.search_word},function(response) {
                console.log(response);
                if(response.length) {
                    $scope.users_list = response;
                    $scope.selected_node = $scope.users_list[0];
                    tree_after_search(true,function() {
                        set_view_contents($scope.selected_node,{'users': $scope.selected_node._id},'users','projects');
                    });
                    return;
                }
                else {
                    toastr.info('No items matched with the keyword: '+ $scope.search_word);
                    $scope.search_word = '';
                }
                tree_after_search(false);

            },function(err){
                tree_after_search(false);
            });
        }
    };

    var tree_after_search = function(view,callback) {
        $scope.create_tree = true;
        $scope.create_side_view = true;
        angular.element('#' + $scope.selected_node._id).addClass('tree-selected');
        if(view)
            callback();
    }

    /*$scope.clear_search = function() {
        if(!$scope.search_word || !$scope.search_word.length)
            $scope.init();
    }*/

}])
