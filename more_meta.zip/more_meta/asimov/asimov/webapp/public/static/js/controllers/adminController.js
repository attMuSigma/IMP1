app.controller('AdminController', function($rootScope, $scope, $http, $location) {

	$('#create').click(function(){
        $('#modal1').openModal();
    });
    
    $('#show').click(function(){
        $http.get("/widget").success(function(response){
            console.log("Widgets!")
            console.log(response);
            $scope.widgets = response;
            console.log($scope.widgets);
        });
        $('#modal2').openModal();
    });

	$scope.widgetFormDefault={'params' : {'wuid' : '', 'status' : 'ready' ,'parameters' : [], 'attributes' : [], 'sink_ports' : [], 'source_ports' : []}};
    $scope.widgetDataDefault={'parameters' : {}, 'attributes' : {}, 'sink_ports' : {}, 'source_ports' : {}};
	
    $scope.widgetForm = $scope.widgetFormDefault;
    $scope.widgetData = $scope.widgetDataDefault;
    
	$scope.createWidget = function() {
        
		//$scope.widgetForm.method = 'create_widget';
        $scope.widgetForm.params['parameters'].push($scope.widgetData.parameters);
        $scope.widgetForm.params['attributes'].push($scope.widgetData.attributes);
        $scope.widgetForm.params['sink_ports'].push($scope.widgetData.sink_ports);
        $scope.widgetForm.params['source_ports'].push($scope.widgetData.source_ports);

        console.log($scope.widgetForm);
        $http.post("/widgetsPanel", $scope.widgetForm).success(function(response) {

            $scope.widgetForm = $scope.widgetFormDefault;
            $scope.widgetData = $scope.widgetDataDefault;
            $('#modal1').closeModal();

        });
		
	}
})


