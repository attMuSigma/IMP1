var app = angular.module('attmlplatform', ['ngRoute', 'ngSanitize',"checklist-model", 'angularModalService', 'ngResource', 'tags-input']);




