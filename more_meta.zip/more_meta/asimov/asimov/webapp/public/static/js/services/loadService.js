app.factory('Loader',function ($rootScope) {

   console.log("Service : Loader");

   return {
       show: function () {
            angular.element('.overlay').show();
            angular.element('.loader').show();
       },
       hide: function () {
            angular.element('.overlay').hide();
            angular.element('.loader').hide();
       }
   }

});