app.factory('Dag', ['$http', '$rootScope', '$socket', 'Notify', 'Loader', function($http, $rootScope, $socket, Notify, Loader) {

    var current_dag = {};
    var callbacks = {} ;
    var dirty  = false;
    var active = false;
    var error_handlers = {

        'add_widget_error' : function(message){
            Notify.error("Error : " + message);
        },
        'delete_widget_error' : function(message){
            Notify.error("Error : " + message);
        },
        'create_connection_error' : function(message){
            Notify.error("Error : " , message);
        },
        'delete_connection_error' : function(message){
            Notify.error("Error : " , message);
        }

    }

    $socket.addErrorCallbacks(error_handlers);
    $socket.add_callback('widget_model', function(widgetData){

        //Updating the model information on every widget model update
        if(typeof current_dag._id != 'undefined'){
            current_dag.widgets[widgetData.widget_uid] = widgetData.widget_model;
        }

        var cbFunction = 'updateWidgetAttributes-' + widgetData.widget_uid;
        if(typeof callbacks[cbFunction] == 'function'){ //Function registered only if the widget menu is opened atleast once
            callbacks[cbFunction](widgetData.widget_model);
        }
    });

    var dag_service = {

        add_callback  : function(name, callback){
           callbacks[name] = callback;
        },
        dirty : function(){
            return dirty;
        },
        clean : function(bool){
            dirty = !bool;
        },
        is_active : function(){
            return active;
        },
        active : function(){
            active = true;
            $('.interrupt').prop("disabled",false);
        },
        inactive : function(){
            active = false;
            $('.interrupt').prop("disabled",true);
        },
        add : function(dag_id) {
            current_dag = {_id : dag_id, widgets : {}, conn_list : {}, element_list : {}, conn_map : {}};
        },
        current_dag : function() {
            return current_dag;
        },
        get : function(callback) {
            $http.post('/dag/get-by-id', {'_id' : current_dag._id})
            .success(function(dag){
                current_dag = dag;
                callback(dag);
            })
            .error(function(response){
                toastr.error("Error loading graph")
                console.log(response)
            })
        },
        update : function(dag) {
            current_dag = dag;
        },
        save : function() {
            $http.post('/dag/save', current_dag).success(function(response){
                toastr.success('Model saved');
                console.log(response);
                dirty = false;
            })
            .error(function(response){
                toastr.error('Error saving model');
                console.log(response);
            });
        },
        add_widget : function(addWidgetData, callback) {
            $socket.send(addWidgetData, function(widgetJson){
                console.log('widget creation successful : ');
                console.log( widgetJson);
                current_dag.widgets[widgetJson.widget_uid] = widgetJson;
                dirty = true;
                callback(widgetJson);
            })
        },
        delete_widget: function(widget_uid){
            deleteWidgetData = {
                'method' : 'delete_widget',
                'project_id' :$rootScope.currentProjectId,
                'model_id' : $rootScope.currentModelId,
                'widget_uid' : widget_uid
            }
            console.log("Deleting widget\t"+widget_uid)
            $socket.send(deleteWidgetData, function(){
                Notify.success("Widget deleted!");
                dirty = true;
                callbacks.remove_widget(widget_uid);
            });
        },
        get_widget : function(widgetUId) {
            return current_dag.widgets[widgetUId];
        },
        update_widget : function(newWidgetJson) {
            current_dag.widgets[newWidgetJson.widget_uid] = newWidgetJson;
            dirty = true;
        },
        remove_widget : function(widgetUId) {
            delete current_dag.widgets[widgetUId];
            dirty = true;
        },
        create_connection : function(connection_data, callback){
            $rootScope.message = 'Connecting widgets...';
            Loader.show();

            var create_connection_data = {
                'method' : 'create_connection',
                'project_id' : $rootScope.currentProjectId,
                'model_id' : $rootScope.currentModelId,
                'connection_id' : connection_data.connection_id,
                'connection' : connection_data.connection
            }
            $socket.send(create_connection_data, function(sink_widget_json){
                console.log("Connection response : ");
                console.log(sink_widget_json);
                current_dag.widgets[sink_widget_json.widget_uid] = sink_widget_json;
                current_dag.conn_map[connection_data.connection_id] = connection_data.connection;
                Loader.hide();
                dirty = true;
                callback();
            });
        },
        delete_connection : function(plumbConnId){
            var delete_connection_data = {
              'method' : "delete_connection",
              'project_id' : $rootScope.currentProjectId,
              'model_id' : $rootScope.currentModelId,
              'connection' : current_dag.conn_map[plumbConnId]
            }
            //console.log(delete_connection_data);
            $socket.send(delete_connection_data, function(response){
                console.log("Delete connection response : ");
                console.log(response);
                dirty = true;
                delete current_dag.conn_map[plumbConnId];
            });

        },
        get_connection : function(plumbConnId){
            return current_dag.conn_map[plumbConnId];
        },
       //Returns all the possible legal target sinks given a source widget id
       get_possible_sinks : function(widget_id){
            var source_ports = current_dag.widgets[widget_id].source_ports,
                final_sink_list = [];
            //Iterate through the list of all widgets
            for(index in source_ports){
                for(var id in current_dag.widgets){
                    //Check if it is not same as the source
                    if(id!=source_ports[index].widget_uid){
                        //Assign the necessary sink ports
                        var sink_ports = current_dag.widgets[id].sink_ports;
                        for(var i in sink_ports){
                            //Check if the datatype requirements match and if the sink port is vacant
                            if(source_ports[index].dtype===sink_ports[i].dtype && sink_ports[i].source===null){
                                final_sink_list.push(sink_ports[i]);
                            }
                        }
                    }
                }
            }
            return final_sink_list;
       }

    }

    return dag_service;
}]);
