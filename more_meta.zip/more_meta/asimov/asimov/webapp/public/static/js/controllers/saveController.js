app.controller('saveController', function($scope, $rootScope, $location, $socket, Dag) {

       var proceed = function() {
            Dag.clean(true);
            $location.path($rootScope.next);
       }
       $scope.submit = function (toSave){

            if(toSave) {
                Dag.save(proceed)
            } else {
                proceed();
            }
       }
});