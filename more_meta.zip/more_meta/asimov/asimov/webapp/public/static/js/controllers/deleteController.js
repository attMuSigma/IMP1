app.controller('deleteController', ['$rootScope', '$scope', '$http', 'Delete',
                                     function($rootScope, $scope, $http, Delete) {

    $scope.deleteItem = $rootScope.deleteItem;
    $scope.deleteItemId = $rootScope.deleteItemId;
    $scope.confirmDelete = function(){
  	console.log(JSON.stringify($scope.deleteItem),$scope.deleteItemId);
    Delete[$scope.deleteItem]($scope.deleteItemId);
  }
}]);