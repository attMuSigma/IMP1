app.factory('$socket', ['Notify', 'Loader', function(Notify, Loader){

    console.log("Service : $socket");
    var _Socket = {};
    var callbacks = {
        'error' : function(message) {
            console.log(message);
        },
        'widget_model' : function(data){
            console.log("Widget model recieved : ");
            console.log(data)
        }
    };

    var url = window.location.origin + '/ws';
    var sock = new SockJS(url);
	
    sock.onopen = function() {
        console.log("Websocket : opened connection")
    }

    sock.onmessage = function(e) {
       var response = e.data;
       console.log("Websocket(message received) : " + response.method);

       callbacks[response.method](response.data)
    };

    sock.onclose = function() {
       console.log('close');
    };

    _Socket = {
        send : function(message, callback, errorCallback){
            callbacks[message.method] = callback ;
            if(errorCallback) callbacks[message.method+ '_error'] = errorCallback ;
            console.log("Websocket(Sending message) : ",message)
            sock.send(JSON.stringify(message));
        },
        add_callback : function(cbName, cbFunction){
            callbacks[cbName] =  cbFunction;
        },
        addErrorCallbacks : function(errorHandlers){
            $.each(errorHandlers, function(cbName, cbFunction){
                callbacks[cbName] = function(message){
                    cbFunction(message);
                    Loader.hide();
                }
            })
        }
    }

    return _Socket;

}])
