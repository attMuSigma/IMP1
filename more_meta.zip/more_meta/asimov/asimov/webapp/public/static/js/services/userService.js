app.factory('User', function($http) {
    console.log("Service : User");

     var user_service =  {
        get_all : function(callback) {
            $http.get('/user/find')
            .success(function(response) {
                callback(response);
            })
            .error(function(response){
                console.log(response)
            })
        }
    }

    return user_service;
});