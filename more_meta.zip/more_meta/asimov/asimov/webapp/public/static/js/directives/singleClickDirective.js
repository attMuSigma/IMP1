app.directive('sglclick', ['$parse','$timeout', function($parse,$timeout) {
    return {
        priority: 1001,
        restrict: 'A',
        link: function(scope, element, attr) {
          var fn = $parse(attr['sglclick']);
          var delay = 300, clicks = 0, timer = null;
          element.on('click', function (event) {
            clicks++;  //count clicks
            if(clicks === 1) {
              console.log(clicks);
              timer = $timeout(function() {
                fn(scope,{$event:event});
                clicks = 0;
              },delay)
              } else { 
                $timeout.cancel(timer);
                clicks = 0;            
              }
          });
        }
    };
}]);