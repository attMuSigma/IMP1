app.factory('Widget', ['$http', '$rootScope', '$socket', 'Notify', 'Model', 'Dag', 'Loader', function($http, $rootScope, $socket, Notify, Model, Dag, Loader) {

    var widgetStatuses  = {};
    var callbacks = {};

    //For loaded models as the state information comes before the model loads
    $socket.add_callback('widget_state', function(statusInfo){
        widgetStatuses[statusInfo.widget_uid] = statusInfo;
    });

    var errorHandlers = {
        'apply_parameters_error' : function(message){
            Notify.error("Error : " + message);
        }
    }

    $socket.addErrorCallbacks(errorHandlers);

    widgetService =  {

        add_callback : function(name, callback){
            callbacks[name] = callback;
        },
        apply : function(apply_parameters_data, callback){
            Loader.show();
            Dag.active();
            $socket.send(apply_parameters_data, function(widgetJson){
                console.log("Response - widgetJson : ")
                console.log(widgetJson)
                Dag.update_widget(widgetJson);
                callback(widgetJson);
                Dag.inactive();
                Loader.hide();
            })
        },
        setStatus : function(widget_uid, statusInfo){
            widgetStatuses[widget_uid] = statusInfo;
        },
        getStatus : function(widget_uid){
            return widgetStatuses[widget_uid];
        },
        add_to_canvas : function(e) {
            callbacks['add_to_canvas'](e);
        },
        parameters : {
            local_browser : function (widgetJson) {
                return {
                    'depth' : widgetJson.parameters.depth.value,
                    'root_dir': widgetJson.parameters.root_dir.value,
                    'selected_file' : widgetJson.parameters.selected_file.value
                }
            },
            csv : function (widgetJson) {
                return {
                    'filepath' : widgetJson.parameters.filepath.value,
                    'separator' : widgetJson.parameters.separator.value
                }
            },
            dataframe_sampler : function (widgetJson) {
                return {
                    'randomize' : widgetJson.parameters.randomize.value,
                    'sample_size' : widgetJson.parameters.sample_size.value
                }
            },
            dataframe_split : function(widgetJson) {
                return {
                    'shuffle' : widgetJson.parameters.shuffle.value,
                    'split' : widgetJson.parameters.split.value
                }
            },
            pca : function(widgetJson) {
                return {
                    'n_components' : widgetJson.parameters.n_components.value,
                    'whiten' : widgetJson.parameters.whiten.value
                }
            },
            drop_column : function(widgetJson) {
                return {
                    drop_cols : (widgetJson.parameters.drop_cols.value) ? widgetJson.parameters.drop_cols.value : []
                }
            },
            scatterplot_matrix : function(widgetJson) {
                return {
                    columns : (widgetJson.parameters.columns.value) ? widgetJson.parameters.columns.value : []
                }
            },
            select_target : function(widgetJson) {
                return {
                   'domain' : widgetJson.parameters.domain.value,
                   'target' : widgetJson.parameters.target.value
                }
            },
            estimator_evaluator : function(widgetJson) {
                return {
                    'nfolds' : widgetJson.parameters.nfolds.value,
                    'randomize' : widgetJson.parameters.randomize.value,
                    'shuffle' : widgetJson.parameters.shuffle.value
                }
            },
            gradient_boosting_classifier : function(widgetJson) {
                return {
                    'learning_rate' : widgetJson.parameters.learning_rate.value,
                    'max_depth' : widgetJson.parameters.max_depth.value,
                    'max_leaf_nodes' : widgetJson.parameters.max_leaf_nodes.value,
                    'min_samples_leaf' : widgetJson.parameters.min_samples_leaf.value,
                    'min_samples_split' : widgetJson.parameters.min_samples_split.value,
                    'n_estimators' : widgetJson.parameters.n_estimators.value,
                    'subsample' : widgetJson.parameters.subsample.value,
                    'max_features' : widgetJson.parameters.max_features.value,
                    'randomize' : widgetJson.parameters.randomize.value
                }
            },
            cross_validate: function(widgetJson){
                return{
                    'nfolds' : widgetJson.parameters.nfolds.value,
                    'randomize' : widgetJson.parameters.randomize.value,
                    'shuffle' : widgetJson.parameters.shuffle.value
                }
            },
            roc_curve : function(widgetJson){
                return{}
            },
            pipeline_store : function(widgetJson){
                return{}
            },
            pipeline_predict : function(widgetJson){
                return{}
            },
            svc : function(widgetJson) {
                return {
                    'C' : widgetJson.parameters.C.value,
                    'kernel' : widgetJson.parameters.kernel.value,
                    'degree' : widgetJson.parameters.degree.value,
                    'gamma' : widgetJson.parameters.gamma.value,
                    'coef0' : widgetJson.parameters.coef0.value,
                    'shrinking' : widgetJson.parameters.shrinking.value,
                    'tol' : widgetJson.parameters.tol.value,
                    'class_weight' : widgetJson.parameters.class_weight.value,
                    'max_iter' : widgetJson.parameters.max_iter.value,
                    'randomize' : widgetJson.parameters.randomize.value
                }
            },
            confusion_matrix: function(widgetJson){
                return{
                    'normalize' : widgetJson.parameters.normalize.value
                }
            },
        },
        attributes : {
            local_browser : function (widgetJson) {
                return {
                    'filelist' : widgetJson.attributes.file_list.value,
                    'root_dir_options' : widgetJson.parameters.root_dir.options[0].options
                }
            },
            csv : function (widgetJson) {
                return {
                    'filepath' : widgetJson.attributes.active_filepath.value,
                    'separator' : widgetJson.attributes.active_separator.value
                }
            },
            dataframe_sampler : function (widgetJson) {
                var dataframe = []
                if(widgetJson.attributes.samples.value != null) {
                    dataframe = $.map(widgetJson.attributes.samples.value.X.value, function(row, n) {
                        n = parseInt(n) ? parseInt(n) : n;
                        return {'n' : n, 'row' : row}
                    })
                }
                return {
                    'dataframe_headers' : (widgetJson.attributes.samples.value == null) ? [] : widgetJson.attributes.samples.value.X.meta.name,
                    'dataframe' : dataframe
                }
            },
            dataframe_split : function(widgetJson) {
                return {}
            },
            drop_column : function(widgetJson) {
                var droppedVars = (widgetJson.parameters.drop_cols.value) ? widgetJson.parameters.drop_cols.value : []
                var dropColSelection = {};
                if(droppedVars.length>0) {
                    $.each(droppedVars, function(i, varName) {
                        dropColSelection[varName] = true;
                    })
                }
                return {
                    'dropColSelection' : dropColSelection,
                    'dropColOptions' : (widgetJson.parameters.drop_cols.options[0].options) ? widgetJson.parameters.drop_cols.options[0].options : []
                }
            },
            pca : function(widgetJson) {

                var n_components = $.map(widgetJson.parameters.n_components.options, function(option) {
                        return {'label' : option.dtype, 'value' : option.default_value}
                });
                var meanValArray = [];
                 if(widgetJson.attributes.mean.value != null){
                    meanValArray = $.map(widgetJson.attributes.mean.value.X.value, function(meanVal){
                        return meanVal[0];
                    })
                }
                return {
                    'components' : (typeof widgetJson.attributes.components == 'undefined')? '' : widgetJson.attributes.components.value,
                    'explained_variance_ratio' : (typeof widgetJson.attributes.explained_variance_ratio == 'undefined')? '' : widgetJson.attributes.explained_variance_ratio,
                    'mean' : meanValArray,
                    'n_components' : n_components,
                    'noise_variance' : widgetJson.attributes.noise_variance.value
                }
            },
            scatterplot_matrix : function(widgetJson) {
                var columnOptions = (widgetJson.parameters.columns.options[0].options) ? widgetJson.parameters.columns.options[0].options : [];
                var plottedVars = (widgetJson.parameters.columns.value) ? widgetJson.parameters.columns.value : []
                var plotVarSelection = {};
                if(plottedVars.length>0) {
                    $.each(plottedVars, function(i, varName) {
                        plotVarSelection[varName] = true;
                    })
                }
                return {
                    'plotString' : (typeof widgetJson.attributes.plot.value === 'undefined') ? '' : widgetJson.attributes.plot.value,
                    'plotVarOptions' : columnOptions,
                    'plotVarSelection' : plotVarSelection
                }
            },
            select_target : function(widgetJson) {
                return {
                   'domainOptions' : widgetJson.parameters.domain.options[0].options,
                   'targetOptions' : widgetJson.parameters.target.options[0].options
                }
            },
            gradient_boosting_classifier : function(widgetJson) {
                return {
                    max_features_options : [
                        {'value' : null, 'label' : 'null'},
                        {'value' : 'auto', 'label' : 'auto'},
                        {'value' : 'sqrt', 'label' : 'sqrt'},
                        {'value' : 'log2', 'label' : 'log2'},
                        {'value' : 'value', 'label' : 'value'}
                    ]
                }
            },
            estimator_evaluator : function(widgetJson) {
                var metricScoresData = (widgetJson.attributes.scores.value == null)? {} : widgetJson.attributes.scores.value.X.value ;
                var metricScores = $.map(metricScoresData, function(s, m) {
                            return {'metric' : m , 'cv_scores' : s[0]};
                })
                return {
                    'metricOptions' : widgetJson.parameters.metrics.options[0].options,
                    'metricScores' : metricScores
                }
            },
            cross_validate : function(widgetJson) {
                var metricScoresData = (typeof widgetJson.attributes.scores == 'undefined')? {} : widgetJson.attributes.scores.value.X.value ;
                var metricScores = $.map(metricScoresData, function(s, m) {
                            return {'metric' : m , 'cv_scores' : s[0]};
                })
                return {
                    'metricScores' : metricScores
                }
            },
            roc_curve : function(widgetJson) {
                return {
                    'plotString' : ( widgetJson.attributes.plot.value === null) ? '' : widgetJson.attributes.plot.value
                }
            },
            pipeline_store : function(widgetJson) {
                return {}
            },
            pipeline_predict : function(widgetJson) {
                return {}
            },
            svc : function(widgetJson) {
                return {
                   'kernelOptions' : widgetJson.parameters.kernel.options[0].options,
                   'classWeightOptions' : widgetJson.parameters.class_weight.options[0].options
                }
            },
            confusion_matrix : function(widgetJson) {
                return {
                    'plotString' : ( widgetJson.attributes.plot.value === null) ? '' : widgetJson.attributes.plot.value
                }
            },
        }
    }

    return widgetService;

}]);

