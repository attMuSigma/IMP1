# -*- coding: utf-8 -*-
"""
Provides Logistic Regression widget class
"""
import pandas as pd
from sklearn.linear_model import LogisticRegression
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.attributes import DataFrameAttribute
from asimov.sklearn_backend.widgets.attributes import IntAttribute
from asimov.sklearn_backend.widgets.attributes import FloatAttribute
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.sink_port import SingleSink
from asimov.sklearn_backend.widgets.parameters import Parameter
from asimov.sklearn_backend.widgets.parameters import EnumArg
from asimov.sklearn_backend.widgets.parameters import FloatArg
from asimov.sklearn_backend.widgets.parameters import BoolArg


class LogisticRegressionWidget(BaseWidget):

    def __init__(self, widget_uid):
        super().__init__('supervised.logistic_regression', widget_uid)
        self._estimator = LogisticRegression()

    def _update_ports(self):
        '''
        Creates this widget's ports
        '''
        self._sink_ports[0] = SingleSink(self._widget_uid, 0, adt.DataFrame)
        self._source_ports[0] = SourcePort(self._widget_uid, 0, adt.DataFrame)

    def _update_static_parameters(self):
        self._parameters.update({'penalty': Parameter([EnumArg('l2', ['l1', 'l2'])]),
                                 'dual': Parameter([BoolArg(False)]),
                                 'C': Parameter([FloatArg(1.0)]),
                                 'fit_intercept': Parameter([BoolArg(True)]),
                                 'intercept_scaling': Parameter([FloatArg(1.0)]),
                                 'auto_balance': Parameter([BoolArg(True)]),
                                 'randomize': Parameter([BoolArg(False)])})
    
    def _fit(self):
        '''
        Creates a new estimator and fits the input data
        '''
        try:
            self._estimator = LogisticRegression(penalty=self._parameters['penalty'].value, 
                                                 dual=self._parameters['dual'].value,
                                                 C=self._parameters['C'].value,
                                                 fit_intercept=self._parameters['fit_intercept'].value,
                                                 intecept_scaling=self._parameters['intecept_scaling'].value,
                                                 class_weight='auto' if self._parameters['auto_balance'].value else None,
                                                 random_state=None if self._parameters['randomize'].value else 0)
            input_pdf = self._sink_ports[0].data.X
            self._estimator.fit(input_pdf)
        finally:
            self._update_attributes()

    def _update_attributes(self):
        '''
        Updates this widget's parameters if the estimator has been fit prior
        '''
        try:
            comp = adt.DataFrame(pd.DataFrame(self._estimator.components_))
            mean = adt.DataFrame(pd.DataFrame(self._estimator.mean_))
            evr = adt.DataFrame(pd.DataFrame(self._estimator.explained_variance_ratio_))
            ncomp = self._estimator.n_components_
            nv = self._estimator.noise_variance_
        except AttributeError:
            comp = mean = evr = ncomp = nv = None
        self._attributes['components'] = DataFrameAttribute(comp)
        self._attributes['explained_variance_ratio'] = DataFrameAttribute(evr)
        self._attributes['mean'] = DataFrameAttribute(mean)
        self._attributes['n_components'] = IntAttribute(ncomp)
        self._attributes['noise_variance'] = FloatAttribute(nv)
    
    def _transform(self):
        '''
        Transforms sink port data and places it on source port
        '''
        input_pdf = self._sink_ports[0].data.X
        output_ndarray = self._estimator.transform(input_pdf)
        output_pdf = pd.DataFrame(output_ndarray, columns=["Feature {:}".format(i) for i in range(output_ndarray.shape[1])],
                                                  index=["Component {:}".format(i) for i in range(output_ndarray.shape[0])])
        output_adf = adt.DataFrame(output_pdf)
        self._source_ports[0].data = output_adf

    def _update_dynamic_parameters(self):
        '''
        This widget has no dynamic parameters
        '''
