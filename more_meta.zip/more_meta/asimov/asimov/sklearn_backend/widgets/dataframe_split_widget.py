# -*- coding: utf-8 -*-
"""
Provides a class for dropping columns from a dataframe
"""
import pandas as pd
import sklearn.cross_validation as scv
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget
from asimov.sklearn_backend.widgets.draft_widget import WidgetException
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.sink_port import SingleSink
from asimov.sklearn_backend.widgets.parameters import Parameter
from asimov.sklearn_backend.widgets.parameters import FloatArg
from asimov.sklearn_backend.widgets.parameters import BoolArg

class DataframeSplitWidget(BaseWidget):
    _widget_id = 'data.dataframe_split'

    def _initialize(self):
        '''
        This widget has no unique initialization routine
        '''

    def _update_ports(self):
        self._sink_ports[0] = SingleSink(self._widget_uid, 0, adt.DataFrame)
        self._source_ports[0] = SourcePort(self._widget_uid, 0, adt.DataFrame, 'DataFrame A')
        self._source_ports[1] = SourcePort(self._widget_uid, 1, adt.DataFrame, 'DataFrame B')

    def _update_static_parameters(self):
        '''
        Initializes the static parameters safely
        '''
        self._parameters.update({'split': Parameter([FloatArg(0.30)]),
                                 'shuffle': Parameter([BoolArg(False)])})

    def _update_dynamic_parameters(self):
        '''
        This widget has no dynamic parameters
        '''

    def _update_attributes(self):
        '''
        This widget has no attributes
        '''

    def _evaluate(self):
        '''
        Splits the input DataFrame and places the subsets on the output port
        '''
        input_adf = self._sink_ports[0].data
        data = input_adf.X
        target = input_adf.y
        random_state = None if self._parameters['shuffle'].value else 0
        split = self._parameters['split'].value
        
        idx_a, idx_b = self._create_indexes(input_adf, split, random_state)
        data_a = data.iloc[idx_a]
        data_b = data.iloc[idx_b]
        if target is None:
            target_a = target_b = None
        elif isinstance(target, pd.Series):
            target_a = pd.Series(target.iloc[idx_a], name=target.name)
            target_b = pd.Series(target.iloc[idx_b], name=target.name)
        else:
            raise WidgetException('DataFrame target is not a Series')
        output_adf_a = adt.DataFrame(data_a, target_a, parent_widget=self, source_adfs=input_adf, match_index=False)
        output_adf_b = adt.DataFrame(data_b, target_b, parent_widget=self, source_adfs=input_adf, match_index=False)
        self._source_ports[0].data = output_adf_a
        self._source_ports[1].data = output_adf_b
    
    def _create_indexes(self, adf, split, random_state):
        '''
        Returns the indexes used for creating subsets A and B
        '''
        if adf.domain is adt.Domain.CLASSIFICATION:
            splitter = scv.StratifiedShuffleSplit(adf.y, n_iter=1, random_state=random_state, test_size=split)
        else:
            splitter = scv.ShuffleSplit(adf.X.shape[0], 1, random_state=random_state, test_size=split)
        return next(iter(splitter))
