# -*- coding: utf-8 -*-
"""
Provides PCA widget class
"""
import numpy as np
import pandas as pd
from . import data_types as adt
from .attributes import DataFrameAttribute
from .attributes import IntAttribute
from .attributes import FloatAttribute
from .draft_widget import TransformWidget
from .draft_widget import WidgetException
from .source_port import SourcePort
from .sink_port import SingleSink
from .parameters import Parameter
from .parameters import EnumArg
from .parameters import IntArg
from .parameters import FloatArg
from .parameters import NoneArg
from .parameters import BoolArg
from sklearn.decomposition import PCA


class PcaWidget(TransformWidget):
    _widget_id = 'decomposition.pca'

    def _initialize(self):
        self._estimator = PCA()

    def _update_ports(self):
        '''
        Creates this widget's ports
        '''
        self._sink_ports[0] = SingleSink(self._widget_uid, 0, adt.DataFrame)
        self._source_ports[0] = SourcePort(self._widget_uid, 0, adt.DataFrame)

    def _update_static_parameters(self):
        '''
        Initializes static parameters
        '''
        self._parameters.update({'n_components': Parameter([NoneArg(), IntArg(1), FloatArg(0.99), EnumArg('mle', ['mle'])]),
                                 'whiten': Parameter([BoolArg(False)])})
    
    def _fit(self):
        '''
        Creates a new estimator and fits the input data
        '''
        input_adf = self._sink_ports[0].data
        if (np.object==input_adf.signature).any():
            raise WidgetException('PCA cannot handle string or other complex object data types')
        self._estimator.set_params(n_components=self._parameters['n_components'].value, whiten=self._parameters['whiten'].value)
        input_nd = input_adf.X.as_matrix()
        try:
            self._estimator.fit(input_nd)
        except Exception as e:
            raise WidgetException(e).with_traceback(e.__traceback__)

    def _update_attributes(self):
        '''
        Updates this widget's parameters if the estimator has been fit prior
        '''
        try:
            #comp = # adt.DataFrame(pd.DataFrame(self._estimator.components_))
            mean = None # adt.DataFrame(pd.DataFrame(self._estimator.mean_))
            #evr = adt.DataFrame(pd.DataFrame(self._estimator.explained_variance_ratio_))
            ncomp = self._estimator.n_components_
            nv = self._estimator.noise_variance_
        except AttributeError:
            comp = mean = evr = ncomp = nv = None
        #self._attributes['components'] = DataFrameAttribute(comp)  # TODO: add back when appropriate
        #self._attributes['explained_variance_ratio'] = DataFrameAttribute(evr)  # TODO: add back when appropriate
        self._attributes['mean'] = DataFrameAttribute(mean)
        self._attributes['n_components'] = IntAttribute(ncomp)
        self._attributes['noise_variance'] = FloatAttribute(nv)
    
    def _transform(self):
        '''
        Transforms sink port data and places it on source port
        '''
        input_adf = self._sink_ports[0].data
        input_pdf = input_adf.X
        output_ndarray = self._estimator.transform(input_pdf)
        output_pdf = pd.DataFrame(output_ndarray, columns=["Feature {:}".format(i) for i in range(output_ndarray.shape[1])], index=input_pdf.index)
        output_adf = adt.DataFrame(output_pdf, parent_widget=self, source_adfs=input_adf)
        self._source_ports[0].data = output_adf

    def _update_dynamic_parameters(self):
        '''
        This widget has no dynamic parameters
        '''
