# -*- coding: utf-8 -*-
"""
Provides data types
"""
import weakref
import urllib
import os
import pandas as pd
import sklearn as sk
from enum import Enum
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget
from sklearn.pipeline import Pipeline as sk_Pipeline

class DataTypeException(Exception):
    pass


class AvpEnum(Enum):
    def __str__(self):
        return self.value
    def __repr__(self):
        return self.value


class Domain(AvpEnum):
    NONE = 'domain.none'
    CLASSIFICATION = 'domain.classification'
    REGRESSION = 'domain.regression'


_domain_from_str = {str(domain): domain for domain in Domain}
def domain_from_string(string):
    try:
        return _domain_from_str[string]
    except KeyError as e:
        raise DataTypeException("Domain {:} is invalid".format(e))


class ResourceScheme(AvpEnum):
    FILE = 'resource.file'
    HDFS = 'resource.hdfs'


class MetaDataType(type):
    '''
    Meta class which offers control over string representation for serialization
    '''
    string_rep='datatype.base'
    base = None

    def __str__(self):
        return self.string_rep
    
    def __repr__(self):
        return self.string_rep


class Estimator(object, metaclass=MetaDataType):
    string_rep='datatype.estimator'

    def __init__(self, name, estimator, domain=Domain.NONE):
        self._verify_est(estimator)
        self._name = name
        self._estimator = estimator
        self._domain = domain
    
    def _verify_est(self, estimator):
        if not isinstance(estimator, self.base):
            raise DataTypeException("Input estimator must be type: {:}".format(self.base))

    @property
    def name(self):
        return self._name

    @property
    def estimator(self):
        return self._estimator
    
    def clone(self):
        sk.base.clone(self._estimator)
    
    @property
    def domain(self):
        return self._domain


class Pipeline(Estimator):
    string_rep='datatype.estimator.pipeline'
    base = sk_Pipeline
    
    @staticmethod
    def create_scikit_pipeline(transforms, estimator, estimator_name):
        pipeline = sk.base.clone(transforms)
        pipeline.steps.append((estimator_name, sk.base.clone(estimator)))
        return pipeline

    def __init__(self, name, pipeline, domain, signature):
        super().__init__(name, pipeline, domain)
        self.signature = signature
        self.classes = pipeline.classes_ if hasattr(pipeline, 'classes_') else None


class Classifier(Estimator):
    string_rep = 'datatype.estimator.classifier'
    base = sk.base.ClassifierMixin

    def __init__(self, name, estimator):
        super().__init__(name, estimator, Domain.CLASSIFICATION)


class Regressor(Estimator):
    string_rep = 'datatype.estimator.regressor'
    base = sk.base.RegressorMixin
    
    def __init__(self, name, estimator):
        super().__init__(name, estimator, Domain.REGRESSION)


class Prediction(object, metaclass=MetaDataType):
    string_rep = 'datatype.prediction'

    def __init__(self, predictions, estimator_name, domain, classes=None):
        self._verify_pred(predictions, domain)
        self._predictions = predictions
        self._estimator_name = estimator_name
        self._domain = domain
        self._classes = list() if classes is None else list(classes)
        if self._domain is Domain.CLASSIFICATION and not self._classes:
            raise DataTypeException('Classification predictions must provide a class list')
        
    def _verify_pred(self, predictions, domain):
        '''
        Raises DataTypeException if it is not formed correctly
        '''
        if domain is Domain.CLASSIFICATION:
            self._verify_cols({'prediction', 'target', 'fold', 'probability'}, set(predictions.columns))
        elif domain is Domain.REGRESSION:
            self._verify_cols({'prediction', 'target', 'fold'}, set(predictions.columns))
        else:
            raise DataTypeException("Invalid domain {:} specified".format(domain))
    
    def _verify_cols(self, required_cols, columns):
        '''
        Raises DataTypeException if the input column set does not have the required columns
        '''
        if not required_cols == columns:
            raise DataTypeException("Invalid Prediction has columns {:} instead of {:}".format(columns, required_cols))

    @property
    def predictions(self):
        return self._predictions.copy(deep=False)
    
    @property
    def domain(self):
        return self._domain
    
    @property
    def classes(self):
        return self._classes
    
    @property
    def estimator_name(self):
        return self._estimator_name


class Resource(object, metaclass=MetaDataType):
    string_rep = 'datatype.resource'

    @staticmethod
    def from_uri(uri):
        '''
        Static factory which returns a Resource from URI
        '''
        parser = urllib.parse.urlparse(uri)
        path = os.path.abspath(os.path.join(parser.netloc, parser.path))
        lookup = {enum.name.lower(): enum for enum in ResourceScheme}
        try:
            return Resource(lookup[parser.scheme], path)
        except KeyError as e:
            raise DataTypeException("Unsupported URI scheme: {:}".format(e))

    def __init__(self, scheme, path):
        if scheme not in ResourceScheme:
            raise DataTypeException("Invalid resource scheme: {:}".format(scheme))
        self._scheme = scheme
        self._path = path
    
    @property
    def scheme(self):
        return self._scheme
    
    @property
    def path(self):
        return self._path
    
    @property
    def uri(self):
        return
        urllib.urlparse.urljoin(str(self._scheme) + ':', urllib.request.pathname2url(self._path))


class DataFrame(object, metaclass=MetaDataType):
    string_rep = 'datatype.dataframe'
    _dtype_map = {'float64': 'float', 'int64': 'int', 'object': 'object', 'float32': 'float', 'int32': 'int', 'category': 'category', 'bool':'bool'}

    def __init__(self, X, y=None, domain=None, parent_widget=None, source_adfs=None, match_index=True):
        '''
        Wraps Pandas dataframe and provides easy serialization to dict for json schema

        Parameters
        ----------
        X : pandas.DataFrame
            The independent variable(s)
        y : pandas.Series
            The dependent variable
        domain : Domain enum
            Machine learning domain. Use the enumerations provided by the Domain class
        parent_widget : BaseWidget child
            The widget which created this DataFrame 
        source_adfs : Sequence of DataFrame objects
            The source DataFrame objects used to create this DataFrame
        '''
        if parent_widget is None:
            lineage = list()
            domain = Domain.NONE if domain is None else domain
        else:
            if not isinstance(parent_widget, BaseWidget):
                raise DataTypeException('Parent widget must derive from BaseWidget class')
            lin_node = LineageNode(parent_widget, self)
            if source_adfs is None:
                lineage = [lin_node]
                domain = Domain.NONE if domain is None else domain
            else:
                try:
                    source_adfs = tuple(source_adfs)
                except TypeError:
                    source_adfs = (source_adfs,)
                source_adf = source_adfs[0]
                domain = source_adf.domain if domain is None else domain
                y = source_adf.y if y is None else y
                if len(source_adfs) == 1:
                    if match_index and not source_adf.X.index.equals(X.index):
                        raise DataTypeException('An index mismatch occurred when creating a new DataFrame')
                    lineage = list(source_adf.lineage)
                    lineage.append(lin_node)
                else:
                    if match_index and not all(adf.X.index.equals(X.index) for adf in source_adfs):
                        raise DataTypeException('An index mismatch occurred when creating a new DataFrame')
                    if not all(adf.domain is source_adf.domain for adf in source_adfs):
                        raise DataTypeException('Multiple different domains introduced in the joining of dataframes')
                    if not all(adf.y is source_adf.y for adf in source_adfs):
                        raise DataTypeException('Multiple different targets introduced in the joining of dataframes')
                    lineage = [tuple(adf.lineage for adf in source_adfs), lin_node]
        if not isinstance(X, pd.DataFrame):
            raise DataTypeException('X must be a Pandas DataFrame')
        if not ((isinstance(y, pd.Series) and y.name) or y is None):
            raise DataTypeException('y must be a named Pandas Series')
        if not isinstance(domain, Domain):
            raise DataTypeException('domain must be a Domain enum')
        self._X = X
        self._y = y
        self._domain = domain
        self._lineage = lineage


    @property
    def signature(self):
        return self._X.convert_objects().dtypes

    @property
    def lineage(self):
        return self._lineage.copy()

    @property
    def domain(self):
        return self._domain

    @property
    def dtype_set(self):
        return set(DataFrame._dtype_map[str(self.X[column].dtype)] for column in self.X)
    
    @property
    def structure(self):
        if isinstance(self.X, pd.DataFrame):
            return 'dense'
        elif isinstance(self.X, pd.SparseDataFrame):
            return 'sparse'
        else:
            raise DataTypeException("X is invalid type: {:}".format(type(self.X)))

    @property
    def X(self):
        return self._X

    @property
    def y(self):
        return self._y

    def to_dict(self, subset=None):
        '''
        Returns a dict representation of the dataframe for easy JSON serialization
        '''
        X_sample = self._X if subset is None else self._X.sample(n=subset, axis=0)
        X_sample = X_sample.where(pd.notnull(X_sample), None)
        X_value = dict(zip(X_sample.index.astype(str), X_sample.as_matrix().tolist()))
        X_meta = {'name': list(self._X.columns.astype(str)), 'dtype': [DataFrame._dtype_map[str(dtype)] for dtype in self._X.dtypes]}
        
        if self._y is None:
            y_meta = None
            y_value = None
        else:
            y_meta = {'name': self._y.name, 'dtype': DataFrame._dtype_map[str(self._y.dtype)]}
            y_sample = self._y.loc[X_sample.index]
            y_value = y_sample.as_matrix().tolist()

        return {'type': 'dataframe',
                'meta': {'structure': self.structure,
                         'dtypes': list(self.dtype_set),
                         'domain': str(self.domain)},
                'X': {'meta': X_meta,
                      'value': X_value},
                'y': {'meta': y_meta,
                      'value': y_value}}


class LineageNode(object):
    '''
    Object representing a widget's participation in a dataframe's lineage
    '''
    def __init__(self, widget, dataframe):
        if not isinstance(widget, BaseWidget):
            raise DataTypeException('widget parameter must derived from BaseWidget')
        if not isinstance(dataframe, DataFrame):
            raise DataTypeException('dataframe parameter must be an ASIMOV DataFrame')
        self._widget = weakref.proxy(widget)
        self._dataframe = weakref.proxy(dataframe)
    
    @property
    def widget(self):
        return self._widget
    
    @property
    def dataframe(self):
        return self._dataframe
    
    @property
    def widget_deref(self):
        return self._widget.__repr__.__self__
