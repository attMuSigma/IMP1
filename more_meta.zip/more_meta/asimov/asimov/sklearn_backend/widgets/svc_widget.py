# -*- coding: utf-8 -*-
"""
Provides the SVC widget class
"""
from sklearn.svm import SVC

import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.parameters import Parameter, EnumArg, IntArg, FloatArg, BoolArg


class SvcWidget(BaseWidget):
    _widget_id = 'supervised.svc'

    def _initialize(self):
        self._estimator = SVC(random_state=0)

    def _update_ports(self):
        '''
        Creates this widget's ports
        '''
        self._source_ports[0] = SourcePort(self._widget_uid, 0, adt.Estimator, 'Estimator')

    def _update_static_parameters(self):
        self._parameters.update({'C': Parameter([FloatArg(1.0)]),
                                 'kernel': Parameter([EnumArg('rbf', ['linear', 'poly', 'rbf', 'sigmoid'])]),
                                 'degree': Parameter([IntArg(3)]),
                                 'gamma': Parameter([FloatArg(0.0)]),
                                 'coef0': Parameter([FloatArg(0.0)]),
                                 'shrinking': Parameter([BoolArg(True)]),
                                 'tol': Parameter([FloatArg(1e-3)]),
                                 'class_weight': Parameter([EnumArg(None, [None, 'auto'])]),
                                 'max_iter': Parameter([IntArg(-1)]),
                                 'randomize': Parameter([BoolArg(False)])})

    def _evaluate(self):
        '''
        Creates a new estimator from the current parameters
        '''
        params = {name: arg.value for name, arg in self._parameters.items()}
        params['random_state'] = None if params['randomize'] else 0
        del params['randomize']
        self._estimator.set_params(**params)
        self._source_ports[0].data = adt.Classifier("svc-{:}".format(self._widget_uid), self._estimator)

    def _update_attributes(self):
        '''
        This widget has no attributes
        '''

    def _update_dynamic_parameters(self):
        '''
        This widget has no dynamic parameters
        '''
