# -*- coding: utf-8 -*-
"""
Provides PCA widget class
"""
import random
from . import data_types as adt
from .attributes import DataFrameAttribute
from .draft_widget import BaseWidget
from .sink_port import SingleSink
from .sink_port import SinkException
from .parameters import Parameter
from .parameters import IntArg
from .parameters import BoolArg


class SamplerWidget(BaseWidget):
    _widget_id = 'data.dataframe_sampler'

    def _initialize(self):
        self._max_sample = 100
        self._samples_adf = None

    def _update_ports(self):
        '''
        Creates this widget's ports
        '''
        self._sink_ports[0] = SingleSink(self._widget_uid, 0, adt.DataFrame)

    def _update_static_parameters(self):
        '''
        Safely initializes the static parameters
        '''
        sample_size = Parameter([IntArg(50)])
        randomize = Parameter([BoolArg(False)])
        self._parameters.update({'sample_size': sample_size, 'randomize': randomize})

    def _update_attributes(self):
        '''
        Updates the samples attribute
        '''
        self._attributes['samples'] = DataFrameAttribute(self._samples_adf)

    def _update_dynamic_parameters(self):
        '''
        This widget has no dynamic parameters
        '''

    def _evaluate(self):
        '''
        Samples the input dataframe and stores the samples as an attribute
        '''
        try:
            input_pdf = self._sink_ports[0].data.X
            sample_size = min(self._parameters['sample_size'].value, input_pdf.shape[0])
            sample_size = self._max_sample if sample_size > self._max_sample else sample_size
            if self._parameters['randomize'].value:
                indexes = random.sample(list(input_pdf.index), sample_size)
            else:
                indexes = list(input_pdf.index)[:sample_size]
            sample_pdf = input_pdf.ix[indexes]
            self._samples_adf = adt.DataFrame(sample_pdf)
        except SinkException:
            self._samples_adf = None
            raise
