# -*- coding: utf-8 -*-
"""
Provides a class for dropping columns from a dataframe
"""
import numpy as np
import pandas as pd
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.draft_widget import WidgetException
from asimov.sklearn_backend.widgets.draft_widget import TransformWidget
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.sink_port import DataUnavailable
from asimov.sklearn_backend.widgets.sink_port import SingleSink
from asimov.sklearn_backend.widgets.sink_port import NotConnected
from asimov.sklearn_backend.widgets.parameters import Parameter
from asimov.sklearn_backend.widgets.parameters import ListArg
from sklearn.base import BaseEstimator
from sklearn.base import TransformerMixin


class DropColumn(BaseEstimator, TransformerMixin):
    '''
    sklearn estimator which drops specified columns from a Pandas dataframe
    '''
    def __init__(self, drop_cols=None):
        super().__init__()
        self.drop_cols = list() if drop_cols is None else drop_cols

    def fit(self, X=None, y=None):
        return self

    def transform(self, X, y=None):
        if isinstance(X, pd.DataFrame):
            X = X.as_matrix()
        elif not isinstance(X, np.ndarray):
            raise TypeError('Input to DropColumn should be a numpy ndarray or pandas DataFrame')
        return X if not self.drop_cols else np.delete(X, self.drop_cols, axis=1)


class DropColumnWidget(TransformWidget):
    _widget_id = 'data.drop_column'

    def _initialize(self):
        self._estimator = DropColumn()

    def _update_ports(self):
        self._sink_ports[0] = SingleSink(self._widget_uid, 0, adt.DataFrame)
        self._source_ports[0] = SourcePort(self._widget_uid, 0, adt.DataFrame)

    def _update_static_parameters(self):
        '''
        This widget has no static parameters
        '''
    
    def _update_attributes(self):
        '''
        This widget has no attributes
        '''
    
    def _fit(self):
        '''
        Updates the internal estimator with current parameters
        '''
        try:
            input_adf = self._sink_ports[0].data
            input_pdf = input_adf.X
            index_lookup = {name: index for index, name in enumerate(input_pdf.columns)}
            try:
                drop_indexes = [index_lookup[name] for name in self._parameters['drop_cols'].value]
            except KeyError as e:
                raise WidgetException("Specified column '{:}' not found in input DataFrame".format(e))
            self._estimator.set_params(drop_cols=drop_indexes)
        except:
            self._estimator.set_params(drop_cols=list())
        
        
    def _transform(self):
        '''
        Transforms sink port data and places it on source port
        '''
        input_adf = self._sink_ports[0].data
        input_pdf = input_adf.X
        input_nd = input_pdf.values
        drop_cols = set(self._estimator.drop_cols)
        output_cols = [name for index, name in enumerate(input_pdf.columns) if index not in drop_cols]
        output_nd = self._estimator.fit_transform(input_nd)
        output_pdf = pd.DataFrame(output_nd, columns=output_cols, index=input_pdf.index)
        output_adf = adt.DataFrame(output_pdf, parent_widget=self, source_adfs=input_adf)
        self._source_ports[0].data = output_adf

    def _update_dynamic_parameters(self):
        '''
        Updates the drop_cols parameter.
        
        When updating, this takes the intersection of the existing dropped columns
        and the available columns of the input pd.DataFrame. This allows us to maintain
        a prexisting valid selection provided by the user
        '''
        try:
            input_cols = list(self._sink_ports[0].data.X.columns)
            current_cols = set(self._parameters['drop_cols'].value)
            dynamic_cols = list(current_cols.intersection(input_cols))
            drop_param = Parameter([ListArg(list(), input_cols)], dynamic_cols)
        except (DataUnavailable, NotConnected):
            drop_param = Parameter([ListArg(list(), list())])
        self._parameters['drop_cols'] = drop_param
