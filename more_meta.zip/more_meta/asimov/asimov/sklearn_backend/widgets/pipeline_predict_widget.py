# -*- coding: utf-8 -*-
"""
Provides Pipeline Predict Widget
"""
import pandas as pd
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget, WidgetException, EvaluationError
from asimov.sklearn_backend.widgets.sink_port import SingleSink
from asimov.sklearn_backend.widgets.source_port import SourcePort


class PipelinePredictWidget(BaseWidget):
    _widget_id = 'evaluation.pipeline_predict'

    def _initialize(self):
        '''
        This widget has no unique initialization routine
        '''

    def _update_ports(self):
        '''
        Creates this widget's ports
        '''
        self._sink_ports[0] = SingleSink(self._widget_uid, 0, adt.DataFrame, name='DataFrame')
        self._sink_ports[1] = SingleSink(self._widget_uid, 1, adt.Pipeline, name='Pipeline')
        self._source_ports[0] = SourcePort(self._widget_uid, 0, adt.Prediction, name='Predictions')

    def _update_static_parameters(self):
        '''
        This widget has no static parameters
        '''

    def _evaluate(self):
        '''
        Checks sink port for file resource, then its parameters. Finally reads the CSV.
        '''
        # read sink ports and verify data
        dataframe_adt = self._sink_ports[0].data
        pipeline_adt = self._sink_ports[1].data
        if dataframe_adt.domain is adt.Domain.NONE:
            raise WidgetException('DataFrame must have its domain and target specified')
        if pipeline_adt.domain is not dataframe_adt.domain:
            raise WidgetException('Pipeline domain and DataFrame domain do not match')
        if not pipeline_adt.signature.equals(dataframe_adt.signature):
            raise WidgetException('DataFrame signature does not match the Pipeline signature')
        # generate predictions
        pipeline_sk = pipeline_adt.estimator
        dataframe_pdf = dataframe_adt.X
        y = dataframe_adt.y
        try:
            y_pred = pipeline_sk.predict(dataframe_pdf)
        except Exception as e:
            raise EvaluationError("Prediction failure: {:}".format(e)).with_traceback(e.__traceback__)
        if pipeline_adt.domain is adt.Domain.CLASSIFICATION:
            y_pred_proba = pipeline_sk.predict_proba(dataframe_pdf)
            predictions = pd.DataFrame({'prediction': y_pred, 'probability': y_pred_proba.tolist(), 'target': y, 'fold': 0})
        else:
            predictions = pd.DataFrame({'prediction': y_pred, 'target': y, 'fold': 0})
        # write predictions to source port
        adt_predictions = adt.Prediction(predictions, pipeline_adt.name, pipeline_adt.domain, pipeline_adt.classes)
        self._source_ports[0].data = adt_predictions

    def _update_attributes(self):
        '''
        This widget has no attributes
        '''

    def _update_dynamic_parameters(self):
        '''
        This widget has no dynamic parameters
        '''
