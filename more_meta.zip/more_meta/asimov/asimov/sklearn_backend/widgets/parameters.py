# -*- coding: utf-8 -*-
"""
Provides parameter and argument classes
"""


class ParameterException(Exception):
    pass


class Parameter(object):
    def __init__(self, options, value=None):
        self._state = {'options': options, 'value': value if value is not None else options[0].value}
        self._types = set()
        for param in options:
            param_type = {type(param.value), }
            param_opt_types = {type(param_opt) for param_opt in param.options} if param.options is not None else set()
            self._types.update(param_type.union(param_opt_types))

    def to_dict(self):
        state_copy = self._state.copy()
        state_copy['options'] = [option.to_dict() for option in state_copy['options']]
        return state_copy
    
    @property
    def options(self):
        return self._state['options'].copy()
    
    @property
    def value(self):
        return self._state['value']
    
    @value.setter
    def value(self, val):
        val = self._safe_cast(val)
        if type(val) not in self._types:
            raise ParameterException("Specified type '{:}' invalid for type set {:}".format(type(val).__name__, {elem.__name__ for elem in self._types}))
        self._state['value'] = val

    def _safe_cast(self, value):
        '''
        Tries to infer the value type and returns a casted version of it
        '''
        if type(value) is int and int not in self._types and float in self._types:
            return float(value)
        else:
            return value


class Argument(object):
    def __init__(self, default_value=None):
        self._state = {'default_value': default_value}

    def to_dict(self):
        return self._state.copy()

    @property
    def options(self):
        if 'options' not in self._state:
            return None
        else:
            return self._state['options'].copy()

    @property
    def value(self):
        return self._state.get('default_value', None)

    def __str__(self):
        return str(self._state)


class IntArg(Argument):
    def __init__(self, default_value):
        super(IntArg, self).__init__(default_value)
        self._state['dtype'] = 'int'


class NoneArg(Argument):
    def __init__(self):
        super(NoneArg, self).__init__(None)
        self._state['dtype'] = 'null'

class FloatArg(Argument):
    def __init__(self, default_value):
        super(FloatArg, self).__init__(default_value)
        self._state['dtype'] = 'float'


class BoolArg(Argument):
    def __init__(self, default_value):
        super(BoolArg, self).__init__(default_value)
        self._state['dtype'] = 'bool'


class ListArg(Argument):
    def __init__(self, default_value, options):
        super(ListArg, self).__init__(default_value)
        self._state['dtype'] = 'list'
        self._state['options'] = options


class EnumArg(Argument):
    def __init__(self, default_value, options):
        super(EnumArg, self).__init__(default_value)
        self._state['dtype'] = 'enum'
        self._state['options'] = options


class StringArg(Argument):
    def __init__(self, default_value):
        super(StringArg, self).__init__(default_value)
        self._state['dtype'] = 'string'


class DictArg(Argument):
    def __init__(self, default_value, options):
        super(DictArg, self).__init__(default_value)
        self._state['dtype'] = 'dict'
        self._state['options'] = options


class LinRangeArg(Argument):
    def __init__(self):
        super(LinRangeArg, self).__init__()
        self._state['dtype'] = 'lin_range'


class ExpRangeArg(Argument):
    def __init__(self):
        super(ExpRangeArg, self).__init__()
        self._state['dtype'] = 'exp_range'


class EnumRangeArg(Argument):
    def __init__(self, options):
        super(EnumRangeArg, self).__init__(list())
        self._state.update({'dtype': 'enum_range',
                            'options': options})

if __name__ == '__main__':
    '''
    Test area
    '''
