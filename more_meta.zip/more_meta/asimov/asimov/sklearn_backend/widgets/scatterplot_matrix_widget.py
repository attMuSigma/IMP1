# -*- coding: utf-8 -*-
"""
Provides a class for dropping columns from a dataframe
"""
import io
import base64
import seaborn as sns
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget
from asimov.sklearn_backend.widgets.draft_widget import WidgetException
from asimov.sklearn_backend.widgets.sink_port import DataUnavailable
from asimov.sklearn_backend.widgets.sink_port import SingleSink
from asimov.sklearn_backend.widgets.sink_port import NotConnected
from asimov.sklearn_backend.widgets.parameters import Parameter
from asimov.sklearn_backend.widgets.parameters import ListArg
from asimov.sklearn_backend.widgets.attributes import StringAttribute


class ScatterplotMatrixWidget(BaseWidget):
    _widget_id = 'viz.scatterplot_matrix'

    def _initialize(self):
        self._plot_str = None

    def _update_ports(self):
        self._sink_ports[0] = SingleSink(self._widget_uid, 0, adt.DataFrame)

    def _update_static_parameters(self):
        '''
        Initializes static parameters to safe values
        '''
        columns = Parameter([ListArg(list(), list())])
        self._parameters['columns'] = columns
    
    def _evaluate(self):
        '''
        Creates the graphic and stores as an attribute
        '''
        try:
            input_adf = self._sink_ports[0].data
            columns = self._parameters['columns'].value
            if not columns:
                raise WidgetException('No features were selected for plotting')
            self._plot_str = self._create_plot(input_adf, columns)
        except:
            self._plot_str = None
            raise
    
    def _create_plot(self, input_adf, columns):
        '''
        Returns a base64 encoded string of the plot
        '''
        pdf = input_adf.X[columns]
        target = input_adf.y
        if target is not None:
            if not target.name:
                raise WidgetException('DataFrame target is missing a name')
            target_pretty = target.apply(lambda x: "Class {:}".format(x))
            pdf[target.name] = target_pretty
        try:
            fig = sns.pairplot(pdf, hue=target.name) if input_adf.domain is adt.Domain.CLASSIFICATION else sns.pairplot(pdf)
        except Exception as e:
            raise WidgetException("Error plotting features {:}: {:}. Ensure data is numerical.".format(columns, e))
        image_data = io.BytesIO()
        fig.savefig(image_data, format='png')
        return base64.encodebytes(image_data.getvalue()).decode()
        
    def _update_attributes(self):
        '''
        Add the string encoded plot as an attribute
        '''
        self._attributes['plot'] = StringAttribute(self._plot_str)

    def _update_dynamic_parameters(self):
        '''
        Updates the available columns from the input data
        '''
        try:
            input_cols = list(self._sink_ports[0].data.X.columns)
            current_cols = set(self._parameters['columns'].value)
            dynamic_cols = list(current_cols.intersection(input_cols))
            columns = Parameter([ListArg(dynamic_cols, input_cols)])
        except (DataUnavailable, NotConnected):
            columns = Parameter([ListArg(list(), list())])
        self._parameters['columns'] = columns

    def is_evaluated(self):
        '''
        Overrides the base method because evaluation is different for this widget
        '''
        if self._attributes['plot'].value is None:
            return False
        else:
            return True
