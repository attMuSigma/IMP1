# -*- coding: utf-8 -*-
"""
Provides the pass estimator
"""
import pandas as pd
from sklearn.base import BaseEstimator
from sklearn.base import TransformerMixin
from asimov.sklearn_backend.widgets.draft_widget import TransformWidget


class PassEstimator(BaseEstimator, TransformerMixin):
    '''
    Valid sklearn estimator which simply passes the input data through
    '''
    def fit(self, X=None, y=None):
        return self

    def transform(self, X, y=None):
        return X.values if isinstance(X, pd.DataFrame) else X


class PassWidget(TransformWidget):
    '''
    Dummy class which is currently only used to extract its estimator
    '''

    def __init__(self, wid, wuid):
        self._widget_id = wid
        super().__init__(wuid)

    def _initialize(self):
        self._estimator = PassEstimator()

    def _update_static_parameters(self):
        pass
    def _update_dynamic_parameters(self):
        pass
    def _update_ports(self):
        pass
    def _fit(self):
        pass
    def _transform(self):
        pass
    def _update_attributes(self):
        pass
