# -*- coding: utf-8 -*-
"""
Provides a mock source widget
"""
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget
from asimov.sklearn_backend.widgets.source_port import SourcePort


class MockAdfSourceWidget(BaseWidget):
    _widget_id = 'mock_source'

    def __init__(self, X, y, domain):
        super().__init__(0)
        self._source_ports[0] = SourcePort(0, 0, adt.DataFrame)
        self._source_ports[0].data = adt.DataFrame(X, y, domain, self)

    def _update_attributes(self):
        pass
    def _update_ports(self):
        pass
    def _update_static_parameters(self):
        pass
    def _update_dynamic_parameters(self):
        pass
    def _evaluate(self):
        pass
    def _initialize(self):
        pass


class MockSourceWidget(BaseWidget):
    def __init__(self, wid, wuid):
        self._widget_id = wid
        super().__init__(wuid)
    def _update_static_parameters(self):
        pass
    def _update_dynamic_parameters(self):
        pass
    def _update_ports(self):
        pass
    def _fit(self):
        pass
    def _transform(self):
        pass
    def _evaluate(self):
        pass
    def _update_attributes(self):
        pass
    def _initialize(self):
        pass
