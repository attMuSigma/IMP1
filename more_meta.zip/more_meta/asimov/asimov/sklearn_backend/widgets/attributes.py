# -*- coding: utf-8 -*-
"""
Provides parameter and argument classes
"""


class Attribute(object):
    def __init__(self, dtype, value):
        self._state = {'dtype': dtype, 'value': value}

    def to_dict(self):
        '''
        Attempts to convert the value to dict in the event it is a special object
        '''
        try:
            copy = self._state.copy()
            copy['value'] = copy['value'].to_dict()
        except AttributeError:
            pass
        finally:
            return copy

    @property
    def value(self):
        return self._state['value']


class IntAttribute(Attribute):
    def __init__(self, value=None):
        super().__init__('int', value)


class FloatAttribute(Attribute):
    def __init__(self, value=None):
        super().__init__('float', value)


class StringAttribute(Attribute):
    def __init__(self, value=None):
        super().__init__('string', value)


class BoolAttribute(Attribute):
    def __init__(self, value=None):
        super().__init__('bool', value)

class ListAttribute(Attribute):
    def __init__(self, value=None):
        super().__init__('list', list() if value is None else value)

class DataFrameAttribute(Attribute):
    def __init__(self, value=None):
        super().__init__('dataframe', value)
