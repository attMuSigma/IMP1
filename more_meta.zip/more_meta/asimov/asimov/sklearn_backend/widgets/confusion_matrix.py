"""
Returns the confusion matrix plot
"""
import io
import base64

import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix


def fig_to_str(figure):
    '''
    Converts figure to base64 encoded PNG
    '''
    image_data = io.BytesIO()
    figure.savefig(image_data, format='png')
    encoded_str = base64.encodebytes(image_data.getvalue()).decode()
    return encoded_str


def create_confusion_matrix_plot(target, prediction, classes, normalize):
    '''
    Returns a confusion matrix plot
    '''
    # create confusion matrix
    cm = confusion_matrix(target, prediction, labels=classes)
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    # create plot
    np.set_printoptions(precision=2)
    fig, ax = plt.subplots()
    cmap=plt.cm.Blues
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title('Confusion Matrix')
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)
    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    return fig, ax


def create_encoded_confusion_matrix_plot(pred_adt, normalize):
    '''
    Returns a string-encoded confusion matrix plot
    '''
    # extract predictions
    pred_pdf = pred_adt.predictions
    classes = pred_adt.classes
    target_nd = pred_pdf['target'].values
    pred_nd = pred_pdf['prediction'].values
    # create and encode plot 
    fig, ax = create_confusion_matrix_plot(target_nd, pred_nd, classes, normalize)
    return fig_to_str(fig)
