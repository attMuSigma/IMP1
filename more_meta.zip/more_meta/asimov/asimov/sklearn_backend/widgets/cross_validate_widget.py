# -*- coding: utf-8 -*-
"""
Provides the estimator evaluator widget
"""
import multiprocessing
import numpy as np
import pandas as pd
import sklearn.cross_validation as scv
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget
from asimov.sklearn_backend.widgets.draft_widget import WidgetException
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.sink_port import SingleSink
from asimov.sklearn_backend.widgets.parameters import Parameter
from asimov.sklearn_backend.widgets.parameters import IntArg
from asimov.sklearn_backend.widgets.parameters import BoolArg
from asimov.sklearn_backend.utils import lineage as lin
from asimov.sklearn_backend.utils.cross_val_predict import cross_val_predict


class CrossValidateWidget(BaseWidget):
    _widget_id = 'evaluation.cross_validate'

    def _update_ports(self):
        for port_id, sink_type, port_type, port_name in ((0, SingleSink, adt.DataFrame, 'DataFrame'),
                                                         (1, SingleSink, adt.Estimator, 'Estimator')):
            self._sink_ports[port_id] = sink_type(self._widget_uid, port_id, port_type, port_name)
        for port_id, port_type, port_name in ((0, adt.Prediction, 'Predictions'),
                                              (1, adt.Pipeline, 'Pipeline')):
            self._source_ports[port_id] = SourcePort(self._widget_uid, port_id, port_type, port_name)

    def _update_static_parameters(self):
        '''
        Initializes the static parameters safely
        '''
        self._parameters.update({'nfolds': Parameter([IntArg(3)]),
                                 'shuffle': Parameter([BoolArg(False)]),
                                 'randomize': Parameter([BoolArg(False)])})

    def _evaluate(self):
        '''
        Trains the input estimator object on training set and computes metrics
        '''
        adf = self._sink_ports[0].data
        estimator = self._sink_ports[1].data
        self._verify_estimator(adf.domain, estimator)
        try:
            adt_predictions, adt_pipeline = self._cross_validate(adf, estimator)
        except WidgetException:
            raise
        except Exception as e:
            self._reraise(e)
        self._source_ports[0].data = adt_predictions
        self._source_ports[1].data = adt_pipeline

    def _verify_estimator(self, domain, estimator):
        '''
        Raises if the provided estimator does not match the data domain
        '''
        if domain is adt.Domain.CLASSIFICATION:
            if not isinstance(estimator, adt.Classifier):
                raise WidgetException('Data domain is classification but input estimator was not a classifier')
        elif domain is adt.Domain.REGRESSION:
            if not isinstance(estimator, adt.Regressor):
                raise WidgetException('Data domain is regression but input estimator was not a regressor')
        else:
            raise WidgetException('Data did not specify a domain')
    
    def _cross_validate(self, adf, adt_estimator):
        '''
        Cross validates an estimator and returns scores
        '''
        if (adf.signature == np.object).any():
            raise WidgetException('Only numerical data is supported. Remove complex data such as strings')
        try:
            transforms = lin.extract_pipeline(adf.lineage)
            source_adf = lin.extract_source_adf(adf.lineage)
        except lin.LineageBreak as e:
            raise WidgetException("Non-transformer widget {:} breaks the transformer pipeline. Move it upstream or remove it.".format(e))
        except lin.LineageException as e:
            raise WidgetException("The input transformer pipeline is malformed: {:}".format(e))
        cv_params = self._get_cv_params()
        if source_adf.domain is adt.Domain.CLASSIFICATION:
            return self._class_cv(source_adf, transforms, adt_estimator, cv_params)
        else:
            return self._reg_cv(source_adf, transforms, adt_estimator, cv_params)
    
    def _get_cv_params(self):
        '''
        Returns a dictionary of parameters for cross validation
        '''
        return {'shuffle': self._parameters['shuffle'].value,
                'n_folds': self._parameters['nfolds'].value,
                'random_state': None if self._parameters['randomize'].value else 0}

    def _class_cv(self, source_adf, transforms, adt_estimator, cv_params):
        '''
        Performs cross validation for classification
        '''
        # setup cross validation objects
        X, y = source_adf.X.values, source_adf.y.values
        cv =  scv.StratifiedKFold(y, **cv_params)
        classifier = adt_estimator.estimator
        try:
            classifier.set_params(probability=True)
        except ValueError:
            pass
        
        sk_pipeline = adt.Pipeline.create_scikit_pipeline(transforms, classifier, adt_estimator.name)
        # create prediction results
        n_jobs = multiprocessing.cpu_count()
        try:
            y_pred, y_pred_proba = cross_val_predict(sk_pipeline, X, y, cv=cv, n_jobs=n_jobs, predict_function=['predict', 'predict_proba'])     
        except Exception as e:
            raise WidgetException("Cross validation failure: {:}".format(e))
        predictions = pd.DataFrame({'prediction': y_pred, 'probability': y_pred_proba.tolist(), 'target': y})
        predictions['fold'] = pd.concat([pd.Series(data=fold_index, index=cv_idx) for fold_index, (_, cv_idx) in enumerate(cv)])
        # retrain pipeline on all data and return
        sk_pipeline.fit(X, y)
        adt_predictions = adt.Prediction(predictions, adt_estimator.name, source_adf.domain, sk_pipeline.classes_)
        adt_pipeline = adt.Pipeline(adt_estimator.name, sk_pipeline, source_adf.domain, source_adf.signature)
        return adt_predictions, adt_pipeline

    def _reg_cv(self, source_adf, transforms, adt_estimator, cv_params):
        '''
        Performs cross validation for regression
        '''
        # setup cross validation objects
        X, y = np.array(source_adf.X), source_adf.y
        cv =  scv.KFold(y, **cv_params)
        n_jobs = multiprocessing.cpu_count()
        sk_pipeline = adt.Pipeline.create_scikit_pipeline(transforms, adt_estimator.estimator, adt_estimator.name)
        # create prediction results
        try:
            y_pred = cross_val_predict(sk_pipeline, X, y, cv=cv, n_jobs=n_jobs)
        except Exception as e:
            raise WidgetException("Cross validation failure: {:}".format(e))
        predictions = pd.DataFrame({'prediction': y_pred, 'target': y})
        predictions['fold'] = pd.concat([pd.Series(data=fold_index, index=cv_idx) for fold_index, (_, cv_idx) in enumerate(cv)])
        # retrain pipeline on all data and return
        sk_pipeline.fit(X, y)
        adt_predictions = adt.Prediction(predictions, adt_estimator.name, source_adf.domain)
        adt_pipeline = adt.Pipeline(adt_estimator.name, sk_pipeline, source_adf.domain, source_adf.signature)
        return adt_predictions, adt_pipeline

    def _update_attributes(self):
        '''
        This widget has no attributes
        '''

    def _update_dynamic_parameters(self):
        '''
        This widget has no dynamic parameters
        '''
    
    def _initialize(self):
        '''
        This widget has no unique initialization routine
        '''

