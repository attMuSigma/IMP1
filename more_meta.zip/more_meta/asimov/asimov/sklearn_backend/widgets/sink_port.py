# -*- coding: utf-8 -*-
"""
Provides the sink port class
"""
class SinkException(Exception):
    pass


class DataUnavailable(SinkException):
    pass


class NotConnected(SinkException):
    pass


class InvalidSource(SinkException):
    pass


class SinkPort(object):
    '''
    Base class for single and multi sink ports
    '''
    def __init__(self, widget_uid, port_id, name, dtype):
        self._widget_uid = widget_uid        
        self._port_id = port_id
        self._name = name
        self._dtype = dtype
    
    @property
    def widget_uid(self):
        return self._widget_uid

    @property
    def port_id(self):
        return self._port_id

    @property
    def name(self):
        return self._name
    
    @property
    def dtype(self):
        return self._dtype

    def add_source(self, widget_uid, port_id, port):
        raise NotImplementedError()
    
    def remove_source(self, widget_uid, port_id):
        raise NotImplementedError()

    @property
    def data(self):
        raise NotImplementedError()

    def to_dict(self):
        return {'widget_uid': self.widget_uid,
                'port_id': self.port_id,
                'name': self.name,
                'dtype': str(self.dtype)}
    
    def _verify_compatible(self, source_port):
        '''
        Raises if the source port is not compatible with this sink port
        '''
        if not issubclass(source_port.dtype, self._dtype):
            raise InvalidSource("Source port of type {:} is incompatible with sink type {:}".format(source_port.dtype, self._dtype))


class SingleSink(SinkPort):
    '''
    Sink sink port implementation
    '''
    def __init__(self, widget_uid, port_id, dtype, name='Input Data'):
        super().__init__(widget_uid, port_id, name, dtype)
        self._update_source()

    def _update_source(self, widget_uid=None, port_id=None, port=None):
        '''
        Convenience method for safely funneling modification of source state
        '''
        self._source = {'widget_uid': widget_uid, 'port_id': port_id, 'port': port}

    def add_source(self, source_port):
        '''
        Attempts to add a new source input and subscribes to its controls
        '''
        self._verify_compatible(source_port)
        if self._source['port'] is not None:
            raise SinkException('Can only have one source at a time')
        self._update_source(source_port.widget_uid, source_port.port_id, source_port)
    
    def remove_source(self, source_port):
        '''
        Removes a source and unsubscribes from its controls
        '''
        if not (self._source['widget_uid'], self._source['port_id']) == (source_port.widget_uid, source_port.port_id):
            raise SinkException('Connection does not exist')
        self._update_source()
    
    @property
    def data(self):
        '''
        Attempts to return the data provided by the connected source port's read() method
        '''
        if self._source['port'] is None: 
            raise NotConnected("Port {:} is not connected to a {:} source".format(self._name, self._dtype))
        if not self._source['port'].has_data():
            raise DataUnavailable("Port {:} has no {:} data available".format(self._name, self._dtype))
        return self._source['port'].data

    def to_dict(self):
        base_dict = super().to_dict()
        source_dict = None if self._source['widget_uid'] is None else {'widget_uid': self._source['widget_uid'], 'port_id': self._source['port_id']}
        base_dict.update({'type': 'single', 'source': source_dict})
        return base_dict


class MultiSink(SinkPort):
    '''
    Multiple sink port implementation
    '''
    def __init__(self, widget_uid, port_id, dtype, name='Input Data'):
        super().__init__(widget_uid, port_id, name, dtype)
        self._sources = dict()
    
    def add_source(self, source_port):
        '''
        Attempts to add a new source input and subscribes to its controls
        '''
        self._verify_compatible(source_port)
        source_key = (source_port.widget_uid, source_port.port_id)
        if source_key in self._sources:
            raise SinkException("Add source failure. Source {:} already exists".format(source_key))
        self._sources[source_key] = source_port
    
    def remove_source(self, source_port):
        '''
        Removes a source and unsubscribes from its controls
        '''
        source_key = (source_port.widget_uid, source_port.port_id,)
        if source_key not in self._sources:
            raise SinkException("Remove source failure. Source {:} does not exist".format(source_key))
        del self._sources[source_key]

    @property
    def data(self):
        '''
        Returns a dict containing each source widget's data
        '''
        if not self._sources:
            raise NotConnected("Port {:} is not connected to any {:} sources".format(self._name, self._dtype))
        if not all(source.has_data() for source in self._sources.values()):
            raise DataUnavailable("Port {:} is connected to one or more {:} sources with unavailable data".format(self._name, self._dtype))
        return {source_key: source_port.data for source_key, source_port in self._sources.items()}

    def to_dict(self):
        base_dict = super().to_dict()
        source_list = list() if not self._sources else [{'widget_uid': widget_uid, 'port_id': port_id} for widget_uid, port_id in self._sources.keys()]
        base_dict.update({'type': 'multiple', 'source': source_list})
        return base_dict
    
    def _create_dict(self):
        '''
        Convience method which returns a dict of sources for this sink
        '''
        