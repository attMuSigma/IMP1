# -*- coding: utf-8 -*-
"""
Provides a class for dropping columns from a dataframe
"""
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget
from asimov.sklearn_backend.widgets.draft_widget import WidgetException
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.sink_port import DataUnavailable
from asimov.sklearn_backend.widgets.sink_port import SingleSink
from asimov.sklearn_backend.widgets.sink_port import NotConnected
from asimov.sklearn_backend.widgets.parameters import Parameter
from asimov.sklearn_backend.widgets.parameters import EnumArg


class SelectTargetWidget(BaseWidget):
    _widget_id = 'data.select_target'

    def _initialize(self):
        '''
        This widget has no unique initialization routine
        '''

    def _update_ports(self):
        self._sink_ports[0] = SingleSink(self._widget_uid, 0, adt.DataFrame, name='Unlabeled DataFrame')
        self._source_ports[0] = SourcePort(self._widget_uid, 0, adt.DataFrame, name='Labeled DataFrame')

    def _update_static_parameters(self):
        '''
        Initializes static parameters to safe values
        '''
        self._parameters.update({'target': Parameter([EnumArg(None, list())]),
                                 'domain': Parameter([EnumArg(None, [str(adt.Domain.CLASSIFICATION), str(adt.Domain.REGRESSION)])])})
    
    def _update_attributes(self):
        '''
        This widget has no attributes
        '''
        
    def _evaluate(self):
        '''
        Transforms sink port data and places it on source port
        '''
        # read input parameters
        input_adf = self._sink_ports[0].data
        target = self._parameters['target'].value
        domain_str = self._parameters['domain'].value
        if not target:
            raise WidgetException('A target must be specified')
        if not domain_str:
            raise WidgetException('A domain must be specified')
        # validate user selection
        try:
            domain = adt.domain_from_string(domain_str)
        except adt.DataTypeException:
            raise WidgetException("Specified domain {:} is not valid".format(domain_str))
        if domain is adt.Domain.NONE:
            raise WidgetException('A domain must be specified')
        # select target and set output
        y_ps = input_adf.X[target]
        X_pdf = input_adf.X.drop([target], axis=1)
        output_adf = adt.DataFrame(X_pdf, y_ps, domain, parent_widget=self, source_adfs=input_adf)
        self._source_ports[0].data = output_adf

    def _update_dynamic_parameters(self):
        '''
        Attempts to populate the target parameter from the input columns
        '''
        try:
            input_cols = list(self._sink_ports[0].data.X.columns)
            current_target = self._parameters['target'].value
            current_target = current_target if current_target in input_cols else None
            target = Parameter([EnumArg(current_target, input_cols)])
        except (DataUnavailable, NotConnected):
            target = Parameter([EnumArg(None, list())])
        self._parameters['target'] = target
