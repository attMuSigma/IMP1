# -*- coding: utf-8 -*-
"""
Provides methods for plotting ROC curve
"""
import io
import base64
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from sklearn.preprocessing import label_binarize


def fig_to_str(figure):
    '''
    Converts figure to base64 encoded PNG
    '''
    image_data = io.BytesIO()
    figure.savefig(image_data, format='png')
    encoded_str = base64.encodebytes(image_data.getvalue()).decode()
    return encoded_str


def create_roc_graph(adt_pred):
    '''
    Returns a base64 encoded PNG of a ROC curve for multiclass classifiers
    '''
    prediction_pdf = adt_pred.predictions
    classes = adt_pred.classes
    lookup = dict(enumerate(classes))
    n_classes = len(classes)

    if n_classes == 2:
        enc_array = prediction_pdf['target'].as_matrix()
        y_test = np.zeros((enc_array.size, 2), dtype=int)
        for col_index, class_name in lookup.items():
            y_test[enc_array==class_name, col_index] = 1
    else:
        y_test = label_binarize(prediction_pdf['target'], classes=classes)
    y_score = np.vstack(prediction_pdf['probability'])

    # Compute ROC curve and ROC area for each class
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
    
    # Compute micro-average ROC curve and ROC area
    fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
    
    fig, ax = plt.subplots()
    fig.set_size_inches(9, 6)

    # Plot ROC curve
    ax.plot(fpr["micro"], tpr["micro"],
             label='micro-average ROC curve (area = {0:0.2f})'
                   ''.format(roc_auc["micro"]))
    for i in range(n_classes):
        ax.plot(fpr[i], tpr[i], label='ROC curve of class {0} (area = {1:0.2f})'
                                       ''.format(lookup[i], roc_auc[i]))
    
    ax.plot([0, 1], [0, 1], 'k--')
    ax.set_xlim([0.0, 1.0])
    ax.set_ylim([0.0, 1.05])
    ax.set_xlabel('False Positive Rate')
    ax.set_ylabel('True Positive Rate')
    ax.set_title('Receiver operating characteristics')
    ax.legend(loc="lower right")
    return fig_to_str(fig)
