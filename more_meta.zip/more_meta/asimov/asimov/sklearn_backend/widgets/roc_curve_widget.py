# -*- coding: utf-8 -*-
"""
Provides ROC Curve widget
"""
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget, WidgetException
from asimov.sklearn_backend.widgets.sink_port import SingleSink
from asimov.sklearn_backend.widgets.attributes import StringAttribute
from asimov.sklearn_backend.widgets.roc_curve import create_roc_graph


class RocCurveWidget(BaseWidget):
    _widget_id = 'viz.roc_curve'

    def _initialize(self):
        self._plot_str = None

    def _update_ports(self):
        self._sink_ports[0] = SingleSink(self._widget_uid, 0, adt.Prediction, name='Predictions')

    def _update_static_parameters(self):
        '''
        This widget has no static parameters
        '''
    
    def _evaluate(self):
        '''
        Creates the graphic and stores as an attribute
        '''
        try:
            adt_pred = self._sink_ports[0].data
            if adt_pred.domain is not adt.Domain.CLASSIFICATION:
                raise WidgetException('Invalid domain. Only classification predictions are supported.')
            self._plot_str = create_roc_graph(adt_pred)
        except:
            self._plot_str = None
            raise
    
    def _update_attributes(self):
        '''
        Updates the ROC plot attribute
        '''
        self._attributes['plot'] = StringAttribute(self._plot_str)

    def _update_dynamic_parameters(self):
        '''
        This widget has no dynamic parameters
        '''

    def is_evaluated(self):
        '''
        Overrides the base method because evaluation is different for this widget
        '''
        if self._attributes['plot'].value is None:
            return False
        else:
            return True
