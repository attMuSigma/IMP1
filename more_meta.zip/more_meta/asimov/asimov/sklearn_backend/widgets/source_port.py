# -*- coding: utf-8 -*-
"""
Provides source port class
"""
class SourceException(Exception):
    pass


class SourcePort(object):
    '''
    Source port implementation. Offers one-to-many transmission of port data
    '''
    def __init__(self, widget_uid, port_id, dtype, name='Output Data'):
        self._widget_uid = widget_uid
        self._port_id = port_id
        self._name = name
        self._dtype = dtype
        self._data = None
    
    @property
    def widget_uid(self):
        return self._widget_uid

    @property
    def port_id(self):
        return self._port_id

    @property
    def name(self):
        return self._name
    
    @property
    def dtype(self):
        return self._dtype

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, val):
        if not isinstance(val, self._dtype):
            raise SourceException("Set data of type {:} but source type is {:}".format(type(val), self._dtype))
        self._data = val
    
    def has_data(self):
        return False if self._data is None else True
    
    def flush(self):
        self._data = None

    def to_dict(self):
        return {'widget_uid': self._widget_uid,
                'port_id': self._port_id,
                'name': self._name,
                'dtype': str(self._dtype)}


if __name__ == '__main__':
    '''
    Test area
    '''
