# -*- coding: utf-8 -*-
"""
Provides Gradient Boosting Classifier widget class
"""
import pandas as pd
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.attributes import DataFrameAttribute
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.parameters import Parameter, EnumArg, IntArg, FloatArg, NoneArg, BoolArg
from sklearn.ensemble import GradientBoostingClassifier


class GradientBoostingClassifierWidget(BaseWidget):
    _widget_id = 'supervised.gradient_boosting_classifier'

    def _initialize(self):
        self._estimator = GradientBoostingClassifier(random_state=0)

    def _update_ports(self):
        '''
        Creates this widget's ports
        '''
        self._source_ports[0] = SourcePort(self._widget_uid, 0, adt.Estimator, 'Estimator')

    def _update_static_parameters(self):
        self._parameters.update({'learning_rate': Parameter([FloatArg(0.1)]),
                                 'n_estimators': Parameter([IntArg(100)]),
                                 'max_depth': Parameter([IntArg(3)]),
                                 'min_samples_split': Parameter([IntArg(2)]),
                                 'min_samples_leaf': Parameter([IntArg(1)]),
                                 'subsample': Parameter([FloatArg(1.0)]),
                                 'max_features': Parameter([NoneArg(), EnumArg('auto', ['auto', 'sqrt', 'log2']), IntArg(1), FloatArg(0.50)]),
                                 'max_leaf_nodes': Parameter([NoneArg(), IntArg(3)]),
                                 'randomize': Parameter([BoolArg(False)])})

    def _evaluate(self):
        '''
        Creates a new estimator from the current parameters
        '''
        params = {name: arg.value for name, arg in self._parameters.items()}
        params['random_state'] = None if params['randomize'] else 0
        del params['randomize']
        self._estimator.set_params(**params)
        self._source_ports[0].data = adt.Classifier("gradient_boosting_classifier-{:}".format(self._widget_uid), self._estimator)

    def _update_attributes(self):
        '''
        Updates this widget's parameters if the estimator has been fit prior
        '''
        try:
            importance = adt.DataFrame(pd.DataFrame(self._estimator.feature_importances_))
        except (AttributeError, ValueError):
            importance = None
        self._attributes['feature_importances'] = DataFrameAttribute(importance)

    def _update_dynamic_parameters(self):
        '''
        This widget has no dynamic parameters
        '''
