# -*- coding: utf-8 -*-
"""
Provides CSV widget class
"""
import os
import csv
import pandas as pd
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget
from asimov.sklearn_backend.widgets.draft_widget import WidgetException
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.sink_port import SingleSink
from asimov.sklearn_backend.widgets.sink_port import SinkException
from asimov.sklearn_backend.widgets.sink_port import DataUnavailable
from asimov.sklearn_backend.widgets.sink_port import NotConnected
from asimov.sklearn_backend.widgets.parameters import Parameter
from asimov.sklearn_backend.widgets.parameters import EnumArg
from asimov.sklearn_backend.widgets.parameters import StringArg
from asimov.sklearn_backend.widgets.parameters import NoneArg
from asimov.sklearn_backend.widgets.attributes import StringAttribute


class CsvWidget(BaseWidget):
    _widget_id = 'data.csv'

    def _initialize(self):
        '''
        This widget has no unique initialization routine
        '''
        
    def _update_ports(self):
        '''
        Creates this widget's ports
        '''
        self._sink_ports[0] = SingleSink(self._widget_uid, 0, adt.Resource)
        self._source_ports[0] = SourcePort(self._widget_uid, 0, adt.DataFrame)

    def _update_static_parameters(self):
        '''
        Sets the filepath and separator variables initially
        '''
        self._parameters.update({'filepath': Parameter([StringArg('')]), 
                                 'separator': Parameter([NoneArg(), EnumArg('|', ['|', ','])])})

    def _evaluate(self):
        '''
        Checks sink port for file resource, then its parameters. Finally reads the CSV.
        '''
        try:
            filepath = self._get_filepath()
            sep = self._get_sep(filepath)
            self._verify_filepath(filepath)
            try:
                pdf = pd.read_csv(filepath, sep=sep)
            except Exception as e:
                raise WidgetException("CSV read error: {:}".format(e))
            adf = adt.DataFrame(pdf, parent_widget=self)
            self._source_ports[0].data = adf
        finally:
            self._attributes.update({'active_filepath': StringAttribute(filepath),
                                     'active_separator': StringAttribute(sep)})

    def _get_filepath(self):
        '''
        Gets the filepath from input resource or set parameter
        '''
        try:
            resource = self._sink_ports[0].data
            if resource.scheme is not adt.ResourceScheme.FILE:
                raise SinkException('Only resources of scheme file are supported currently')
            filepath = resource.path
        except (DataUnavailable, NotConnected):
            filepath = self._parameters['filepath'].value
        return filepath

    def _verify_filepath(self, filepath):
        '''
        Raises WidgetException if the file does not exist
        '''
        if not filepath:
            raise WidgetException('No filepath was selected')
        elif not os.path.isfile(filepath):
            raise WidgetException("Specified filepath does not exist: {:}".format(filepath))

    def _get_sep(self, filepath):
        '''
        Returns the CSV delimiter character
        '''
        sep = self._parameters['separator'].value
        return self._infer_delim(filepath) if (sep is None or sep == str()) else sep

    def _infer_delim(self, filepath):
        '''
        Returns the inferred delimiter character
        '''
        try:
            self._verify_filepath(filepath)
            with open(filepath, 'r') as file:
                sep = csv.Sniffer().sniff(next(file)).delimiter
        except WidgetException:
            sep = None
        return sep

    def _update_attributes(self):
        '''
        Attribute update occurs in evaluate method
        '''

    def _update_dynamic_parameters(self):
        '''
        This widget has no dynamic parameters
        '''
