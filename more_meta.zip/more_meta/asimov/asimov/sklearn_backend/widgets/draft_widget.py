# -*- coding: utf-8 -*-
"""
Provides the draft widget class for faster concrete widget development
"""
import sklearn as sk
from asimov.sklearn_backend.widgets.sink_port import SinkException
from asimov.sklearn_backend.widgets.parameters import ParameterException


class WidgetException(Exception):
    pass


class EvaluationError(WidgetException):
    pass


class BaseWidget(object):
    '''
    Base class for general widgets
    '''
    _widget_id = None

    def __init__(self, widget_uid, context=None):
        '''
        Safely initialzes attributes and performs safety checks
        '''
        self._widget_uid = widget_uid
        self._context = dict() if context is None else context.copy()
        self._source_ports = dict()
        self._sink_ports = dict()
        self._parameters = dict()
        self._attributes = dict()
        if not isinstance(self._widget_id, str):
            raise NotImplementedError('Class attribute "_widget_id" must be defined in derived class')
        self._initialize()
        self._update_ports()
        self._update_static_parameters()
        self._update_dynamic_parameters()
        try:
            self.evaluate()
        except (WidgetException, SinkException):
            pass

    def _initialize(self):
        '''
        Instantiates attributes for derived widgets
        '''
        raise NotImplementedError()

    def _update_ports(self):
        '''
        Instantiates source and sink port objects
        '''
        raise NotImplementedError()

    def _update_static_parameters(self):
        '''
        Instantiates parameters which are independent of input data
        '''
        raise NotImplementedError()

    def _update_dynamic_parameters(self):
        '''
        Instantiates parameters which are dependent on input data
        '''
        raise NotImplementedError()

    def _update_attributes(self):
        '''
        Instantiates attributes which act as read-only feedback variables
        '''
        raise NotImplementedError()

    def _evaluate(self):
        '''
        Business logic for evaluation, to be overridden by derived widget
        '''
        raise NotImplementedError()
    
    def _reraise(self, e, exception_class=None):
        '''
        Reraises an exception e with traceback intact
        '''
        exception_class = WidgetException if exception_class is None else exception_class
        raise exception_class(e).with_traceback(e.__traceback__)

    @property
    def widget_uid(self):
        return self._widget_uid
    
    @property
    def widget_id(self):
        return self._widget_id

    def get_source(self, port_id):
        '''
        Returns this widget's specified source port
        '''
        if port_id not in self._source_ports:
            raise WidgetException("Widget {:} does not have a source {:}".format(self.widget_id, port_id))
        return self._source_ports[port_id]

    def evaluate(self):
        '''
        Invokes the templated methods overridden by the derived widget class
        '''
        try:
            self._update_dynamic_parameters()
            self._evaluate()
        except WidgetException as e:
            self.flush()
            raise EvaluationError(e).with_traceback(e.__traceback__)
        except:
            self.flush()
            raise
        finally:
            self._update_attributes()

    def is_evaluated(self):
        return all(source.has_data() for source in self._source_ports.values())

    def add_source(self, sink_port_id, source_port):
        '''
        Adds a source port to a specified sink port
        '''
        try:
            self._sink_ports[sink_port_id].add_source(source_port)
            self._update_dynamic_parameters()
        except KeyError:
            raise WidgetException("Sink port ID {:} doesn't exist for widget {:}".format(sink_port_id, self.widget_uid))

    def remove_source(self, sink_port_id, source_port):
        '''
        Removes a source port from a specified sink port
        '''
        try:
            self._sink_ports[sink_port_id].remove_source(source_port)
            self._update_dynamic_parameters()
        except KeyError:
            raise WidgetException("Sink port {:} doesn't exist".format(sink_port_id))
    
    def set_parameters(self, param_dict):
        '''
        Updates internal estimator parameters
        '''
        try:
            for name, value in param_dict.items():
                self._parameters[name].value = value
        except (ParameterException, TypeError) as e:
            raise WidgetException("Could not set parameter '{:}': {:}".format(name, e))
        except KeyError as e:
            raise WidgetException("Invalid parameter name specified: {:}".format(e))

    def to_dict(self):
        '''
        Returns a dict representation of the widget for serialization
        '''
        params = {name: param.to_dict() for name, param in self._parameters.items()}
        attributes = {name: attr.to_dict() for name, attr in self._attributes.items()}
        sinks = {str(port_id): port.to_dict() for port_id, port in self._sink_ports.items()}
        sources = {str(port_id): port.to_dict() for port_id, port in self._source_ports.items()}
        return {'widget_id': self._widget_id, 'widget_uid': self._widget_uid, 'parameters': params,
                'attributes': attributes, 'sink_ports': sinks, 'source_ports': sources}

    def flush(self):
        '''
        Iterates over each source port and signals flush command
        '''
        for port in self._source_ports.values():
            port.flush()
        self._update_dynamic_parameters()


class SourceWidget(BaseWidget):
    '''
    Base class for widgets which load data
    '''


class TransformWidget(BaseWidget):
    '''
    Base class for widgets which transform data
    '''
    
    def _evaluate(self):
        self._fit()
        self._transform()
    
    def _fit(self):
        raise NotImplementedError()
    
    def _transform(self):
        raise NotImplementedError()
    
    @property
    def estimator(self):
        try:
            if not isinstance(self._estimator, sk.base.TransformerMixin):
                raise WidgetException("Provided estimator must be a sklearn transformer".format(self._estimator))
        except AttributeError:
            raise WidgetException('Transform widget was not initialized with a sklearn estimator') 
        return sk.base.clone(self._estimator)
