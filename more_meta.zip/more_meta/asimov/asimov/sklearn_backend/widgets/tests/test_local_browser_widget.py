# -*- coding: utf-8 -*-
"""
Tests the Local Browser widget
"""
import unittest
import tempfile
from asimov.sklearn_backend.widgets.draft_widget import WidgetException
from asimov.sklearn_backend.widgets.local_browser_widget import LocalBrowserWidget


class BasicTest(unittest.TestCase):

    def setUp(self):
        self.user_path = '/asimov/data'

    def test_basic_browse(self):
        '''
        Tests that no parameters are set by default, and that the widget is unevaluated
        '''
        with tempfile.NamedTemporaryFile(dir=self.user_path, suffix='.test') as file:
            widget = LocalBrowserWidget(1)
            with self.assertRaises(WidgetException):
                widget.evaluate()
            model = widget.to_dict()
            self.assertTrue(file.name in model['attributes']['file_list']['value'])

    def test_set_parameters(self):
        '''
        Tests that no parameters are set by default, and that the widget is unevaluated
        '''
        with tempfile.TemporaryDirectory(dir=self.user_path) as directory:
            with tempfile.NamedTemporaryFile(dir=directory, suffix='.test') as file:
                widget = LocalBrowserWidget(1)

                widget.set_parameters({'selected_file': file.name})
                widget.evaluate()
                model = widget.to_dict()
                self.assertTrue(file.name in model['attributes']['file_list']['value'])
                
                resource = widget.get_source(0).data
                self.assertEqual(resource.path, file.name)
        

if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
