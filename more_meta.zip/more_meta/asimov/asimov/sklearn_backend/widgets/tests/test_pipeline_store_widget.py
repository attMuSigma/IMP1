# -*- coding: utf-8 -*-
"""
Tests the Pipeline Store widget
"""
import unittest
from asimov.sklearn_backend.widgets.pipeline_store_widget import PipelineStoreWidget
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets import data_types as adt
from asimov.webapp.app.utils.mock_documents import mocked_docs


class BasicTest(unittest.TestCase):

    def test_basic_store(self):
        '''
        Tests that a pipeline is stored in a model
        '''
        with mocked_docs(store_pipeline=False) as mock:
            # make sure the model has no pipelines
            self.assertTrue(len(mock.model_doc.pipelines) == 0)
            # setup the source and run the widget
            mock_source = SourcePort(0, 0, adt.Pipeline)
            mock_source.data = mock.pipeline_adt
            context = {'project_id': mock.project_doc.id, 'model_id': mock.model_doc.id, 'db_host': mock.host,
                       'db_port': mock.port, 'db_name': mock.db}
            widget = PipelineStoreWidget(0, context)
            widget.add_source(0, mock_source)
            widget.evaluate()
            # reload the model and make sure the pipeline is there
            mock.model_doc.reload()
            self.assertTrue(len(mock.model_doc.pipelines) == 1)
            # reevaluation should not increase the number of pipelines
            widget.evaluate()
            mock.model_doc.reload()
            self.assertTrue(len(mock.model_doc.pipelines) == 1)


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
