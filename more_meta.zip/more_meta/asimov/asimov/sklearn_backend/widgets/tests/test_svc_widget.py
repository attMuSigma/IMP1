# -*- coding: utf-8 -*-
"""
Tests the SVC widget
"""
import unittest
from asimov.sklearn_backend.widgets.svc_widget import SvcWidget, SVC


class BasicTest(unittest.TestCase):

    def test_basic(self):
        '''
        Tests splitting a DF with classification domain
        '''
        widget = SvcWidget(1)
        widget.evaluate()
        adt_estimator = widget.get_source(0).data
        self.assertTrue(isinstance(adt_estimator.estimator, SVC))
        self.assertTrue(widget.is_evaluated())
        svc = adt_estimator.estimator
        params = svc.get_params()
        self.assertEqual(params['C'], 1.0)
        self.assertEqual(params['kernel'], 'rbf')
        self.assertEqual(params['gamma'], 0.0)


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
