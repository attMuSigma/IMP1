# -*- coding: utf-8 -*-
"""
Tests the PCA widget
"""
import unittest
import pandas as pd
import numpy as np
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.pca_widget import PcaWidget
from asimov.sklearn_backend.widgets.draft_widget import WidgetException


class BasicTest(unittest.TestCase):
    
    def setUp(self):
        self.mock_source = SourcePort(0, 0, adt.DataFrame)
        self.mock_source.data = adt.DataFrame(pd.DataFrame(np.ones((50,4)), columns=['col1', 'col2', 'col3', 'col4']))
        self.invalid_mock_source = SourcePort(0, 0, adt.DataFrame)
        self.invalid_mock_source.data = adt.DataFrame(pd.DataFrame([[1,2,'red'], [3,4,'green']]))
    
    def test_initial_state(self):
        '''
        Tests that no parameters are set by default, and that the widget is unevaluated
        '''
        widget = PcaWidget(1)
        model = widget.to_dict()
        self.assertEqual(model['widget_uid'], 1)
        self.assertEqual(model['widget_id'], 'decomposition.pca')
        self.assertEqual(model['attributes']['noise_variance']['value'], None)
        self.assertEqual(model['parameters']['n_components']['value'], None)
        self.assertEqual(widget.is_evaluated(), False)

    def test_evaluate_with_params(self):
        '''
        Tests that the widget reduces dimensions to 1
        '''
        widget = PcaWidget(1)
        widget.set_parameters({'n_components': 1})
        
        model = widget.to_dict()
        self.assertEqual(model['parameters']['n_components']['value'], 1)
        
        widget.add_source(0, self.mock_source)
        widget.evaluate()
        self.assertEqual(widget.is_evaluated(), True)
        
        model = widget.to_dict()
        self.assertEqual(model['attributes']['n_components']['value'], 1)
        
        pdf = widget.get_source(0).data.X
        self.assertEqual(pdf.shape, (50, 1))
    
    def test_evaluate_no_params(self):
        '''
        Tests that no columns are dropped if no parameters are set
        '''
        widget = PcaWidget(1)
        widget.add_source(0, self.mock_source)
        widget.evaluate()
        pdf = widget.get_source(0).data.X
        self.assertEqual(pdf.shape, (50, 4))
    
    def test_object_input(self):
        '''
        Tests that a widget exception is raised when object dtypes are input
        '''
        widget = PcaWidget(1)
        widget.add_source(0, self.invalid_mock_source)
        with self.assertRaises(WidgetException):
            widget.evaluate()


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
