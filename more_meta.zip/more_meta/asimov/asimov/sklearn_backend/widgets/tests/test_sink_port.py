# -*- coding: utf-8 -*-
"""
Test the Sink Port class
"""
import unittest
import pandas as pd
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.sink_port import SingleSink
from asimov.sklearn_backend.widgets.sink_port import MultiSink
from asimov.sklearn_backend.widgets.sink_port import NotConnected
from asimov.sklearn_backend.widgets.sink_port import DataUnavailable
from asimov.sklearn_backend.widgets.sink_port import SinkException
from asimov.sklearn_backend.widgets.source_port import SourcePort


class BasicTest(unittest.TestCase):
    '''
    Performs a basic suite of tests on single and multi sinks
    '''
    def setUp(self):
        self.good_source = SourcePort(0, 0, adt.DataFrame)
        self.good_source.data = adt.DataFrame(pd.DataFrame())
        self.empty_source = SourcePort(1, 0, adt.DataFrame)
    
        
    def test_single_read_unconnected(self):
        single = SingleSink(2, 0, adt.DataFrame)
        with self.assertRaises(NotConnected):
            single.data
    
    def test_single_remove_unconnected(self):
        single = SingleSink(2, 0, adt.DataFrame)
        with self.assertRaises(SinkException):
            single.remove_source(self.good_source)

    def test_single_read_available(self):
        single = SingleSink(2, 0, adt.DataFrame)
        single.add_source(self.good_source)
        self.assertTrue(single.data.X.equals(pd.DataFrame()))

    def test_single_read_unavailable(self):
        single = SingleSink(2, 0, adt.DataFrame)
        single.add_source(self.empty_source)
        with self.assertRaises(DataUnavailable):
            single.data
    
    def test_single_add_exceed(self):
        single = SingleSink(2, 0, adt.DataFrame)
        single.add_source(self.empty_source)
        with self.assertRaises(SinkException):
            single.add_source(self.empty_source)
        
    def test_multi_read_unconnected(self):
        multi = MultiSink(3, 0, adt.DataFrame)
        with self.assertRaises(NotConnected):
            multi.data

    def test_multi_remove_unconnected(self):
        multi = MultiSink(3, 0, adt.DataFrame)
        with self.assertRaises(SinkException):
            multi.remove_source(self.good_source)
            
    def test_multi_read_available(self):
        multi = MultiSink(3, 0, adt.DataFrame)
        multi.add_source(self.good_source)
        self.assertEqual(multi.data, {(0, 0): self.good_source.data})
            
    def test_multi_read_unavailable(self):
        multi = MultiSink(3, 0, adt.DataFrame)
        multi.add_source(self.empty_source)
        with self.assertRaises(DataUnavailable):
            multi.data
    
    def test_multi_read_one_unavailable(self):
        multi = MultiSink(3, 0, adt.DataFrame)
        multi.add_source(self.empty_source)
        multi.add_source(self.good_source)
        with self.assertRaises(DataUnavailable):
            multi.data

if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)

    
