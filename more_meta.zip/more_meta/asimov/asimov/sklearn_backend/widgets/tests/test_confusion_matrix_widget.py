# -*- coding: utf-8 -*-
"""
Tests the Confusion Matrix widget
"""
import unittest
import pandas as pd
import numpy as np
from asimov.sklearn_backend.widgets import data_types as adt
from asimov.sklearn_backend.widgets.confusion_matrix_widget import ConfusionMatrixWidget
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.sink_port import SinkException
from sklearn.datasets import make_classification
from sklearn.svm import SVC


class BasicTest(unittest.TestCase):

    def setUp(self):
        svm = SVC(probability=True, random_state=0)
        text_labels = np.array(['cat', 'dog', 'bird'])
        
        X_bin, y_bin = make_classification(n_classes=2, n_informative=2, class_sep=3)
        y_bin = text_labels[y_bin]
        svm.fit(X_bin, y_bin)
        pred_bin, pred_proba_bin = svm.predict(X_bin), svm.predict_proba(X_bin)
        pred_pdf_bin = pd.DataFrame({'target': y_bin, 'prediction': pred_bin, 'probability': pred_proba_bin.tolist(), 'fold':0})
        pred_adt_bin = adt.Prediction(pred_pdf_bin, 'foo', adt.Domain.CLASSIFICATION, ['cat', 'dog'])
        
        X_mult, y_mult = make_classification(n_classes=3, n_informative=3, class_sep=3)
        y_mult = text_labels[y_mult]
        svm.fit(X_mult, y_mult)
        pred_mult, pred_proba_mult = svm.predict(X_mult), svm.predict_proba(X_mult)
        pred_pdf_mult = pd.DataFrame({'target': y_mult, 'prediction': pred_mult, 'probability': pred_proba_mult.tolist(), 'fold':0})
        pred_adt_mult = adt.Prediction(pred_pdf_mult, 'foo', adt.Domain.CLASSIFICATION, ['cat', 'dog', 'bird'])
        
        self.mock_binary_source = SourcePort(0, 0, adt.Prediction)
        self.mock_binary_source.data = pred_adt_bin
        self.mock_multi_source = SourcePort(0, 0, adt.Prediction)
        self.mock_multi_source.data = pred_adt_mult

    def test_binary_class(self):
        '''
        Tests confusion matrix curve on 2 targets
        '''
        widget = ConfusionMatrixWidget(1)
        with self.assertRaises(SinkException):
            widget.evaluate()
        model = widget.to_dict()
        self.assertEqual(model['attributes']['plot']['value'], None)
        self.assertEqual(widget.is_evaluated(), False)

        widget.add_source(0, self.mock_binary_source)
        widget.evaluate()
        self.assertEqual(widget.is_evaluated(), True)
        model = widget.to_dict()
        self.assertEqual(type(model['attributes']['plot']['value']), str)
        
    def test_multiclass(self):
        '''
        Tests confusion matrix on 3 targets
        '''
        widget = ConfusionMatrixWidget(1)
        with self.assertRaises(SinkException):
            widget.evaluate()
        model = widget.to_dict()
        self.assertEqual(model['attributes']['plot']['value'], None)
        self.assertEqual(widget.is_evaluated(), False)

        widget.add_source(0, self.mock_multi_source)
        widget.set_parameters({'normalize': True})
        widget.evaluate()
        self.assertEqual(widget.is_evaluated(), True)
        model = widget.to_dict()
        self.assertEqual(type(model['attributes']['plot']['value']), str)
    
    def test_create_roc_graph_binary(self):
        '''
        Tests the underlying function which creates the ROC graph
        '''


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
