# -*- coding: utf-8 -*-
"""
Tests the DataFrame Sampler widget
"""
import unittest
import pandas as pd
import numpy as np
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.sink_port import SinkException
from asimov.sklearn_backend.widgets.dataframe_sampler_widget import SamplerWidget


class BasicTest(unittest.TestCase):
    
    def setUp(self):
        self.mock_source = SourcePort(0, 0, adt.DataFrame)
        self.mock_source.data = adt.DataFrame(pd.DataFrame(np.ones((50,4)), columns=['col1', 'col2', 'col3', 'col4']))
        self.mock_source_index = SourcePort(0, 0, adt.DataFrame)
        self.mock_source_index.data = adt.DataFrame(pd.DataFrame(np.arange(16).reshape((4,4)), index=[4, 7, 11, 3], columns=['col1', 'col2', 'col3', 'col4']))
        

    def test_basic_sample(self):
        '''
        Tests that the mock data is sampled correctly
        '''
        widget = SamplerWidget(1)
        widget.set_parameters({'sample_size': 5})
        with self.assertRaises(SinkException):
            widget.evaluate()
        model = widget.to_dict()
        self.assertEqual(model['attributes']['samples']['value'], None)
        
        widget.add_source(0, self.mock_source)
        widget.evaluate()
        model = widget.to_dict()
        self.assertEqual(len(model['attributes']['samples']['value']['X']['value']), 5)
    
    def test_lower_bound(self):
        '''
        Tests that the widget picks the smaller size between the dataframe and the parameter
        '''
        widget = SamplerWidget(1)
        widget.set_parameters({'sample_size': 500})
        widget.add_source(0, self.mock_source)
        widget.evaluate()
        model = widget.to_dict()
        self.assertEqual(len(model['attributes']['samples']['value']['X']['value']), 50)

    def test_randomize_subset(self):
        '''
        Tests that the widget picks the smaller size between the dataframe and the parameter
        '''
        widget = SamplerWidget(1)
        widget.set_parameters({'sample_size': 5, 'randomize': True})
        widget.add_source(0, self.mock_source)
        widget.evaluate()
        model = widget.to_dict()
        self.assertEqual(len(model['attributes']['samples']['value']['X']['value']), 5)
    
    def test_nonrange_index(self):
        '''
        Tests sampling a dataframe whose indexes are not a linear range
        '''
        widget = SamplerWidget(1)
        widget.set_parameters({'sample_size': 5, 'randomize': True})
        widget.add_source(0, self.mock_source_index)
        widget.evaluate()
        model = widget.to_dict()
        with self.assertRaises(KeyError):
            model['attributes']['samples']['value']['X']['value'][0]

        self.assertEqual(model['attributes']['samples']['value']['X']['value']['4'], [0, 1, 2, 3])
        

if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
