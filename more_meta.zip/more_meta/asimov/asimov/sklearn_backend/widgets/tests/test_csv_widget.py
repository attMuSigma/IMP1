# -*- coding: utf-8 -*-
"""
Tests the CSV widget
"""
import unittest
import os
from asimov.sklearn_backend.widgets.csv_widget import CsvWidget
from asimov.sklearn_backend.widgets.draft_widget import WidgetException
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets import data_types as adt


class BasicTest(unittest.TestCase):

    def setUp(self):
        self.test_dir = os.path.dirname(os.path.realpath(__file__))
        self.test_file = os.path.join(self.test_dir,'test_data.csv')
        self.test_resource = adt.Resource(adt.ResourceScheme.FILE, self.test_file)
        self.mock_source = SourcePort(0, 0, adt.Resource)
        self.mock_source.data = self.test_resource

    def test_evaluate_no_params(self):
        '''
        Tests that the widget raises an exception if a filepath is not specified
        '''
        widget = CsvWidget(1)
        model = widget.to_dict()
        self.assertEqual(model['widget_uid'], 1)
        self.assertEqual(model['widget_id'], 'data.csv')
        self.assertEqual(model['parameters']['filepath']['value'], '')
        self.assertEqual(model['parameters']['separator']['value'], None)
        self.assertEqual(widget.is_evaluated(), False)
        with self.assertRaises(WidgetException):
            widget.evaluate()
        model = widget.to_dict()
        self.assertEqual(model['parameters']['filepath']['value'], '')
        self.assertEqual(model['parameters']['separator']['value'], None)
        self.assertEqual(model['attributes']['active_filepath']['value'], '')
        self.assertEqual(model['attributes']['active_separator']['value'], None)

    def test_evaluate_with_params(self):
        '''
        Tests that the test CSV file is read and placed on the source port
        '''
        widget = CsvWidget(1)
        params = {'filepath':self.test_file , 'separator': ','}
        widget.set_parameters(params)
        widget.evaluate()
        pdf = widget.get_source(0).data.X
        self.assertEqual(list(pdf.columns), ['Feature1', 'Feature2', 'Feature3', 'Feature4'])
        self.assertEqual(list(pdf.iloc[0,:]), [0, 0, 0, 0])
        model = widget.to_dict()
        self.assertEqual(model['attributes']['active_filepath']['value'], self.test_file)
        self.assertEqual(model['attributes']['active_separator']['value'], ',')
    
    def test_input_resource(self):
        '''
        Tests that the test CSV file is read and placed on the source port
        '''
        widget = CsvWidget(1)
        widget.add_source(0, self.mock_source)
        widget.evaluate()
        # widget evaluates with input resource provided
        pdf = widget.get_source(0).data.X
        self.assertEqual(list(pdf.columns), ['Feature1', 'Feature2', 'Feature3', 'Feature4'])
        self.assertEqual(list(pdf.iloc[0,:]), [0, 0, 0, 0])
        # widget has inferred and set its own parameters
        model = widget.to_dict()
        self.assertEqual(model['parameters']['filepath']['value'], '')
        self.assertEqual(model['parameters']['separator']['value'], None)
        self.assertEqual(model['attributes']['active_filepath']['value'], self.test_file)
        self.assertEqual(model['attributes']['active_separator']['value'], ',')
        # widget no longer evaluates with input resource provided
        widget.remove_source(0, self.mock_source)
        with self.assertRaises(WidgetException):
            widget.evaluate()
        model = widget.to_dict()
        self.assertEqual(model['parameters']['filepath']['value'], '')
        self.assertEqual(model['parameters']['separator']['value'], None)
        self.assertEqual(model['attributes']['active_filepath']['value'], '')
        self.assertEqual(model['attributes']['active_separator']['value'], None)


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
