# -*- coding: utf-8 -*-
"""
Test the DataFrame class
"""
import unittest
import mock
import numpy as np
import pandas as pd
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget
from asimov.sklearn_backend.widgets.data_types import DataFrame
from asimov.sklearn_backend.widgets.data_types import Domain
from asimov.sklearn_backend.widgets.data_types import Resource
from asimov.sklearn_backend.widgets.data_types import ResourceScheme
from sklearn import svm

class DataFrameTests(unittest.TestCase):

    def test_only_x(self):
        '''
        Tests an AVP DataFrame which only has an X PDF
        '''
        pdf = pd.DataFrame(np.arange(6).reshape(3,2), columns=['Feature 1', 'Feature 2'])
        adf = DataFrame(pdf)
        
        self.assertEqual(adf.dtype_set, {'int'})
        self.assertEqual(adf.structure, 'dense')
        self.assertEqual(adf.domain, Domain.NONE)
        
        adf_dict = adf.to_dict()
        self.assertEqual(adf_dict['meta']['domain'], 'domain.none')
        self.assertEqual(adf_dict['X']['value']['0'], [0, 1])
        self.assertEqual(adf_dict['X']['value']['1'], [2, 3])
        self.assertEqual(adf_dict['X']['value']['2'], [4, 5])
        self.assertEqual(adf_dict['X']['meta']['name'], ['Feature 1', 'Feature 2'])
        self.assertEqual(adf_dict['X']['meta']['dtype'], ['int', 'int'])
        self.assertEqual(adf_dict['y']['value'], None)
        self.assertEqual(adf_dict['y']['meta'], None)
    
    def test_x_y(self):
        '''
        Tests an AVP DataFrame which only has an X PDF
        '''
        pdf = pd.DataFrame([[1, 0.5, 1], [2, 1.5, -1], [0, 2.5, -1]], columns=['Feature 1', 'Feature 2', 'Class'])
        pdf['Class'] = pdf['Class'].astype('category')
        pdf_x = pdf[['Feature 1', 'Feature 2']]
        pdf_y = pdf['Class']
        adf = DataFrame(pdf_x, pdf_y, Domain.CLASSIFICATION)
        
        self.assertEqual(adf.dtype_set, {'int', 'float'})
        self.assertEqual(adf.structure, 'dense')
        self.assertEqual(adf.domain, Domain.CLASSIFICATION)
        
        adf_dict = adf.to_dict()
        self.assertEqual(adf_dict['meta']['domain'], 'domain.classification')
        self.assertEqual(adf_dict['X']['value']['0'], [1, 0.5])
        self.assertEqual(adf_dict['X']['value']['1'], [2, 1.5])
        self.assertEqual(adf_dict['X']['value']['2'], [0, 2.5])
        self.assertEqual(adf_dict['X']['meta']['name'], ['Feature 1', 'Feature 2'])
        self.assertEqual(adf_dict['X']['meta']['dtype'], ['int', 'float'])
        self.assertEqual(adf_dict['y']['value'], [1, -1, -1])
        self.assertEqual(adf_dict['y']['meta']['dtype'], 'category')
        self.assertEqual(adf_dict['y']['meta']['name'], 'Class')

    def test_empty_x(self):
        '''
        Tests the scenario where an empty PDF is provided
        '''
        pdf = pd.DataFrame()
        adf = DataFrame(pdf)
        self.assertEqual(adf.dtype_set, set())
        self.assertEqual(adf.structure, 'dense')
        self.assertEqual(adf.domain, Domain.NONE)
    
    def test_nan_x(self):
        '''
        Tests the scenario where an empty PDF is provided
        '''
        pdf = pd.DataFrame([[1,2,3], [4,5, np.nan]])
        adf = DataFrame(pdf)
        adf_dict = adf.to_dict()
        self.assertEqual(adf_dict['X']['value']['1'], [4, 5, None])


class ResourceTests(unittest.TestCase):

    def test_basic_parse(self):
        '''
        Tests an AVP DataFrame which only has an X PDF
        '''
        resource = Resource(ResourceScheme.FILE, '/Users/paul/test_data.csv')
        self.assertEqual(resource.path, '/Users/paul/test_data.csv')
        self.assertEqual(resource.scheme, ResourceScheme.FILE)
    
    def test_from_uri(self):
        '''
        Tests static factory of resource
        '''
        resource = Resource.from_uri('file:///Users/paul/test_data.csv')
        self.assertEqual(resource.path, '/Users/paul/test_data.csv')
        self.assertEqual(resource.scheme, ResourceScheme.FILE)


class PredictionsTests(unittest.TestCase):
    
    def setUp(self):
        self.class_pred_pdf = pd.DataFrame(columns=['prediction', 'target', 'fold', 'probability'])
        self.reg_pred_pdf = pd.DataFrame(columns=['prediction', 'target', 'fold'])

    def test_instantiation(self):
        '''
        Tests an AVP DataFrame which only has an X PDF
        '''
        class_pred = adt.Prediction(self.class_pred_pdf, 'foo', adt.Domain.CLASSIFICATION, classes=['a', 'b', 'c'])
        reg_pred = adt.Prediction(self.reg_pred_pdf, 'foo', adt.Domain.REGRESSION)
        with self.assertRaises(adt.DataTypeException):
            class_pred = adt.Prediction(self.class_pred_pdf, 'foo', adt.Domain.REGRESSION)
        with self.assertRaises(adt.DataTypeException):
            class_pred = adt.Prediction(self.class_pred_pdf, 'foo', adt.Domain.NONE)
        with self.assertRaises(adt.DataTypeException):
            reg_pred = adt.Prediction(self.reg_pred_pdf, 'foo', adt.Domain.CLASSIFICATION)


class EstimatorTests(unittest.TestCase):

    def setUp(self):
        self.svc = svm.SVC()
        self.adt_class = adt.Classifier('class', self.svc)
        
        self.svr = svm.SVR()
        self.adt_reg = adt.Regressor('reg', self.svr)
        
    def test_estimator(self):
        '''
        Simple sanity checks on validation
        '''
        self.assertTrue(isinstance(self.adt_class, adt.Estimator))
        self.assertTrue(isinstance(self.adt_reg, adt.Estimator))

    def test_classifier(self):
        '''
        Simple sanity checks on validation
        '''
        adt.Classifier('foo', self.svc)
        with self.assertRaises(adt.DataTypeException):
            adt.Classifier('foo', self.svr)
        self.adt_class.name
        self.adt_class.estimator
        self.assertTrue(self.adt_class.domain is adt.Domain.CLASSIFICATION)
        
    def test_regressor(self):
        '''
        Simple sanity checks on validation
        '''
        adt.Regressor('foo', self.svr)
        with self.assertRaises(adt.DataTypeException):
            adt.Regressor('foo', self.svc)
        self.adt_reg.name
        self.adt_reg.estimator
        self.assertTrue(self.adt_reg.domain is adt.Domain.REGRESSION)


class MockWidget(BaseWidget, mock.MagicMock):
    def __init__(self, wid, wuid):
        super(BaseWidget, self).__init__(wid, wuid)


if __name__ == '__main__':
    '''
    Test area
    '''
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    suite.addTest(loader.loadTestsFromTestCase(DataFrameTests))
    suite.addTest(loader.loadTestsFromTestCase(ResourceTests))
    suite.addTest(loader.loadTestsFromTestCase(PredictionsTests))
    suite.addTest(loader.loadTestsFromTestCase(EstimatorTests))
    unittest.TextTestRunner(verbosity=2).run(suite)
