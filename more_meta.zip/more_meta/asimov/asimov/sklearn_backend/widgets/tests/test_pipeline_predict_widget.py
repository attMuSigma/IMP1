# -*- coding: utf-8 -*-
"""
Tests the Pipeline Predict widget
"""
import unittest
import pandas as pd
import numpy as np
from sklearn.utils.testing import assert_array_almost_equal
from asimov.sklearn_backend.widgets.pipeline_predict_widget import PipelinePredictWidget
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets import data_types as adt
from asimov.sklearn_backend.utils.mock_pipeline import mocked_pipeline


class BasicTest(unittest.TestCase):

    def test_class_pred(self):
        '''
        Tests that a pipeline is stored in a model
        '''
        with mocked_pipeline() as mock:
            # create mock source ports
            source_dataframe = SourcePort(0, 0, adt.DataFrame)
            source_dataframe.data = mock.class_dataframe_adt
            source_pipeline = SourcePort(1, 0, adt.Pipeline)
            source_pipeline.data = mock.class_pipeline_adt
            # connect and evaluate widget
            widget = PipelinePredictWidget(2)
            widget.add_source(0, source_dataframe)
            widget.add_source(1, source_pipeline)
            widget.evaluate()
            # verify predictions
            prediction_adt = widget.get_source(0).data
            predictions = prediction_adt.predictions
            self.assertTrue(predictions['prediction'].equals(pd.Series(mock.class_y_pred_nd)))
            self.assertTrue(predictions['target'].equals(pd.Series(mock.class_y_nd)))
            assert_array_almost_equal(np.vstack(predictions['probability']), mock.class_y_pred_proba_nd)


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
