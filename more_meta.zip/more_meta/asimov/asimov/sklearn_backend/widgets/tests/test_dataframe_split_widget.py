# -*- coding: utf-8 -*-
"""
Tests the DataFrame Split widget
"""
import unittest
import pandas as pd
import numpy as np
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.dataframe_split_widget import DataframeSplitWidget
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.sink_port import SinkException


class BasicTest(unittest.TestCase):

    def setUp(self):
        '''
        Initializes test case with test-wide mock variables
        '''
        samples = 100
        data = pd.DataFrame(np.arange(samples*2).reshape((samples,2)), columns=['col1', 'col2'])
        class_target = pd.Series([1]*(samples//2) + [2]*(samples//2), name='target')
        reg_target = pd.Series(np.arange(samples), name='target')
        self.mock_source_class = SourcePort(0, 0, adt.DataFrame)
        self.mock_source_class.data = adt.DataFrame(data, class_target, adt.Domain.CLASSIFICATION)
        self.mock_source_reg = SourcePort(0, 0, adt.DataFrame)
        self.mock_source_reg.data = adt.DataFrame(data, reg_target, adt.Domain.REGRESSION)
        self.mock_source_none = SourcePort(0, 0, adt.DataFrame)
        self.mock_source_none.data = adt.DataFrame(data)

    def test_split_class(self):
        '''
        Tests splitting a DF with classification domain
        '''
        widget = DataframeSplitWidget(1)
        widget.add_source(0, self.mock_source_class)
        widget.set_parameters({'split': 0.30, 'shuffle': False})
        widget.evaluate()
        
        adf_a = widget.get_source(0).data
        self.assertEqual(adf_a.X.shape[0], 70)
        self.assertEqual(adf_a.y.shape[0], 70)
        self.assertEqual(adf_a.domain, adt.Domain.CLASSIFICATION)
        
        adf_b = widget.get_source(1).data
        self.assertEqual(adf_b.X.shape[0], 30)
        self.assertEqual(adf_b.y.shape[0], 30)
        self.assertEqual(adf_b.domain, adt.Domain.CLASSIFICATION)
        
        # test stratification
        balance_a = (sum(adf_a.y==1)/float(adf_a.y.size))
        balance_b = (sum(adf_b.y==1)/float(adf_b.y.size))
        self.assertTrue(balance_a == balance_b == 0.50)
        self.assertTrue(widget.is_evaluated())
    
    def test_split_reg(self):
        '''
        Tests splitting a DF with regression domain
        '''
        widget = DataframeSplitWidget(1)
        widget.add_source(0, self.mock_source_reg)
        widget.set_parameters({'split': 0.30, 'shuffle': False})
        widget.evaluate()
        
        adf_a = widget.get_source(0).data
        self.assertEqual(adf_a.X.shape[0], 70)
        self.assertEqual(adf_a.y.shape[0], 70)
        self.assertEqual(adf_a.domain, adt.Domain.REGRESSION)
        
        adf_b = widget.get_source(1).data
        self.assertEqual(adf_b.X.shape[0], 30)
        self.assertEqual(adf_b.y.shape[0], 30)
        self.assertEqual(adf_b.domain, adt.Domain.REGRESSION)
        self.assertTrue(widget.is_evaluated())

    def test_split_none(self):
        '''
        Tests splitting a DF with no domain
        '''
        widget = DataframeSplitWidget(1)
        widget.add_source(0, self.mock_source_none)
        widget.set_parameters({'split': 0.30, 'shuffle': False})
        widget.evaluate()
        
        adf_a = widget.get_source(0).data
        self.assertEqual(adf_a.X.shape[0], 70)
        self.assertEqual(adf_a.domain, adt.Domain.NONE)
        
        adf_b = widget.get_source(1).data
        self.assertEqual(adf_b.X.shape[0], 30)
        self.assertEqual(adf_b.domain, adt.Domain.NONE)
        self.assertTrue(widget.is_evaluated())

    def test_no_input(self):
        '''
        Tests evaluation without a source input
        '''
        widget = DataframeSplitWidget(1)
        with self.assertRaises(SinkException):
            widget.evaluate()
        self.assertFalse(widget.is_evaluated())


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
