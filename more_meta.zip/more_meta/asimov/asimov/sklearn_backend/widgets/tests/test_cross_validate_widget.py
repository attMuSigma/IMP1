# -*- coding: utf-8 -*-
"""
Tests the Cross Validation widget
"""
import unittest
import numpy as np
import pandas as pd
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.sink_port import SinkException
from asimov.sklearn_backend.widgets.mock_source_widget import MockAdfSourceWidget
from asimov.sklearn_backend.widgets.cross_validate_widget import CrossValidateWidget
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.utils.testing import assert_array_almost_equal
from sklearn.datasets import load_iris
from sklearn.cross_validation import StratifiedKFold
from sklearn.preprocessing import LabelEncoder


class BasicTest(unittest.TestCase):

    def setUp(self):
        '''
        Initializes test case with test-wide mock variables
        '''
        iris = load_iris()
        self.class_X, self.class_y = pd.DataFrame(iris.data), pd.Series(iris.target, name='Species')
        self.class_source_widget = MockAdfSourceWidget(self.class_X, self.class_y, adt.Domain.CLASSIFICATION)
        self.class_source_port = self.class_source_widget.get_source(0)
        self.class_estimator_port = SourcePort(1, 0, adt.Estimator)
        self.class_estimator_port.data = adt.Classifier('foo', GradientBoostingClassifier(random_state=0))
        
    def test_basic_classification(self):
        '''
        Basic test to exercise the evaluator
        '''
        # hook up training data. won't work without an estimator
        widget = CrossValidateWidget(5)
        widget.add_source(0, self.class_source_port)
        with self.assertRaises(SinkException):
            widget.evaluate()

        # add the classifier and evaluate
        widget.add_source(1, self.class_estimator_port)
        widget.set_parameters({'shuffle': True})
        widget.evaluate()
        
        # setup naive cross validate via loop
        X = np.array(self.class_source_port.data.X)
        y = self.class_source_port.data.y
        cv = StratifiedKFold(y, shuffle=True, random_state=0)  # same as widget config
        encoder = LabelEncoder()
        y_enc = encoder.fit_transform(y)
        est = GradientBoostingClassifier(random_state=0)  # same as widget source estimator
        
        # populate prediction arrays via identical classifier i.e. the 'answers'
        y_pred = np.zeros_like(y_enc)
        y_pred_proba = np.zeros((y_enc.size, 3))
        for train, test in cv:
            est.fit(X[train], y_enc[train])
            y_pred[test] = est.predict(X[test])
            y_pred_proba[test, :] = est.predict_proba(X[test])
        
        # assert prediction object is structured correctly
        adt_pred = widget.get_source(0).data
        self.assertTrue(adt_pred.domain is adt.Domain.CLASSIFICATION)
        self.assertTrue(adt_pred.estimator_name == 'foo')
        self.assertTrue(adt_pred.classes == [0, 1, 2])
        predictions = adt_pred.predictions
        fold_series = pd.concat([pd.Series(data=fold_index, index=cv_idx) for fold_index, (_, cv_idx) in enumerate(cv)])
        self.assertTrue(predictions['prediction'].equals(pd.Series(y_pred)))
        self.assertTrue(predictions['target'].equals(y))
        self.assertTrue(predictions['fold'].equals(fold_series.sort_index()))
        assert_array_almost_equal(np.vstack(predictions['probability']), y_pred_proba)
        
        # refit estimator and make sure it produces the same output as cross validation
        est.fit(X, y)
        est_pred = est.predict(X)
        est_pred_proba = est.predict_proba(X)
        adt_pipeline = widget.get_source(1).data
        sk_pipeline = adt_pipeline.estimator
        pipe_pred = sk_pipeline.predict(X)
        pipe_pred_proba = sk_pipeline.predict_proba(X)
        self.assertTrue((est_pred == pipe_pred).all())
        assert_array_almost_equal(est_pred_proba, pipe_pred_proba)


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
