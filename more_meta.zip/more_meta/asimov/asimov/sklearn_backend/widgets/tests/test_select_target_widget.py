# -*- coding: utf-8 -*-
"""
Tests the Select Target widget
"""
import unittest
import pandas as pd
from asimov.sklearn_backend.widgets.select_target_widget import SelectTargetWidget
from asimov.sklearn_backend.widgets.draft_widget import WidgetException
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets import data_types as adt


class BasicTest(unittest.TestCase):

    def setUp(self):
        self.mock_source = SourcePort(0, 0, adt.DataFrame)
        pdf = pd.DataFrame([[1,2,3,4],[5,6,7,8]], columns=['col1', 'col2', 'regress', 'class'])
        self.mock_source.data = adt.DataFrame(pdf)
            
    def test_targets_populate(self):
        '''
        Tests that the input data columns are the available targets
        '''
        widget = SelectTargetWidget(1)
        widget.add_source(0, self.mock_source)
        model = widget.to_dict()
        self.assertEqual(model['parameters']['target']['options'][0]['options'], ['col1', 'col2', 'regress', 'class'])
        
    def test_target_class(self):
        '''
        Tests that the classification target is registered correctly
        '''
        widget = SelectTargetWidget(1)
        widget.add_source(0, self.mock_source)
        widget.set_parameters({'target': 'class', 'domain': 'domain.classification'})
        widget.evaluate()
        
        output_adf = widget.get_source(0).data
        self.assertEqual(list(output_adf.X.columns), ['col1', 'col2', 'regress'])
        self.assertEqual(output_adf.y.name, 'class')
        self.assertEqual(output_adf.domain, adt.Domain.CLASSIFICATION)
        
    def test_target_regress(self):
        '''
        Tests that the classification target is registered correctly
        '''
        widget = SelectTargetWidget(1)
        widget.add_source(0, self.mock_source)
        widget.set_parameters({'target': 'regress', 'domain': 'domain.regression'})
        widget.evaluate()
        
        output_adf = widget.get_source(0).data
        self.assertEqual(list(output_adf.X.columns), ['col1', 'col2', 'class'])
        self.assertEqual(output_adf.y.name, 'regress')
        self.assertEqual(output_adf.domain, adt.Domain.REGRESSION)

    def test_target_invalid(self):
        '''
        Tests that an exception is raised on invalid target
        '''
        widget = SelectTargetWidget(1)
        widget.add_source(0, self.mock_source)
        widget.set_parameters({'target': 'col2'})
        with self.assertRaises(WidgetException):
            widget.evaluate()


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
