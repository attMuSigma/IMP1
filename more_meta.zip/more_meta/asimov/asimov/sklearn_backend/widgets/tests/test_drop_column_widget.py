# -*- coding: utf-8 -*-
"""
Tests the Drop Column widget
"""
import unittest
import pandas as pd
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets.drop_column_widget import DropColumnWidget
from asimov.sklearn_backend.widgets.draft_widget import WidgetException


class BasicTest(unittest.TestCase):
    
    def setUp(self):
        self.mock_source = SourcePort(0, 0, adt.DataFrame)
        self.mock_source.data = adt.DataFrame(pd.DataFrame([[1,2,3,4],
                                         [5,6,7,8]], columns=['col1', 'col2', 'col3', 'col4']))
    
    def test_initial_state(self):
        '''
        Tests that no parameters are set by default, and that the widget is unevaluated
        '''
        widget = DropColumnWidget(1)
        model = widget.to_dict()
        self.assertEqual(model['widget_uid'], 1)
        self.assertEqual(model['widget_id'], 'data.drop_column')
        self.assertEqual(model['attributes'], {})
        self.assertEqual(model['parameters']['drop_cols']['value'], [])
        self.assertEqual(widget.is_evaluated(), False)
        
    def test_dynamic_params(self):
        '''
        Tests that adding connections updates the dynamic parameters
        '''
        widget = DropColumnWidget(1)
        widget.add_source(0, self.mock_source)
        model = widget.to_dict()
        self.assertEqual(model['parameters']['drop_cols']['options'][0]['options'], ['col1', 'col2', 'col3', 'col4'])
        
        widget.remove_source(0, self.mock_source)
        model = widget.to_dict()
        self.assertEqual(model['parameters']['drop_cols']['options'][0]['options'], [])

    def test_evaluate_with_params(self):
        '''
        Tests that the widget can drop a specified column
        '''
        widget = DropColumnWidget(1)
        widget.set_parameters({'drop_cols': ['col2']})
        
        model = widget.to_dict()
        self.assertEqual(model['parameters']['drop_cols']['value'], ['col2'])
        
        widget.add_source(0, self.mock_source)
        widget.set_parameters({'drop_cols': ['col2']})
        widget.evaluate()
        
        model = widget.to_dict()
        self.assertEqual(model['parameters']['drop_cols']['value'], ['col2'])
        
        adf = widget.get_source(0).data
        pdf_columns = list(adf.X.columns)
        self.assertEqual(list(pdf_columns), ['col1', 'col3', 'col4'])
    
    def test_evaluate_no_params(self):
        '''
        Tests that no columns are dropped if no parameters are set
        '''
        widget = DropColumnWidget(1)
        widget.add_source(0, self.mock_source)
        widget.evaluate()
        adf = widget.get_source(0).data
        pdf_columns = list(adf.X.columns)
        self.assertEqual(pdf_columns, ['col1', 'col2', 'col3', 'col4'])

    def test_set_bad_param(self):
        '''
        Tests that setting invalid parameters raises an exception
        '''
        widget = DropColumnWidget(1)
        with self.assertRaises(WidgetException):
            widget.set_parameters({'wrong_param': ['something']})
        
        model = widget.to_dict()
        self.assertEqual(model['parameters']['drop_cols']['value'], [])

    def test_flush(self):
        '''
        Tests that flushing causes the widget to be unevaluated
        '''
        widget = DropColumnWidget(1)
        widget.add_source(0, self.mock_source)
        widget.evaluate()
        
        self.assertEqual(widget.is_evaluated(), True)
        widget.flush()
        self.assertEqual(widget.is_evaluated(), False)


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)

    
