# -*- coding: utf-8 -*-
"""
Tests the Scatterplot Matrix widget
"""
import unittest
import pandas as pd
from asimov.sklearn_backend.widgets.scatterplot_matrix_widget import ScatterplotMatrixWidget
from asimov.sklearn_backend.widgets.source_port import SourcePort
from asimov.sklearn_backend.widgets import data_types as adt
from asimov.sklearn_backend.widgets.draft_widget import WidgetException
from asimov.sklearn_backend.widgets.sink_port import NotConnected


class BasicTest(unittest.TestCase):

    def setUp(self):
        self.mock_source = SourcePort(0, 0, adt.DataFrame)
        pdf = pd.DataFrame([[1,2,3,4],[5,6,7,8]], columns=['col1', 'col2', 'regress', 'class'])
        self.mock_source.data = adt.DataFrame(pdf)

    def test_basic_evaluation(self):
        '''
        Tests that the widget passes the dataframe through with no target specified
        '''
        widget = ScatterplotMatrixWidget(1)
        with self.assertRaises(NotConnected):
            widget.evaluate()
        model = widget.to_dict()
        self.assertEqual(model['attributes']['plot']['value'], None)
        self.assertEqual(widget.is_evaluated(), False)
        
        widget.add_source(0, self.mock_source)
        with self.assertRaises(WidgetException):
            widget.evaluate()
        self.assertEqual(widget.is_evaluated(), False)
        model = widget.to_dict()
        self.assertEqual(model['attributes']['plot']['value'], None)
        
        widget.set_parameters({'columns': ['col1', 'col2']})
        widget.evaluate()
        self.assertEqual(widget.is_evaluated(), True)
        model = widget.to_dict()
        self.assertEqual(type(model['attributes']['plot']['value']), str)


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
