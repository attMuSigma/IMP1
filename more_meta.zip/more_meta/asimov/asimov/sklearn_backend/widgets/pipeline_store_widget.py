# -*- coding: utf-8 -*-
"""
Provides Pipeline Store Widget
"""
import sys
from mongoengine import connect
import asimov.webapp.app.models.pipeline as pl 
import asimov.sklearn_backend.widgets.data_types as adt
from asimov.sklearn_backend.widgets.draft_widget import BaseWidget, WidgetException
from asimov.sklearn_backend.widgets.sink_port import SingleSink


class PipelineStoreWidget(BaseWidget):
    _widget_id = 'data.pipeline_store'

    def _initialize(self):
        '''
        This widget has no unique initialization routine
        '''

    def _update_ports(self):
        '''
        Creates this widget's ports
        '''
        self._sink_ports[0] = SingleSink(self._widget_uid, 0, adt.Pipeline, name='Pipeline')

    def _update_static_parameters(self):
        '''
        This widget has no static parameters
        '''

    def _evaluate(self):
        '''
        Connects to database and uses pipeline library to update pipeline document
        '''
        pipeline_adt = self._sink_ports[0].data
        try:
            connect(self._context['db_name'], host=self._context['db_host'], port=self._context['db_port'])
            model_id = self._context['model_id']
        except KeyError as e:
            raise WidgetException("Missing context parameter {:}".format(e))
        try:
            pl.update_pipeline_doc(pipeline_adt, model_id)
        except pl.PipelineException as e:
            raise WidgetException("Could not store pipeline: {:}".format(e)).with_traceback(sys.exc_info()[2])

    def _update_attributes(self):
        '''
        This widget has no attributes
        '''

    def _update_dynamic_parameters(self):
        '''
        This widget has no dynamic parameters
        '''
