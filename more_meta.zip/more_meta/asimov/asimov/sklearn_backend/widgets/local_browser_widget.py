# -*- coding: utf-8 -*-
"""
Provides the local file browser widget
"""
import os
from . import data_types as adt
from .draft_widget import BaseWidget
from .draft_widget import WidgetException
from .source_port import SourcePort
from .parameters import Parameter
from .parameters import EnumArg
from .parameters import IntArg
from .attributes import ListAttribute


class LocalBrowserWidget(BaseWidget):
    _widget_id = 'data.local_browser'

    def _initialize(self):
        '''
        This widget has no unique initialization routine
        '''

    def _update_ports(self):
        '''
        Creates this widget's ports
        '''
        self._source_ports[0] = SourcePort(self._widget_uid, 0, adt.Resource)

    def _update_static_parameters(self):
        '''
        Creates static parameters for this widget
        '''
        self._parameters.update({'selected_file': Parameter([EnumArg('', self._read_files())]),
                                 'depth': Parameter([IntArg(1)]),  # TODO: Parameter is not used and should be removed
                                 'root_dir': Parameter([EnumArg('~', ['~', '/'])])})  # TODO: Parameter is not used and should be removed

    def _update_attributes(self):
        '''
        Adds filelist to attributes
        '''
        self._attributes['file_list'] = ListAttribute(self._read_files())  # TODO: This should not be an attribute. Instead use enum dynamic parameter.

    def _evaluate(self):
        '''
        Creates a Resource and places it on the source port
        '''
        selected_file = self._parameters['selected_file'].value
        if not selected_file:
            raise WidgetException('No file has been selected')
        if not os.path.isfile(selected_file):
            raise WidgetException("Selected file does not exist: {:}".format(selected_file))
        self._source_ports[0].data = adt.Resource(adt.ResourceScheme.FILE, selected_file)

    def _update_dynamic_parameters(self):
        '''
        This widget has no dynamic parameters
        '''

    def _read_files(self):
        '''
        Returns a list of files in the data directory
        '''
        return [os.path.join(path, name) for path, subdirs, files in os.walk('/asimov/data') for name in files]
        