# -*- coding: utf-8 -*-
"""
Provides the widget manager class, which resides on the ML Backend and will
interact with the ML Logic component in the middleware.

Implementation Notes:
In the future, this should probably take a JSON as an input instead of having
the backend interface invoke this API directly. This way I can have a single
method to invoke, with the command parameterized, and I dont' have to repeat all
these try-except blocks
"""
from asimov.ml_logic.meta_error import Error
from asimov.sklearn_backend.widget_factory import create_widget as factory_create_widget, FactoryException
from asimov.sklearn_backend.widgets.draft_widget import WidgetException, EvaluationError
from asimov.sklearn_backend.widgets.sink_port import DataUnavailable, NotConnected, InvalidSource, SinkException


def success_status(result=None):
    return {'success': True,
            'result': result}


def failure_status(error, message, result=None):
    return {'success': False,
            'error': str(error),
            'message': str(message),
            'result': result}


class ManagerException(Exception):
    pass


error_lookup = {WidgetException: Error.GENERAL.value, EvaluationError: Error.WIDGET_EVALUATION.value,
                InvalidSource: Error.INVALID_CONNECTION.value, NotConnected: Error.NOT_CONNECTED.value,
                DataUnavailable: Error.DATA_UNAVAILABLE.value, FactoryException: Error.GENERAL.value,
                ManagerException: Error.GENERAL.value, SinkException: Error.INVALID_CONNECTION.value}


class WidgetManager(object):
    def __init__(self, context=None):
        self._context = context
        self._widgets = dict()
    
    def _verify_exist(self, widget_uid):
        '''
        Raises ManagerException if the widget does not exist
        '''
        if widget_uid not in self._widgets:
            raise ManagerException("Widget with UID {:} does not exist".format(widget_uid))
    
    def _verify_not_exist(self, widget_uid):
        '''
        Raises ManagerException if the widget does exist
        '''
        if widget_uid in self._widgets:
            raise ManagerException("Widget with UID {:} already exists".format(widget_uid))
    
    def create_widget(self, widget_id, widget_uid):
        '''
        Instantiates a new widget object corresponding to the widget ID and widget UID
        '''
        try:
            self._verify_not_exist(widget_uid)
            self._widgets[widget_uid] = factory_create_widget(widget_id, widget_uid, context=self._context)
            return success_status()
        except Exception as e:
            return self._handle_error(e)
    
    def delete_widget(self, widget_uid):
        '''
        Flushes and deletes the widget object corresponding to the widget UID
        '''
        try:
            self._verify_exist(widget_uid)
            self._widgets[widget_uid].flush()
            del self._widgets[widget_uid]
            return success_status()
        except Exception as e:
            return self._handle_error(e)
    
    def flush_widget(self, widget_uid):
        '''
        Flushes the widget's output
        '''
        try:
            self._verify_exist(widget_uid)
            self._widgets[widget_uid].flush()
            return success_status()
        except Exception as e:
            return self._handle_error(e)
    
    def create_connection(self, source_wuid, source_port_id, sink_wuid, sink_port_id):
        '''
        Connects a source and sink widget together
        '''
        try:
            self._verify_exist(source_wuid)
            self._verify_exist(sink_wuid)
            source_port = self._widgets[source_wuid].get_source(source_port_id)
            self._widgets[sink_wuid].add_source(sink_port_id, source_port)
            return success_status()
        except Exception as e:
            return self._handle_error(e)
    
    def delete_connection(self, source_wuid, source_port_id, sink_wuid, sink_port_id):
        '''
        Disconnects a source and sink widget
        '''
        try:
            self._verify_exist(source_wuid)
            self._verify_exist(sink_wuid)
            source_port = self._widgets[source_wuid].get_source(source_port_id)
            self._widgets[sink_wuid].remove_source(sink_port_id, source_port)
            return success_status()
        except Exception as e:
            return self._handle_error(e)
    
    def evaluate(self, widget_uid):
        '''
        Attempts to evaluate a widget and returns its model in dict form
        '''
        try:
            self._verify_exist(widget_uid)
            self._widgets[widget_uid].evaluate()
            return success_status()
        except Exception as e:
            return self._handle_error(e, widget_uid)
    
    def apply_parameters(self, widget_uid, params_dict):
        '''
        Sets the parameters of the specified widget
        '''
        try:
            self._verify_exist(widget_uid)
            self._widgets[widget_uid].set_parameters(params_dict)
            return success_status()
        except Exception as e:
            return self._handle_error(e)
    
    def get_model(self, widget_uid):
        '''
        Returns the model of the specified widget in dict form
        '''
        try:
            self._verify_exist(widget_uid)
            widget_model = self._widgets[widget_uid].to_dict()
            return success_status(widget_model)
        except Exception as e:
            return self._handle_error(e, widget_uid)

    def _handle_error(self, e, widget_uid=None):
        '''
        Returns the failure status based on the exception
        '''
        if isinstance(e, ManagerException):
            error = error_lookup[type(e)]
            result = None
        else:
            try:
                error = error_lookup[type(e)]
            except:
                error = Error.GENERAL.value
            finally:
                result = None if widget_uid is None else self._widgets[widget_uid].to_dict()
        return failure_status(error, e, result)
