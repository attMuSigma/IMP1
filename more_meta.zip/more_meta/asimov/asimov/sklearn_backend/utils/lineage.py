# -*- coding: utf-8 -*-
"""
Provides functionality for creating sklearn pipelines from lineage
"""
import pandas as pd
import asimov.sklearn_backend.widgets.data_types as adt
from sklearn.pipeline import Pipeline
from sklearn.pipeline import FeatureUnion
from asimov.sklearn_backend.widgets.draft_widget import TransformWidget
from asimov.sklearn_backend.widgets.pass_estimator import PassEstimator


class LineageException(Exception):
    pass


class LineageBreak(LineageException):
    pass


def extract_pipeline(lineage):
    '''
    Returns a sklearn pipeline from a lineage.
    
    Pipeline break detection is implemented by iterating over the lineage nodes
    and remembering if a transformer has been seen. As soon as a transformer is
    traversed, only transformers should be encountered from thereon out.
    '''
    estimator_list = list()
    transformer_seen = False
    for node in lineage:            
        # a tuple indicates a union of lineages. recursively solve.
        if isinstance(node, tuple):
            sub_pipelines = [extract_pipeline(sub_lineage) for sub_lineage in node]
            sub_pipeline_names = [sub_pipeline.steps[-1][0] for sub_pipeline in sub_pipelines]
            union = FeatureUnion(list(zip(sub_pipeline_names, sub_pipelines)))
            union_name = "|".join(sub_pipeline_names)
            estimator_list.append((union_name, union))
        elif isinstance(node.widget, TransformWidget):
            estimator_list.append(("{:}-{:}".format(node.widget.widget_id, node.widget.widget_uid), node.widget.estimator))
            transformer_seen = True
        else:
            if transformer_seen:
                raise LineageBreak(type(node.widget_deref).__name__)
    if not estimator_list:
        estimator_list.append(('pass_estimator', PassEstimator()))
    return Pipeline(estimator_list)


def extract_signature(lineage):
    '''
    Returns a Pandas Series representing the input signature of the lineage
    
    The signature is taken from the most downstream source widget which is why
    the lineage is traversed in reverse order
    '''
    signatures = list()
    for node in lineage[::-1]:
        # a tuple indicates a union of lineages. recursively solve.
        if isinstance(node, tuple):
            sub_signatures = [extract_signature(sub_lineage) for sub_lineage in node]
            if not sub_signatures:
                raise LineageException('A sub-lineage did not contain a source.')
            signatures.append(pd.concat(sub_signatures))
        elif not isinstance(node.widget, TransformWidget):
            signatures.append(node.dataframe.signature)
            break
    if not signatures:
        raise LineageException('Signature extraction failure. No source widgets were encountered.')
    return pd.concat(signatures)


def extract_source_adf(lineage):
    '''
    Returns the upstream ADF for a given lineage
    '''
    adf_list = list()
    for node in lineage[::-1]:
        # a tuple indicates a union of lineages. recursively solve.
        if isinstance(node, tuple):
            sub_adfs = [extract_source_adf(sub_adf) for sub_adf in node]
            adf_list.append(merge_adfs(sub_adfs))
        elif not isinstance(node.widget, TransformWidget):
            adf_list.append(node.dataframe)
            break
    return merge_adfs(adf_list)


def merge_adfs(adf_list):
    '''
    Returns a single ADF merged from multiple ADFs
    '''
    if not adf_list:
        raise LineageException('A sub-lineage did not contain a source.')
    elif len(adf_list) == 1:
        new_adf = adf_list[0]
    else:
        first_adf = adf_list[0]
        if not all(other_adf.y is first_adf.y for other_adf in adf_list):
            raise LineageException('One or more source dataframes had different targets.')
        if not all(other_adf.domain is first_adf.domain for other_adf in adf_list):
            raise LineageException('One or more source dataframes had different domains.')
        if not all(other_adf.X.index.equals(first_adf.X.index) for other_adf in adf_list):
            raise LineageException('One or more source dataframes had different indexes.')
        new_X = pd.concat([adf.X for adf in adf_list], axis=1, copy=False)
        new_adf = adt.DataFrame(new_X, first_adf.y, first_adf.domain)
    return new_adf
