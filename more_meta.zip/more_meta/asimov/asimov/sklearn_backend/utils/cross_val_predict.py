# -*- coding: utf-8 -*-
"""
Provides cross_val_predict improved method
"""
from __future__ import print_function
from __future__ import division
import numpy as np
import scipy.sparse as sp
from sklearn.base import is_classifier
from sklearn.base import clone
from sklearn.utils import indexable
from sklearn.externals.joblib import Parallel
from sklearn.externals.joblib import delayed
from sklearn.cross_validation import _check_cv
from sklearn.cross_validation import _check_is_partition
from sklearn.cross_validation import _index_param_value
from sklearn.cross_validation import _safe_split


def cross_val_predict(estimator, X, y=None, cv=None, n_jobs=1,
                      verbose=0, fit_params=None, pre_dispatch='2*n_jobs', predict_function='predict'):
    """Generate cross-validated estimates for each input data point
    Parameters
    ----------
    estimator : estimator must implement 'fit' and the methods(s) specified by
        predict_function
    X : array-like
        The data to fit. Can be, for example a list, or an array at least 2d.
    y : array-like, optional, default: None
        The target variable to try to predict in the case of
        supervised learning.
    cv : cross-validation generator or int, optional, default: None
        A cross-validation generator to use. If int, determines
        the number of folds in StratifiedKFold if y is binary
        or multiclass and estimator is a classifier, or the number
        of folds in KFold otherwise. If None, it is equivalent to cv=3.
        This generator must include all elements in the test set exactly once.
        Otherwise, a ValueError is raised.
    n_jobs : integer, optional
        The number of CPUs to use to do the computation. -1 means
        'all CPUs'.
    verbose : integer, optional
        The verbosity level.
    fit_params : dict, optional
        Parameters to pass to the fit method of the estimator.
    pre_dispatch : int, or string, optional
        Controls the number of jobs that get dispatched during parallel
        execution. Reducing this number can be useful to avoid an
        explosion of memory consumption when more jobs get dispatched
        than CPUs can process. This parameter can be:
            - None, in which case all the jobs are immediately
              created and spawned. Use this for lightweight and
              fast-running jobs, to avoid delays due to on-demand
              spawning of the jobs
            - An int, giving the exact number of total jobs that are
              spawned
            - A string, giving an expression as a function of n_jobs,
              as in '2*n_jobs'
    predict_function : string, or list, optional
        Specifies the prediction method(s) to invoke on the provided estimator.
        For example, 'predict_proba' or 'decision_function'. If a list of
        methods is provided, then a tuple of predictions will be returned in
        identical order.
        
    Returns
    -------
    preds : ndarray, or tuple of ndarray
        This is the result of calling the method(s) provided in parameter
        predict_function.
    """
    X, y = indexable(X, y)

    cv = _check_cv(cv, X, y, classifier=is_classifier(estimator))
    # We clone the estimator to make sure that all the folds are
    # independent, and that it is pickle-able.
    parallel = Parallel(n_jobs=n_jobs, verbose=verbose,
                        pre_dispatch=pre_dispatch)
    preds_blocks = parallel(delayed(_fit_and_predict)(clone(estimator), X, y,
                                                      train, test, verbose,
                                                      fit_params, predict_function)
                            for train, test in cv)

    # obtain original indexes from parallelized predictions
    locs = np.concatenate([loc for _, loc in preds_blocks])
    if not _check_is_partition(locs, X.shape[0]):
        raise ValueError('cross_val_predict only works for partitions')
    inv_locs = np.empty(len(locs), dtype=int)
    inv_locs[locs] = np.arange(len(locs))

    # create predictions with correct indexes
    if isinstance(predict_function, str):
        concat_pred = _concat_arrays([p for p, _ in preds_blocks])
        preds = concat_pred[inv_locs]
    else:
        func_preds = list()
        for func_pred in zip(*(p_tuple for p_tuple, _ in preds_blocks)):
            concat_pred = _concat_arrays(func_pred)
            func_preds.append(concat_pred[inv_locs])
        preds = tuple(func_preds)
    return preds


def _concat_arrays(arrays):
    '''Concatenates a sequence of dense or sparse arrays
    Parameters
    ----------
    arrays : sequence of array
    
    Returns
    -------
    concat_array : array
        Concatenated array
    '''
    if sp.issparse(arrays[0]):
        return sp.vstack(arrays, format=arrays[0].format)
    else:
        return np.concatenate(arrays)
    

def _fit_and_predict(estimator, X, y, train, test, verbose, fit_params, predict_function='predict'):
    """Fit estimator and predict values for a given dataset split.
    Parameters
    ----------
    estimator : estimator object
        estimator must implement 'fit' and the methods(s) specified by
        predict_function
    X : array-like of shape at least 2D
        The data to fit.
    y : array-like, optional, default: None
        The target variable to try to predict in the case of
        supervised learning.
    train : array-like, shape (n_train_samples,)
        Indices of training samples.
    test : array-like, shape (n_test_samples,)
        Indices of test samples.
    verbose : integer
        The verbosity level.
    fit_params : dict or None
        Parameters that will be passed to ``estimator.fit``.
    predict_function : string, or list
        Specifies the prediction method(s) to invoke on the provided estimator.
    Returns
    -------
    preds : ndarray, or tuple of ndarray
        This is the result of calling the method(s) provided in parameter
        predict_function.
    test : array-like
        This is the value of the test parameter
    """
    # Adjust length of sample weights
    fit_params = fit_params if fit_params is not None else {}
    fit_params = dict([(k, _index_param_value(X, v, train))
                      for k, v in fit_params.items()])

    X_train, y_train = _safe_split(estimator, X, y, train)
    X_test, _ = _safe_split(estimator, X, y, test, train)

    if y_train is None:
        estimator.fit(X_train, **fit_params)
    else:
        estimator.fit(X_train, y_train, **fit_params)

    if isinstance(predict_function, str):
        preds = getattr(estimator, predict_function)(X_test)
    else:
        preds = tuple(getattr(estimator, func)(X_test) for func in predict_function)
    return preds, test
