# -*- coding: utf-8 -*-
"""
Provides cross_val_predict improved method
"""
import unittest
import numpy as np
from asimov.sklearn_backend.utils.cross_val_predict import cross_val_predict
from sklearn.datasets import load_boston
from sklearn import cross_validation as cval
from sklearn.linear_model import Ridge
from sklearn.utils.testing import assert_equal
from sklearn.utils.testing import assert_raises
from sklearn.utils.testing import assert_array_almost_equal
from scipy.sparse import coo_matrix
from sklearn.cluster import KMeans
from sklearn.datasets import load_iris
from sklearn.neighbors import KNeighborsClassifier


class BasicTest(unittest.TestCase):
        
    def test_cross_val_predict(self):
        '''
        Basic test for cross_val_predict
        '''
        boston = load_boston()
        X, y = boston.data, boston.target
        cv = cval.KFold(len(boston.target))
    
        est = Ridge()
    
        # Naive loop (should be same as cross_val_predict):
        preds2 = np.zeros_like(y)
        for train, test in cv:
            est.fit(X[train], y[train])
            preds2[test] = est.predict(X[test])
    
        preds = cross_val_predict(est, X, y, cv=cv)
        assert_array_almost_equal(preds, preds2)
    
        preds = cross_val_predict(est, X, y)
        assert_equal(len(preds), len(y))
    
        cv = cval.LeaveOneOut(len(y))
        preds = cross_val_predict(est, X, y, cv=cv)
        assert_equal(len(preds), len(y))
    
        Xsp = X.copy()
        Xsp *= (Xsp > np.median(Xsp))
        Xsp = coo_matrix(Xsp)
        preds = cross_val_predict(est, Xsp, y)
        assert_array_almost_equal(len(preds), len(y))
    
        preds = cross_val_predict(KMeans(), X)
        assert_equal(len(preds), len(y))
    
        def bad_cv():
            for i in range(4):
                yield np.array([0, 1, 2, 3]), np.array([4, 5, 6, 7, 8])
    
        assert_raises(ValueError, cross_val_predict, est, X, y, cv=bad_cv())
    
        # setup for exercising the predict_function parameter
        est = KNeighborsClassifier()
        iris = load_iris()
        X, y = iris.data, iris.target
        cv = cval.StratifiedKFold(y)
        # populate prediction arrays via knn classifier ie the 'answers'
        pred_target = np.zeros_like(y)
        pred_proba = np.zeros((y.size, len(iris.target_names)))
        for train, test in cv:
            est.fit(X[train], y[train])
            pred_target[test] = est.predict(X[test])
            pred_proba[test, :] = est.predict_proba(X[test])
        # test string argument for predict_function
        pred_proba_cvp = cross_val_predict(est, X, y, cv=cv, predict_function='predict_proba')
        assert_array_almost_equal(pred_proba, pred_proba_cvp)
        # test multi-function list argument for predict_function
        pred_target_cvp, pred_proba_cvp = cross_val_predict(est, X, y, cv=cv, predict_function=['predict', 'predict_proba'])
        assert_array_almost_equal(pred_target, pred_target_cvp)
        assert_array_almost_equal(pred_proba, pred_proba_cvp)


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)