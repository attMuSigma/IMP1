# -*- coding: utf-8 -*-
"""
Tests the pipeline creator utility
"""
import unittest
import pandas as pd
import asimov.sklearn_backend.widgets.data_types as adt
import asimov.sklearn_backend.utils.lineage as lin
from asimov.sklearn_backend.widgets.pass_estimator import PassEstimator
from asimov.sklearn_backend.widgets.pass_estimator import PassWidget
from asimov.sklearn_backend.widgets.mock_source_widget import MockSourceWidget


class PipelineExtractTest(unittest.TestCase):
    
    def setUp(self):
        self.X1 = pd.DataFrame([[1,2], [1,2]], columns=['col1', 'col2'])
        self.X2 = pd.DataFrame([[3,4], [3,4]], columns=['col3', 'col4'])
        self.X3 = pd.DataFrame([[5,6], [5,6]], columns=['col5', 'col6'])

    def test_simple_extraction(self):
        '''
        Tests a simple linear pipeline extraction as shown below
        
        1 - 2 - 3 -
        '''
        # source 1
        parent1 = MockSourceWidget('widget', 1)
        adf1 = adt.DataFrame(self.X1, parent_widget=parent1)
        # source 2 (think "select target" widget)
        parent2 = MockSourceWidget('widget', 2)
        adf2 = adt.DataFrame(self.X2, parent_widget=parent2, source_adfs=adf1)
        # a "transformer" widget
        parent3 = PassWidget('widget', 3)
        adf3 = adt.DataFrame(self.X3, parent_widget=parent3, source_adfs=[adf2])
        # make sure sklearn pipeline is created correctly
        pipeline = lin.extract_pipeline(adf3.lineage)
        self.assertTrue(pipeline.steps[0][0] == 'widget-3')
        self.assertTrue(isinstance(pipeline.steps[0][1], PassEstimator))
        # make sure the sklearn pipeline works as expected
        X_trans = pipeline.fit_transform(self.X1.as_matrix())
        self.assertTrue(X_trans.tolist() == [[1,2], [1,2]])

    def test_union_extraction(self):
        '''
        Tests a union pipeline extraction (i.e. a V-structure) as shown below

        1 - 3
              \
                5 - 
              /
        2 - 4
        '''
        # two sources were used to make a dataframe
        parent1 = MockSourceWidget('widget', 1)
        adf1 = adt.DataFrame(self.X1, parent_widget=parent1)
        parent2 = MockSourceWidget('widget', 2)
        adf2 = adt.DataFrame(self.X1, parent_widget=parent2)
        # the V structure
        parent3 = PassWidget('widget', 3)
        adf3 = adt.DataFrame(self.X1, parent_widget=parent3, source_adfs=adf1)
        parent4 = PassWidget('widget', 4)
        adf4 = adt.DataFrame(self.X1, parent_widget=parent4, source_adfs=adf2)
        parent5 = PassWidget('widget', 5)
        adf5 = adt.DataFrame(self.X1, parent_widget=parent5, source_adfs=[adf3, adf4])
        # test for correct structure
        pipeline = lin.extract_pipeline(adf5.lineage)
        self.assertTrue(pipeline.steps[0][0] == 'widget-3|widget-4')
        self.assertTrue(pipeline.steps[0][1].transformer_list[0][0] == 'widget-3')
        self.assertTrue(pipeline.steps[0][1].transformer_list[1][0] == 'widget-4')
        self.assertTrue(pipeline.steps[1][0] == 'widget-5')


class SignatureExtractTest(unittest.TestCase):
    
    def setUp(self):
        self.X1 = pd.DataFrame([[1,2.], [1,2.]], columns=['col1', 'col2'])
        self.X2 = pd.DataFrame([[3.,4], [3.,4]], columns=['col3', 'col4'])
        self.X3 = pd.DataFrame([[5,6], [5,6]], columns=['col5', 'col6'])

    def test_simple_signature(self):
        '''
        Tests a simple signature extraction from a pipeline
        '''
        # source 1
        parent1 = MockSourceWidget('source', 1)
        adf1 = adt.DataFrame(self.X1, parent_widget=parent1)
        # source 2 (think "select target" widget)
        parent2 = MockSourceWidget('another-source', 2)
        adf2 = adt.DataFrame(self.X2, parent_widget=parent2, source_adfs=adf1)
        # a "transformer" widget
        parent3 = PassWidget('transformer', 3)
        adf3 = adt.DataFrame(self.X3, parent_widget=parent3, source_adfs=[adf2])
        sig3 = lin.extract_signature(adf3.lineage)
        self.assertTrue(self.X2.dtypes.equals(sig3))
    
    def test_union_signature(self):
        '''
        Tests a union signature extraction (i.e. a V-structure)
        '''
        # two sources were used to make a dataframe
        parent1 = MockSourceWidget('source', 1)
        adf1 = adt.DataFrame(self.X1, parent_widget=parent1)
        parent2 = MockSourceWidget('another-source', 2)
        adf2 = adt.DataFrame(self.X2, parent_widget=parent2)
        # a "transformer" widget
        parent3 = PassWidget('transformer', 3)
        adf3 = adt.DataFrame(self.X3, parent_widget=parent3, source_adfs=[adf1, adf2])
        sig3 = lin.extract_signature(adf3.lineage)
        self.assertTrue(sig3.equals(pd.concat([adf1.X.dtypes, adf2.X.dtypes])))


class SourceExtractTest(unittest.TestCase):
    
    def setUp(self):
        self.X1 = pd.DataFrame([[1,2.], [1,2.]], columns=['col1', 'col2'])
        self.X2 = pd.DataFrame([[3.,4], [3.,4]], columns=['col3', 'col4'])
        self.X3 = pd.DataFrame([[5,6], [5,6]], columns=['col5', 'col6'])

    def test_simple_signature(self):
        '''
        Tests a simple signature extraction from a pipeline
        '''
        # source 1
        parent1 = MockSourceWidget('source', 1)
        adf1 = adt.DataFrame(self.X1, parent_widget=parent1)
        # source 2 (think "select target" widget)
        parent2 = MockSourceWidget('another-source', 2)
        adf2 = adt.DataFrame(self.X2, parent_widget=parent2, source_adfs=adf1)
        # a "transformer" widget
        parent3 = PassWidget('transformer', 3)
        adf3 = adt.DataFrame(self.X3, parent_widget=parent3, source_adfs=[adf2])
        # since no data is copied, the identity of X2 should hold
        src_adf = lin.extract_source_adf(adf3.lineage)
        self.assertIs(src_adf.X, self.X2)
    
    def test_union_signature(self):
        '''
        Tests a union source extraction (i.e. a V-structure) as shown below

        1 - 3
              \
                5 - 
              /
        2 - 4
        '''
        # two sources were used to make a dataframe
        parent1 = MockSourceWidget('widget', 1)
        adf1 = adt.DataFrame(self.X1, parent_widget=parent1)
        parent2 = MockSourceWidget('widget', 2)
        adf2 = adt.DataFrame(self.X2, parent_widget=parent2)
        # the V structure
        parent3 = PassWidget('widget', 3)
        adf3 = adt.DataFrame(self.X1, parent_widget=parent3, source_adfs=adf1)
        parent4 = PassWidget('widget', 4)
        adf4 = adt.DataFrame(self.X1, parent_widget=parent4, source_adfs=adf2)
        parent5 = PassWidget('widget', 5)
        adf5 = adt.DataFrame(self.X1, parent_widget=parent5, source_adfs=[adf3, adf4])
        # test for correct ADF
        src_adf = lin.extract_source_adf(adf5.lineage)
        self.assertTrue(src_adf.X.equals(pd.concat([self.X1, self.X2], axis=1)))


if __name__ == '__main__':
    '''
    Test area
    '''
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    suite.addTest(loader.loadTestsFromTestCase(PipelineExtractTest))
    suite.addTest(loader.loadTestsFromTestCase(SignatureExtractTest))
    suite.addTest(loader.loadTestsFromTestCase(SourceExtractTest))
    unittest.TextTestRunner(verbosity=2).run(suite)