# -*- coding: utf-8 -*-
"""
Provides utilities for creating mock pipelines
"""
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.datasets import load_iris
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from asimov.sklearn_backend.widgets import data_types as adt


class mocked_pipeline(object):
    '''
    Context manager which creates mock pipelines
    '''

    def __enter__(self):
        # train the pipeline and predict
        iris = load_iris()
        X, y = iris.data, iris.target_names[iris.target]
        pipeline_sk = Pipeline([('scaler', StandardScaler()), ('logistic', LogisticRegression())])
        pipeline_sk.fit(X, y)
        y_pred = pipeline_sk.predict(X)
        y_pred_proba = pipeline_sk.predict_proba(X)
        # save the pipeline
        X_pdf = pd.DataFrame(X, columns=list(iris.feature_names))
        y_ps = pd.Series(y, name='species')
        X_adf = adt.DataFrame(X_pdf, y_ps, adt.Domain.CLASSIFICATION)
        pipeline_adt = adt.Pipeline('logistic', pipeline_sk, adt.Domain.CLASSIFICATION, X_adf.signature)
        self.class_pipeline_adt = pipeline_adt
        self.class_pipeline_sk = pipeline_sk
        self.class_dataframe_adt = X_adf
        self.class_X_nd = X
        self.class_y_nd = y
        self.class_y_pred_nd = y_pred
        self.class_y_pred_proba_nd = y_pred_proba
        return self

    def __exit__(self, type, value, tb):
        pass
