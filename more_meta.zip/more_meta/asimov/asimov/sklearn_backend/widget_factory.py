# -*- coding: utf-8 -*-
"""
Provides the widget factory method
"""
from asimov.sklearn_backend.widgets.drop_column_widget import DropColumnWidget
from asimov.sklearn_backend.widgets.pca_widget import PcaWidget
from asimov.sklearn_backend.widgets.csv_widget import CsvWidget
from asimov.sklearn_backend.widgets.local_browser_widget import LocalBrowserWidget
from asimov.sklearn_backend.widgets.dataframe_sampler_widget import SamplerWidget
from asimov.sklearn_backend.widgets.dataframe_split_widget import DataframeSplitWidget
from asimov.sklearn_backend.widgets.select_target_widget import SelectTargetWidget
from asimov.sklearn_backend.widgets.scatterplot_matrix_widget import ScatterplotMatrixWidget
from asimov.sklearn_backend.widgets.gradient_boosting_classifier_widget import GradientBoostingClassifierWidget
from asimov.sklearn_backend.widgets.roc_curve_widget import RocCurveWidget
from asimov.sklearn_backend.widgets.cross_validate_widget import CrossValidateWidget
from asimov.sklearn_backend.widgets.pipeline_store_widget import PipelineStoreWidget
from asimov.sklearn_backend.widgets.pipeline_predict_widget import PipelinePredictWidget
from asimov.sklearn_backend.widgets.svc_widget import SvcWidget
from asimov.sklearn_backend.widgets.confusion_matrix_widget import ConfusionMatrixWidget


class FactoryException(Exception):
    pass


widgets = [PcaWidget, DropColumnWidget, CsvWidget, LocalBrowserWidget, SamplerWidget, DataframeSplitWidget,
           SelectTargetWidget, ScatterplotMatrixWidget, GradientBoostingClassifierWidget, RocCurveWidget,
           CrossValidateWidget, PipelineStoreWidget, PipelinePredictWidget, SvcWidget, ConfusionMatrixWidget]

widget_ids = [widget(0).widget_id for widget in widgets]
widget_lookup = dict(zip(widget_ids, widgets))


def create_widget(widget_id, widget_uid, context=None):
    '''
    Returns an instantiated widget with specified ID and UID
    
    Parameters
    ----------
    widget_id : string
        The unique string for a specific widget class
    widget_uid : int
        A unique integer which acts as a handler for referring to a specific widget object
    
    Returns
    -------
    widget : Object derived from abstract class BaseWidget
    '''
    if not isinstance(widget_uid, int) or widget_uid < 0:
        raise FactoryException('Widget UID must be a positive integer')
    try:
        return widget_lookup[widget_id](widget_uid, context=context)
    except KeyError as e:
        raise FactoryException("Specified widget ID {:} does not exist".format(e))
