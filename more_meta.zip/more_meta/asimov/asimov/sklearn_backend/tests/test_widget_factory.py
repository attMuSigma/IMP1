# -*- coding: utf-8 -*-
"""
Tests the widget factory
"""
import unittest
import asimov.sklearn_backend.widget_factory as factory

class BasicTest(unittest.TestCase):

    def test_basic_factory(self):
        '''
        Tests the creation of a couple of available widgets
        '''
        drop_widget = factory.create_widget('data.drop_column', 0)
        pca_widget = factory.create_widget('decomposition.pca', 1)
        csv_widget = factory.create_widget('data.csv', 2)
        
        self.assertEqual(drop_widget.widget_id, 'data.drop_column')
        self.assertEqual(drop_widget.widget_uid, 0)
        self.assertEqual(pca_widget.widget_id, 'decomposition.pca')
        self.assertEqual(pca_widget.widget_uid, 1)
        self.assertEqual(csv_widget.widget_id, 'data.csv')
        self.assertEqual(csv_widget.widget_uid, 2)


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
