# -*- coding: utf-8 -*-
"""
Tests the widget manager
"""
import unittest
import os
import json
from asimov.sklearn_backend.widget_manager import WidgetManager


class BasicTest(unittest.TestCase):

    def test_basic_chain(self):
        '''
        Exercises the manager by chaining together three widgets and evaluating them
        '''
        manager = WidgetManager()
        self.assertTrue(manager.create_widget('data.csv', 1)['success'])
        self.assertTrue(manager.create_widget('data.drop_column', 2)['success'])
        self.assertTrue(manager.create_widget('decomposition.pca', 3)['success'])
        self.assertTrue(not manager.evaluate(1)['success'])
        
        test_dir = os.path.dirname(os.path.realpath(__file__))
        test_file = os.path.join(test_dir,'test_data.csv')
        self.assertTrue(manager.apply_parameters(1, {'filepath': test_file, 'separator': ','})['success'])
        self.assertTrue(manager.evaluate(1)['success'])
        self.assertTrue(manager.create_connection(1, 0, 2, 0)['success'])
        
        manager.evaluate(2)
        output = manager.get_model(2)
        self.assertTrue(output['success'])
        self.assertEqual(output['result']['parameters']['drop_cols']['options'][0]['options'], ['Feature1', 'Feature2', 'Feature3', 'Feature4'])
        self.assertTrue(manager.delete_connection(1, 0, 2, 0)['success'])
        self.assertTrue(not manager.evaluate(2)['success'])

        output = manager.get_model(2)
        self.assertEqual(output['result']['parameters']['drop_cols']['options'][0]['options'], [])        
        self.assertTrue(manager.create_connection(1, 0, 2, 0)['success'])
        self.assertTrue(manager.create_connection(2, 0, 3, 0)['success'])
        self.assertTrue(manager.evaluate(1)['success'])
        self.assertTrue(manager.evaluate(2)['success'])
        self.assertTrue(manager.evaluate(3)['success'])
        
        #make sure you can JSONize these models
        output = manager.evaluate(3)
        json.dumps(output)
    
    def test_csv_split_integration(self):
        '''
        Integration test for splitting a dataframe loaded by CSV reader
        '''
        manager = WidgetManager()
        self.assertTrue(manager.create_widget('data.csv', 1)['success'])
        self.assertTrue(manager.create_widget('data.dataframe_split', 2)['success'])
        self.assertTrue(manager.create_widget('data.dataframe_sampler', 3)['success'])
        self.assertTrue(manager.create_widget('data.dataframe_sampler', 4)['success'])
        
        # load the CSV
        test_dir = os.path.dirname(os.path.realpath(__file__))
        test_file = os.path.join(test_dir,'test_data.csv')
        self.assertTrue(manager.apply_parameters(1, {'filepath': test_file, 'separator': ','})['success'])
        self.assertTrue(manager.evaluate(1)['success'])

        # hook up the splitter
        self.assertTrue(manager.create_connection(1, 0, 2, 0)['success'])  
        manager.evaluate(2)
        output = manager.get_model(2)
        self.assertTrue(output['success'])

        # attach a sampler to split A
        self.assertTrue(manager.create_connection(2, 0, 3, 0)['success'])
        manager.evaluate(3)
        output = manager.get_model(3)
        self.assertTrue(output['success'])
        
        # these magic numbers should be the same for Split A since a seed of 0 is used by default
        for index in {0, 1, 3, 5, 6, 7, 9}:
            self.assertEqual(output['result']['attributes']['samples']['value']['X']['value']["{:}".format(index)], [index]*4)

        # attach a sampler to split B
        self.assertTrue(manager.create_connection(2, 1, 4, 0)['success'])        
        manager.evaluate(4)
        output = manager.get_model(4)
        self.assertTrue(output['success'])

        # likewise these magic numbers will always be the same for Split B in this test
        for index in {2, 4, 8}:
            self.assertEqual(output['result']['attributes']['samples']['value']['X']['value']["{:}".format(index)], [index]*4)


    def test_roc_curve(self):
        '''
        Integration test for the new cross validation and ROC curve widgets
        '''
        # create manager and all widgets
        manager = WidgetManager()
        self.assertTrue(manager.create_widget('data.csv', 1)['success'])
        self.assertTrue(manager.create_widget('data.select_target', 2)['success'])
        self.assertTrue(manager.create_widget('supervised.gradient_boosting_classifier', 3)['success'])
        self.assertTrue(manager.create_widget('evaluation.cross_validate', 4)['success'])
        self.assertTrue(manager.create_widget('viz.roc_curve', 5)['success'])
        
        # load and evaluate the CSV
        test_dir = os.path.dirname(os.path.realpath(__file__))
        test_file = os.path.join(test_dir,'iris.csv')
        self.assertTrue(manager.apply_parameters(1, {'filepath': test_file, 'separator': ','})['success'])
        self.assertTrue(manager.evaluate(1)['success'])

        # connect raw CSV DF to select target and evaluate
        self.assertTrue(manager.create_connection(1, 0, 2, 0)['success'])
        self.assertTrue(manager.apply_parameters(2, {'target': 'Species', 'domain': 'domain.classification'})['success'])
        self.assertTrue(manager.evaluate(2)['success'])

        # instantiate and connect the gradient boosting classifier (default params)
        self.assertTrue(manager.evaluate(3)['success'])
    
        # connect dataframe and estimator to evaluator
        self.assertTrue(manager.create_connection(2, 0, 4, 0)['success'])
        self.assertTrue(manager.create_connection(3, 0, 4, 1)['success'])
        
        # evaluate the cross validate widget with default parameters
        self.assertTrue(manager.evaluate(4)['success'])

        # connect the prediction results to the ROC curve widget
        self.assertTrue(manager.create_connection(4, 0, 5, 0)['success'])
        self.assertTrue(manager.evaluate(5)['success'])


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
