import matplotlib
matplotlib.use('Agg')  # avoid running X Server