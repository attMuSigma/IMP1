# -*- coding: utf-8 -*-
"""
Provides the Backend Interface class

The Backend Interface is an abstraction which communicates with a Jupyter Kernel.
As there's no need to introduce the complexity of kernel management, the logic which
would normally be running on the kernel is instead contained by the interface.

Eventually, the interface will contain an RPC client and kernel client, and perform
the same operations via RPCs. The RPCs themselves would contain success/failure messages
with predefined codes, and the same exceptions would be raised.

The RPC responses will be generic across all backends. But each backend will be
specialized to communicate the language-specific commands on its respective kernel.
"""
import os
import ast
import pickle
from asimov.sklearn_backend.widget_manager import WidgetManager
from jupyter_client.manager import KernelManager


class BackendInterfaceException(Exception):
    pass


class BackendInterface(object):
    
    @staticmethod
    def create_backend(backend_name, context=None):
        try:
            return backend_lookup[backend_name](context)
        except KeyError as e:
            raise BackendInterfaceException("Specified backend {:} is not supported".format(e))
    
    def create_widget(self, widget_id, widget_uid):
        raise NotImplementedError()
    
    def delete_widget(self, widget_uid):
        raise NotImplementedError()
    
    def create_connection(self, source_wuid, source_port_id, sink_wuid, sink_port_id):
        raise NotImplementedError()
    
    def delete_connection(self, source_wuid, source_port_id, sink_wuid, sink_port_id):
        raise NotImplementedError()
    
    def evaluate(self, widget_uid):
        raise NotImplementedError()
    
    def apply_parameters(self, widget_uid, params_dict):
        raise NotImplementedError()
    
    def get_model(self, widget_uid):
        raise NotImplementedError()
    
    def flush_widget(self, widget_uid):
        raise NotImplementedError()
    
    def interrupt(self):
        raise NotImplementedError()
    
    def restart(self):
        raise NotImplementedError()
    
    def terminate(self):
        raise NotImplementedError()
    

class SklearnEmbeddedInterface(BackendInterface):
    def __init__(self, context=None):
        self._manager = WidgetManager(context)
    
    def create_widget(self, widget_id, widget_uid):
        return self._manager.create_widget(widget_id, widget_uid)
    
    def delete_widget(self, widget_uid):
        return self._manager.delete_widget(widget_uid)
    
    def create_connection(self, source_wuid, source_port_id, sink_wuid, sink_port_id):
        return self._manager.create_connection(source_wuid, source_port_id, sink_wuid, sink_port_id)
    
    def delete_connection(self, source_wuid, source_port_id, sink_wuid, sink_port_id):
        return self._manager.delete_connection(source_wuid, source_port_id, sink_wuid, sink_port_id)
    
    def evaluate(self, widget_uid):
        return self._manager.evaluate(widget_uid)
    
    def apply_parameters(self, widget_uid, params_dict):
        return self._manager.apply_parameters(widget_uid, params_dict)
    
    def get_model(self, widget_uid):
        return self._manager.get_model(widget_uid)

    def flush_widget(self, widget_uid):
        return self._manager.flush_widget(widget_uid)
    
    def interrupt(self):
        pass
    
    def restart(self):
        pass
    
    def terminate(self):
        pass


import_code_template = '''
import pickle
import sys
sys.path.insert(1, '{:}')
from asimov.sklearn_backend.widget_manager import WidgetManager'''

init_code_template = '''
manager = WidgetManager(**{:})'''

method_code_template = '''
output = manager.{:}(**{:})'''


class SklearnJupyterInterface(BackendInterface):
    
    def __init__(self, context=None):
        self._manager = KernelManager(kernel_name='python')
        self._manager.start_kernel()
        self._client = self._manager.client()
        self._client.start_channels(iopub=False, stdin=False, hb=False)
        self._initialize_kernel(context)
    
    def _initialize_kernel(self, context):
        '''
        Creates required local variables
        '''
        import_code = import_code_template.format(self._get_asimov_dir())
        self._execute(import_code)
        init_code = init_code_template.format({'context': context})
        self._execute(init_code)
    
    def _get_asimov_dir(self):
        '''
        Returns the absolute directory to the ASIMOV package
        '''
        try:
            return os.environ['ASIMOV']
        except KeyError as e:
            raise BackendInterfaceException("{:} environment variable must be set and pointing to asimov package".format(e))

    def _execute(self, code, expressions=None):
        '''
        Executes the provided code and waits until a response is provided
        '''
        msg_id = self._client.execute(code, user_expressions=expressions)
        while True:
            msg = self._client.get_shell_msg()
            if msg['parent_header']['msg_id'] == msg_id:
                break
        if msg['content']['status'] == 'error':
            raise BackendInterfaceException("Kernel execution error: {:}: {:}".format(msg['content']['ename'], msg['content']['evalue']))
        return(msg['content']['user_expressions'])
    
    def _execute_method(self, method, args):
        '''
        Helper method for executing methods and getting dict responses back
        '''
        code = method_code_template.format(method, args)
        content_dict = self._execute(code, {'output': 'pickle.dumps(output)'})
        try:
            response_bytes = ast.literal_eval(content_dict['output']['data']['text/plain'])
            response_dict = pickle.loads(response_bytes)
        except Exception as e:
            raise BackendInterfaceException("Kernel parse failure: {:}".format(e))
        return response_dict

    def create_widget(self, widget_id, widget_uid):
        return self._execute_method('create_widget', {'widget_id': widget_id, 'widget_uid': widget_uid})
    
    def delete_widget(self, widget_uid):
        return self._execute_method('delete_widget', {'widget_uid': widget_uid})
    
    def create_connection(self, source_wuid, source_port_id, sink_wuid, sink_port_id):
        return self._execute_method('create_connection', {'source_wuid': source_wuid, 'source_port_id': source_port_id, 'sink_wuid': sink_wuid, 'sink_port_id': sink_port_id})
    
    def delete_connection(self, source_wuid, source_port_id, sink_wuid, sink_port_id):
        return self._execute_method('delete_connection', {'source_wuid': source_wuid, 'source_port_id': source_port_id, 'sink_wuid': sink_wuid, 'sink_port_id': sink_port_id})
    
    def evaluate(self, widget_uid):
        return self._execute_method('evaluate', {'widget_uid': widget_uid})
    
    def apply_parameters(self, widget_uid, params_dict):
        return self._execute_method('apply_parameters', {'widget_uid': widget_uid, 'params_dict': params_dict})
    
    def get_model(self, widget_uid):
        return self._execute_method('get_model', {'widget_uid': widget_uid})

    def flush_widget(self, widget_uid):
        return self._execute_method('flush_widget', {'widget_uid': widget_uid})
    
    def interrupt(self):
        self._manager.interrupt_kernel()
    
    def restart(self):
        self._manager.restart_kernel()
    
    def terminate(self):
        self._manager.shutdown_kernel()


backend_lookup = {'sklearn_embedded': SklearnEmbeddedInterface,
                  'sklearn_jupyter': SklearnJupyterInterface}
