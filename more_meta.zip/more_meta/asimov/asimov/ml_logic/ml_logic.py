# -*- coding: utf-8 -*-
"""
Provides the ML Logic class, which acts as the interface between the middleware
and ML Backend.
"""
import warnings
import networkx as nx
from tornado.concurrent import futures
from asimov.ml_logic import ml_logic_algorithms as mla 
from asimov.ml_logic.meta_error import WidgetException
from asimov.ml_logic.backend_interface import BackendInterface, BackendInterfaceException


class Session(object):
    def __init__(self, project_id, model_id, async, persist, backend):
        self._backend = backend
        self._project_id = project_id
        self._model_id = model_id
        self._async = async
        self._persist = persist
        self._graph = nx.DiGraph()
    
    @property
    def backend(self):
        return self._backend
    
    @property
    def project_id(self):
        return self._project_id
    
    @property
    def model_id(self):
        return self._model_id
    
    @property
    def graph(self):
        return self._graph
    
    @property
    def async(self):
        return self._async
    
    @property
    def persist(self):
        return self._persist
        

class LogicException(Exception):
    pass


class MlLogic(object):
    _thread_pool = futures.ThreadPoolExecutor(max_workers=50)  # magic number, sorry

    def __init__(self, async, persist, context=None):
        '''
        Initializes the ML Logic.
        
        Parameters
        ----------
        async : object
            Instantiated object with interface defined in http://wiki.web.att.com/display/AVP/Sprint+1+Component+Interface%3A+Asynchronous+Bus
        persist : object
            Instantiated object with interface defined in http://wiki.web.att.com/display/AVP/Sprint+1+Component+Interface%3A+Persistence+Logic
        '''
        self._async = async
        self._persist = persist
        self._sessions = dict()
        self._context = dict() if context is None else context

    def async_method(self, method_name, **kwargs):
        '''
        Executes a method of choice and returns a future
        
        method_name : string
            The name of the MLLogic method to invoke
        kwargs : key word arguments
            Method-specific key word arguments
        '''
        method = getattr(self, method_name)
        return self._thread_pool.submit(method, **kwargs)
    
    def load_session(self, session_model):
        '''
        Recreates a session from a previously saved session model
        
        Parameters
        ----------
        session_model : dict
            Dictionary which contains:
                - project_id : Unique string corresponding to a project
                - model_id : Unique string corresponding to the model being developed under this project
                - widgets : Dict whose keys are widget UIDs and values are widget model dicts

        Raises
        -------
        LogicException
            If the operation is unsuccessful
        '''
        try:
            project_id = session_model['project_id']
            model_id = session_model['model_id']
            widget_models = session_model['widgets']
            if 'backend' not in session_model:
                warnings.warn('backend must be specified in the session_model parameter dict')
                backend = 'sklearn_jupyter'
            else:
                backend = session_model['backend']
        except KeyError as e:
            raise LogicException("Session model is missing required field: {:}".format(e))
        
        session_key = self._create_session_key(project_id, model_id)
        self._verify_session_not_exist(session_key)

        try:
            session = self._create_session(project_id, model_id, backend)
            self._sessions[session_key] = session  # immediately add to state for other thread access
            mla.load_session(widget_models, session)
        except WidgetException as e:
            self.end_session(project_id, model_id)
            self._reraise(e)

    def begin_session(self, project_id, model_id, backend='sklearn_jupyter'):
        '''
        Creates a manager for the specified session

        Parameters
        ----------
        project_id : string
            Unique string corresponding to a project
        model_id : string
            Unique string corresponding to the model being developed under this project
        backend : string
            String which identifies which backend to instantiate

        Raises
        -------
        LogicException
            If the operation is unsuccessful
        '''
        session_key = self._create_session_key(project_id, model_id)
        self._verify_session_not_exist(session_key)
        self._sessions[session_key] = self._create_session(project_id, model_id, backend)

    def end_session(self, project_id, model_id):
        '''
        Deletes a manager for the specified session
        
        Parameters
        ----------
        project_id : string
            Unique string corresponding to a project
        model_id : string
            Unique string corresponding to the model being developed under this project
        
        Raises
        -------
        LogicException
            If the operation is unsuccessful
        '''
        session_key = self._create_session_key(project_id, model_id)
        session = self._verify_session_exist(session_key)
        session.backend.terminate()
        del self._sessions[session_key]

    def interrupt_session(self, project_id, model_id):
        '''
        Interrupts a manager for the specified session
        
        Parameters
        ----------
        project_id : string
            Unique string corresponding to a project
        model_id : string
            Unique string corresponding to the model being developed under this project
        
        Raises
        -------
        LogicException
            If the operation is unsuccessful
        '''
        session_key = self._create_session_key(project_id, model_id)
        session = self._verify_session_exist(session_key)
        try:
            session.backend.interrupt()
        except Exception as e:
            self._reraise(e)

    def create_widget(self, project_id, model_id, widget_id, widget_uid):
        '''
        Creates the specified widget and persists its model.
        
        Parameters
        ----------
        project_id : string
            Unique string corresponding to a project
        model_id : string
            Unique string corresponding to the model being developed under this project
        widget_id : string
            A string corresponding to the widget class
        widget_uid : int
            A unique integer which acts as a handler for referring to a specific widget
        
        Raises
        -------
        LogicException
            If the operation is unsuccessful
        '''
        try:
            session_key = self._create_session_key(project_id, model_id)
            session = self._verify_session_exist(session_key)
            mla.create_widget(widget_id, widget_uid, session)
            return mla.get_widget_model(widget_uid, session)
        except WidgetException as e:
            self._reraise(e)
    
    def delete_widget(self, project_id, model_id, widget_uid):
        '''
        Deletes the specified widget and removes its model from the database.
        
        Parameters
        ----------
        project_id : string
            Unique string corresponding to a project
        model_id : string
            Unique string corresponding to the model being developed under this project
        widget_uid : int
            A unique integer which acts as a handler for referring to a specific widget
        
        Raises
        -------
        LogicException
            If the operation is unsuccessful
        '''
        try:
            session_key = self._create_session_key(project_id, model_id)
            session = self._verify_session_exist(session_key)
            mla.delete_widget(widget_uid, session)
        except WidgetException as e:
            self._reraise(e)

    def create_connection(self, project_id, model_id, connection):
        '''
        Connects a source and sink widget, and updates the sink widget's model
        
        Parameters
        ----------
        project_id : string
            Unique string corresponding to a project
        model_id : string
            Unique string corresponding to the model being developed under this project
        connection : dict
            A dict with structured defined in http://wiki.web.att.com/display/AVP/Sprint+1+JSON+Schema+-+Connection
        
        Raises
        -------
        LogicException
            If the operation is unsuccessful
        '''
        try:
            source_wuid, source_port, sink_wuid, sink_port = self._verify_connection(connection)
            session_key = self._create_session_key(project_id, model_id)
            session = self._verify_session_exist(session_key)
            mla.create_connection(source_wuid, source_port, sink_wuid, sink_port, session)
            return mla.get_widget_model(sink_wuid, session)
        except WidgetException as e:
            self._reraise(e)
    
    def delete_connection(self, project_id, model_id, connection):
        '''
        Disconnects a source and sink widget, and updates the sink widget's model
        
        Parameters
        ----------
        project_id : string
            Unique string corresponding to a project
        model_id : string
            Unique string corresponding to the model being developed under this project
        connection : dict
            A dict with structured defined in http://wiki.web.att.com/display/AVP/Sprint+1+JSON+Schema+-+Connection
        
        Raises
        -------
        LogicException
            If the operation is unsuccessful
        '''
        try:
            source_wuid, source_port, sink_wuid, sink_port = self._verify_connection(connection)
            session_key = self._create_session_key(project_id, model_id)
            session = self._verify_session_exist(session_key)
            mla.delete_connection(source_wuid, source_port, sink_wuid, sink_port, session)
            return mla.get_widget_model(sink_wuid, session)
        except WidgetException as e:
            self._reraise(e)
    
    def apply_parameters(self, project_id, model_id, widget_uid, parameters):
        '''
        Applies new parameters to the specified widget and updates its model
        
        Parameters
        ----------
        project_id : string
            Unique string corresponding to a project
        model_id : string
            Unique string corresponding to the model being developed under this project
        widget_uid : int
            A unique integer which acts as a handler for referring to a specific widget
        parameters : dict
            A dict with structured defined in http://wiki.web.att.com/display/AVP/Sprint+1+JSON+Schema+-+Widget+Parameter
        
        Raises
        -------
        LogicException
            If the operation is unsuccessful
        '''
        try:
            session_key = self._create_session_key(project_id, model_id)
            session = self._verify_session_exist(session_key)
            mla.apply_parameters(widget_uid, parameters, session)
            return mla.get_widget_model(widget_uid, session)
        except WidgetException as e:
            self._reraise(e)
    
    def get_widget_models(self, project_id, model_id):
        '''
        Returns all widget models in a session
        
        Parameters
        ----------
        project_id : string
            Unique string corresponding to a project
        model_id : string
            Unique string corresponding to the model being developed under this project
        
        Returns
        -------
        widget_models : dict
            A dict whose keys are widget UIDs and values are widget model dicts

        Raises
        -------
        LogicException
            If the operation is unsuccessful
        '''
        try:
            session_key = self._create_session_key(project_id, model_id)
            session = self._verify_session_exist(session_key)
            return mla.get_widget_models(session)
        except WidgetException as e:
            self._reraise(e)

    def get_widget_model(self, project_id, model_id, widget_uid):
        '''
        Returns a single widget model
        
        Parameters
        ----------
        project_id : string
            Unique string corresponding to a project
        model_id : string
            Unique string corresponding to the model being developed under this project
        widget_uid : int
            A unique integer which acts as a handler for referring to a specific widget
        
        Returns
        -------
        widget_models : dict
            A dict whose keys are widget UIDs and values are widget model dicts

        Raises
        -------
        LogicException
            If the operation is unsuccessful
        '''
        try:
            session_key = self._create_session_key(project_id, model_id)
            session = self._verify_session_exist(session_key)
            return mla.get_widget_model(widget_uid, session)
        except WidgetException as e:
            self._reraise(e)

    def _create_session(self, project_id, model_id, backend_type):
        '''
        Returns a session object
        '''
        try:
            context = dict(project_id=project_id, model_id=model_id, **self._context)
            backend = BackendInterface.create_backend(backend_type, context=context)
            return Session(project_id, model_id, self._async, self._persist, backend)
        except BackendInterfaceException as e:
            self._reraise(e)

    def _create_session_key(self, project_id, model_id):
        '''
        Returns a session key
        '''
        return (project_id, model_id,)

    def _verify_session_exist(self, session_key):
        '''
        Helper method which raises if the session doesn't exist
        '''
        if session_key not in self._sessions:
            raise LogicException("Session with project {:} and model {:} doesn't exist".format(*session_key))
        return self._sessions[session_key]
    
    def _verify_session_not_exist(self, session_key):
        '''
        Helper method which raises if the session exists
        '''
        if session_key in self._sessions:
            raise LogicException("Session with project {:} and model {:} already exists".format(*session_key))
    
    def _verify_connection(self, connection):
        '''
        Raises LogicException if the connection dict is malformed
        '''
        try:
            return connection['source']['widget_uid'], connection['source']['port_id'], connection['sink']['widget_uid'], connection['sink']['port_id']
        except KeyError as e:
            raise LogicException("Connection failure. Missing required connection parameter {:}".format(e))

    def _reraise(self, e):
        '''
        Reraises the exception as a LogicException with the original traceback intact
        '''
        raise LogicException(e).with_traceback(e.__traceback__)