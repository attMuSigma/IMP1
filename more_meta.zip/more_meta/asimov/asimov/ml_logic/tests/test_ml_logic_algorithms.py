# -*- coding: utf-8 -*-
"""
Provides tests for the ML Logic class
"""
import unittest
import os
import mock
from asimov.ml_logic.ml_logic import Session
from asimov.ml_logic.backend_interface import SklearnEmbeddedInterface, SklearnJupyterInterface
from asimov.ml_logic import ml_logic_algorithms as mla
from asimov.ml_logic.meta_error import State


ACTIVE_BACKEND = SklearnEmbeddedInterface
#ACTIVE_BACKEND = SklearnJupyterInterface


class WildCard(object):
    def __eq__(self, val):
        return True


def called_relatively(mock_obj, call_list):
    '''
    Returns true if the calls to mock_obj were made in the correct order relatively
    '''
    call_indexes = [mock_obj.call_args_list.index(call) for call in call_list]
    return True if call_indexes == sorted(call_indexes) else False


class BasicTest(unittest.TestCase):

    def setUp(self):
        test_dir = os.path.dirname(os.path.realpath(__file__))
        self.test_file = os.path.join(test_dir,'test_data.csv')
        self.iris_file = os.path.join(test_dir,'iris.csv')
        self.mock_async = mock.Mock()
        self.mock_persist = mock.Mock()
        self.wildcard = WildCard()
        
    def test_create_widget(self):
        '''
        Tests create and delete operations
        '''
        session = Session('foo', 'bar', self.mock_async, self.mock_persist, ACTIVE_BACKEND())
        mla.create_widget('data.csv', 0, session)
        self.assertTrue(0 in session.graph)
        mla.delete_widget(0, session)
        self.assertFalse(0 in session.graph)
        
    def test_basic_propagations(self):
        '''
        Tests loading a session from model dicts
        '''
        session = Session('foo', 'bar', self.mock_async, self.mock_persist, ACTIVE_BACKEND())
        mla.create_widget('data.csv', 0, session)
        mla.create_widget('data.drop_column', 1, session)
        mla.create_widget('decomposition.pca', 2, session)
        mla.apply_parameters(0, {'separator': ',', 'filepath': self.test_file}, session)
        mla.create_connection(0, 0, 1, 0, session)
        mla.create_connection(1, 0, 2, 0, session)
        mla.flush(0, session)
        mla.evaluate(0, session)
        # verify that the widgets are operating correctly
        drop_widget_model = mla.get_widget_model(1, session)
        self.assertEqual(drop_widget_model['parameters']['drop_cols']['options'][0]['options'], ['Feature1','Feature2','Feature3','Feature4'])

    def test_load_session(self):
        '''
        Tests loading a session from model dicts
        '''
        # create session and widgets
        session = Session('foo', 'bar', self.mock_async, self.mock_persist, ACTIVE_BACKEND())
        mla.create_widget('data.csv', 0, session)
        mla.create_widget('data.drop_column', 1, session)
        mla.create_widget('decomposition.pca', 2, session)
        mla.apply_parameters(0, {'separator': ',', 'filepath': self.test_file}, session)
        mla.create_connection(0, 0, 1, 0, session)
        mla.create_connection(1, 0, 2, 0, session)
        # do a full evaluation and extract the session widget models
        mla.flush(0, session)
        mla.evaluate(0, session)
        # create a new session and load from the previous widget models
        widget_models = mla.get_widget_models(session)
        session = Session('foo', 'bar', self.mock_async, self.mock_persist, ACTIVE_BACKEND())
        mla.load_session(widget_models, session)
        # sanity check that it loaded
        drop_widget_model = mla.get_widget_model(1, session)
        self.assertEqual(drop_widget_model['parameters']['drop_cols']['options'][0]['options'], ['Feature1','Feature2','Feature3','Feature4'])
        # sanity check that connections can be made after loading
        self.mock_async.notify_widget_state.reset_mock()
        mla.create_widget('data.dataframe_sampler', 3, session)
        mla.create_connection(2, 0, 3, 0, session)
        self.mock_async.notify_widget_state.assert_has_calls([mock.call('foo', 'bar', 3, State.EVALUATED.value, self.wildcard)])
        
    def test_load_session_floating(self):
        '''
        Tests the corner case where unconnected widgets are being loaded
        '''
        # create session and widgets
        session = Session('foo', 'bar', self.mock_async, self.mock_persist, ACTIVE_BACKEND())
        mla.create_widget('data.csv', 0, session)
        mla.apply_parameters(0, {'separator': ',', 'filepath': self.test_file}, session)
        # do a full evaluation and extract the session widget models
        mla.evaluate(0, session)
        # create a new session and load from the previous widget models
        widget_models = mla.get_widget_models(session)
        session = Session('foo', 'bar', self.mock_async, self.mock_persist, ACTIVE_BACKEND())
        mla.load_session(widget_models, session)
        mla.apply_parameters(0, {'separator': ',', 'filepath': self.test_file}, session)

    def test_delete_connection(self):
        '''
        Tests loading a session from model dicts
        '''
        # create session and widgets
        session = Session('foo', 'bar', self.mock_async, self.mock_persist, ACTIVE_BACKEND())
        mla.create_widget('data.csv', 0, session)
        mla.create_widget('data.drop_column', 1, session)
        mla.create_widget('decomposition.pca', 2, session)
        mla.apply_parameters(0, {'separator': ',', 'filepath': self.test_file}, session)
        mla.create_connection(0, 0, 1, 0, session)
        mla.create_connection(1, 0, 2, 0, session)
        # do a full evaluation
        mla.flush(0, session)
        mla.evaluate(0, session)
        # delete the connection (0,1) and verify only (1,2) remains
        self.mock_async.notify_widget_state.reset_mock()
        mla.delete_connection(0, 0, 1, 0, session)
        self.assertEqual(set(session.graph.edges()), set([(1,2)]))
        # widget 1 is now disconnected
        self.mock_async.notify_widget_state.assert_has_calls([mock.call('foo', 'bar', 1, State.NOT_CONNECTED.value, self.wildcard)])
        # widget 2 is connected but has no data available        
        self.mock_async.notify_widget_state.assert_has_calls([mock.call('foo', 'bar', 2, State.DATA_UNAVAILABLE.value, self.wildcard)])
    
    def test_v_structure(self):
        '''
        Tests the evaluation of widgets which forms a V structure
        '''
        # create session and widgets
        session = Session('foo', 'bar', self.mock_async, self.mock_persist, ACTIVE_BACKEND())
        mla.create_widget('data.csv', 0, session)
        mla.create_widget('data.select_target', 1, session)
        mla.create_widget('data.dataframe_split', 2, session)
        mla.create_widget('supervised.gradient_boosting_classifier', 3, session)
        mla.create_widget('evaluation.cross_validate', 4, session)
        mla.create_widget('viz.roc_curve', 5, session)
        # create connections
        mla.create_connection(0, 0, 1, 0, session)
        mla.create_connection(1, 0, 2, 0, session)
        mla.create_connection(2, 0, 4, 0, session)
        mla.create_connection(3, 0, 4, 1, session)
        mla.create_connection(4, 0, 5, 0, session)
        # set the filepath, which causes first few widgets to evaluate. the cross validate widiget will fail without a domain
        self.mock_async.notify_widget_state.reset_mock()
        mla.apply_parameters(0, {'separator': ',', 'filepath': self.iris_file}, session)
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 0, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 1, State.ERROR.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 2, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 4, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.DATA_UNAVAILABLE.value, self.wildcard)]))
        # set the domain of the dataset. allows all but last widget to evaluate                                                                        
        self.mock_async.notify_widget_state.reset_mock()
        mla.apply_parameters(1, {'domain': 'domain.classification', 'target': 'Species'}, session)
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 1, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 2, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 4, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.EVALUATED.value, self.wildcard)]))
        # make sure the plot is created
        encoded_plot = mla.get_widget_model(5, session)['attributes']['plot']['value']
        self.assertTrue(isinstance(encoded_plot, str) and encoded_plot)
    
    def test_long_chain(self):
        '''
        Tests a complex long chain of widgets
        '''
        # create session and widgets
        session = Session('foo', 'bar', self.mock_async, self.mock_persist, ACTIVE_BACKEND())
        mla.create_widget('data.csv', 0, session)
        mla.create_widget('data.select_target', 1, session)
        mla.create_widget('data.dataframe_split', 2, session)
        mla.create_widget('data.drop_column', 3, session)
        mla.create_widget('decomposition.pca', 4, session)
        mla.create_widget('evaluation.cross_validate', 5, session)
        mla.create_widget('supervised.gradient_boosting_classifier', 6, session)
        mla.create_widget('viz.roc_curve', 7, session)
        # create connections
        mla.create_connection(0, 0, 1, 0, session)  # csv -> select
        mla.create_connection(1, 0, 2, 0, session)  # select -> split
        mla.create_connection(2, 0, 3, 0, session)  # split A -> drop
        mla.create_connection(3, 0, 4, 0, session)  # drop -> pca
        mla.create_connection(4, 0, 5, 0, session)  # pca -> cv
        mla.create_connection(6, 0, 5, 1, session)  # gbc -> cv
        mla.create_connection(5, 0, 7, 0, session)  # cv -> roc
        # set the filepath, which causes first few widgets to evaluate. the cross validate widiget will fail without a domain
        self.mock_async.notify_widget_state.reset_mock()
        mla.apply_parameters(0, {'separator': ',', 'filepath': self.iris_file}, session)
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 0, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 1, State.ERROR.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 2, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 3, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 4, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 7, State.DATA_UNAVAILABLE.value, self.wildcard)]))
        # set the domain of the dataset. allows all downstream widgets to evaluate                                                                   
        self.mock_async.notify_widget_state.reset_mock()
        mla.apply_parameters(1, {'domain': 'domain.classification', 'target': 'Species'}, session)
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 1, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 2, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 3, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 4, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 7, State.EVALUATED.value, self.wildcard)]))
        # make sure the plot is created
        encoded_plot = mla.get_widget_model(7, session)['attributes']['plot']['value']
        self.assertTrue(isinstance(encoded_plot, str) and encoded_plot)


    def test_delete_reconnect(self):
        '''
        Tests an error mode where a middle widget is deleted and bypassed
        '''
        # create session and widgets
        session = Session('foo', 'bar', self.mock_async, self.mock_persist, ACTIVE_BACKEND())
        mla.create_widget('data.csv', 0, session)
        mla.create_widget('data.select_target', 1, session)
        mla.create_widget('data.dataframe_split', 2, session)
        mla.create_widget('data.drop_column', 3, session)
        mla.create_widget('decomposition.pca', 4, session)
        mla.create_widget('evaluation.cross_validate', 5, session)
        mla.create_widget('supervised.gradient_boosting_classifier', 6, session)
        mla.create_widget('viz.roc_curve', 7, session)
        # create connections
        mla.create_connection(0, 0, 1, 0, session)  # csv -> select
        mla.create_connection(1, 0, 2, 0, session)  # select -> split
        mla.create_connection(2, 0, 3, 0, session)  # split A -> drop
        mla.create_connection(3, 0, 4, 0, session)  # drop -> pca
        mla.create_connection(4, 0, 5, 0, session)  # pca -> cv
        mla.create_connection(6, 0, 5, 1, session)  # gbc -> cv
        mla.create_connection(5, 0, 7, 0, session)  # cv -> roc
        # set the filepath, which causes first few widgets to evaluate. the cross validate widiget will fail without a domain
        self.mock_async.notify_widget_state.reset_mock()
        mla.apply_parameters(0, {'separator': ',', 'filepath': self.iris_file}, session)
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 0, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 1, State.ERROR.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 2, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 3, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 4, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 7, State.DATA_UNAVAILABLE.value, self.wildcard)]))
        # set the domain of the dataset. allows all downstream widgets to evaluate                                                                   
        self.mock_async.notify_widget_state.reset_mock()
        mla.apply_parameters(1, {'domain': 'domain.classification', 'target': 'Species'}, session)
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 1, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 2, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 3, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 4, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 7, State.EVALUATED.value, self.wildcard)]))
        # delete the drop column widget
        self.mock_async.notify_widget_state.reset_mock()
        mla.delete_widget(3, session)
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 4, State.NOT_CONNECTED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 7, State.DATA_UNAVAILABLE.value, self.wildcard)]))
        # bypass to PCA directly
        self.mock_async.notify_widget_state.reset_mock()
        mla.create_connection(2, 0, 4, 0, session)  # split A -> pca
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 4, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 7, State.EVALUATED.value, self.wildcard)]))
        

    def test_propagation_fail(self):
        '''
        Tests an error mode where deleting and reconnecting a wire fails to propagate
        '''
        # create session and widgets
        session = Session('foo', 'bar', self.mock_async, self.mock_persist, ACTIVE_BACKEND())
        mla.create_widget('data.csv', 0, session)
        mla.create_widget('data.select_target', 1, session)
        mla.create_widget('data.dataframe_split', 2, session)
        mla.create_widget('supervised.gradient_boosting_classifier', 3, session)
        mla.create_widget('evaluation.cross_validate', 4, session)
        mla.create_widget('viz.roc_curve', 5, session)
        mla.create_widget('evaluation.pipeline_predict', 6, session)
        mla.create_widget('viz.confusion_matrix', 7, session)
        # create connections
        mla.create_connection(0, 0, 1, 0, session)  # csv -> select
        mla.create_connection(1, 0, 2, 0, session)  # select -> drop
        mla.create_connection(2, 0, 4, 0, session)  # split A -> cv
        mla.create_connection(3, 0, 4, 1, session)  # gbc -> cv
        mla.create_connection(4, 0, 5, 0, session)  # cv -> roc
        # set the filepath, which causes first few widgets to evaluate. the cross validate widiget will fail without a domain
        self.mock_async.notify_widget_state.reset_mock()
        mla.apply_parameters(0, {'separator': ',', 'filepath': self.iris_file}, session)
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 0, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 1, State.ERROR.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 2, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 4, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.DATA_UNAVAILABLE.value, self.wildcard),]))
        # set the domain and target
        self.mock_async.notify_widget_state.reset_mock()
        mla.apply_parameters(1, {'domain': 'domain.classification', 'target': 'Species'}, session)
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 1, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 2, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 4, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.EVALUATED.value, self.wildcard),]))
        # delete csv -> select
        self.mock_async.notify_widget_state.reset_mock()
        mla.delete_connection(0, 0, 1, 0, session)
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 1, State.NOT_CONNECTED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 2, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 4, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.DATA_UNAVAILABLE.value, self.wildcard),]))
        # reconnect csv -> select
        self.mock_async.notify_widget_state.reset_mock()
        mla.create_connection(0, 0, 1, 0, session)
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 1, State.ERROR.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 2, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 4, State.DATA_UNAVAILABLE.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.DATA_UNAVAILABLE.value, self.wildcard),]))
        # set the domain and target
        self.mock_async.notify_widget_state.reset_mock()
        mla.apply_parameters(1, {'domain': 'domain.classification', 'target': 'Species'}, session)
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 1, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 2, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 4, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.EVALUATED.value, self.wildcard),]))
        # make sure the plot is created
        encoded_plot = mla.get_widget_model(5, session)['attributes']['plot']['value']
        self.assertTrue(isinstance(encoded_plot, str) and encoded_plot)
        
        # round two for more testing
        mla.create_connection(2, 1, 6, 0, session)  # split B -> predict
        mla.create_connection(4, 1, 6, 1, session)  # cv pipeline -> predict
        mla.create_connection(6, 0, 7, 0, session)  # predict -> confusion matrix
        self.mock_async.notify_widget_state.reset_mock()
        mla.apply_parameters(2, {'split': 0.30}, session)
        self.assertTrue(called_relatively(self.mock_async.notify_widget_state, [mock.call('foo', 'bar', 2, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 4, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 6, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 5, State.EVALUATED.value, self.wildcard),
                                                                                mock.call('foo', 'bar', 7, State.EVALUATED.value, self.wildcard),]))
        encoded_plot = mla.get_widget_model(7, session)['attributes']['plot']['value']
        self.assertTrue(isinstance(encoded_plot, str) and encoded_plot)

if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)
