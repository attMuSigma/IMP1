# -*- coding: utf-8 -*-
"""
Provides tests for the ML Logic class
"""
import unittest
import mock
import os
from tornado.testing import AsyncTestCase, gen_test
from asimov.ml_logic.ml_logic import MlLogic, LogicException


class BasicTest(unittest.TestCase):

    def setUp(self):
        '''
        Creates mock objects
        '''
        self.async = mock.Mock()
        self.persist = mock.Mock()
        test_dir = os.path.dirname(os.path.realpath(__file__))
        self.test_file = os.path.join(test_dir,'test_data.csv')
        
    def test_temp_patch(self):
        '''
        Verifies the patch for returning models works
        '''
        logic = MlLogic(self.async, self.persist)
        logic.begin_session('foo', 'bar', 'sklearn_embedded')
        logic.create_widget('foo', 'bar', 'data.csv', 0)
        logic.apply_parameters('foo', 'bar', 0, {'filepath': "{:}".format(self.test_file), 'separator': ','})
        drop_widget_model = logic.create_widget('foo', 'bar', 'data.drop_column', 1)
        self.assertEqual(drop_widget_model['parameters']['drop_cols']['options'][0]['options'], [])
        drop_widget_model = logic.create_connection('foo', 'bar', {'source': {'widget_uid': 0, 'port_id': 0}, 'sink': {'widget_uid': 1, 'port_id': 0}})
        self.assertEqual(drop_widget_model['parameters']['drop_cols']['options'][0]['options'], ['Feature1','Feature2','Feature3','Feature4'])        
        drop_widget_model = logic.apply_parameters('foo', 'bar', 1, {})
        self.assertEqual(drop_widget_model['parameters']['drop_cols']['options'][0]['options'], ['Feature1','Feature2','Feature3','Feature4'])
    
    def test_get_models(self):
        '''
        Exercises the ML logic by creating a chain of widgets and probing the async bus
        '''
        logic = MlLogic(self.async, self.persist)
        logic.begin_session('foo', 'bar', 'sklearn_embedded')
        logic.create_widget('foo', 'bar', 'data.csv', 0)
        logic.apply_parameters('foo', 'bar', 0, {'filepath': "{:}".format(self.test_file), 'separator': ','})
        logic.create_widget('foo', 'bar', 'data.drop_column', 1)
        logic.create_connection('foo', 'bar', {'source': {'widget_uid': 0, 'port_id': 0}, 'sink': {'widget_uid': 1, 'port_id': 0}})
        logic.create_widget('foo', 'bar', 'data.dataframe_sampler', 2)
        logic.create_connection('foo', 'bar', {'source': {'widget_uid': 1, 'port_id': 0}, 'sink': {'widget_uid': 2, 'port_id': 0}})
        drop_widget_model = logic.get_widget_model('foo', 'bar', 1)
        self.assertEqual(drop_widget_model['parameters']['drop_cols']['options'][0]['options'], ['Feature1','Feature2','Feature3','Feature4'])

    def test_basic_chain(self):
        '''
        Exercises the ML logic by creating a chain of widgets and probing the async bus
        '''
        logic = MlLogic(self.async, self.persist)
        logic.begin_session('foo', 'bar', 'sklearn_embedded')
        logic.create_widget('foo', 'bar', 'data.csv', 0)
        logic.apply_parameters('foo', 'bar', 0, {'filepath': "{:}".format(self.test_file), 'separator': ','})
        logic.create_widget('foo', 'bar', 'data.drop_column', 1)
        logic.create_connection('foo', 'bar', {'source': {'widget_uid': 0, 'port_id': 0}, 'sink': {'widget_uid': 1, 'port_id': 0}})
        logic.create_widget('foo', 'bar', 'data.dataframe_sampler', 2)
        logic.create_connection('foo', 'bar', {'source': {'widget_uid': 1, 'port_id': 0}, 'sink': {'widget_uid': 2, 'port_id': 0}})

    def test_multi_session(self):
        '''
        Demonstrates that the same UID can be used for different models
        '''
        logic = MlLogic(self.async, self.persist)
        logic.begin_session('foo', 'bar', 'sklearn_embedded')
        logic.create_widget('foo', 'bar', 'data.csv', 0)
        logic.begin_session('baz', 'qux', 'sklearn_embedded')
        logic.create_widget('baz', 'qux', 'data.csv', 0)
    
    def test_session_creation(self):
        '''
        Demonstrates that a session has to be explicitely created/deleted
        '''
        logic = MlLogic(self.async, self.persist)
        with self.assertRaises(LogicException):
            logic.create_widget('foo', 'bar', 'data.csv', 0)
        logic.begin_session('foo', 'bar', 'sklearn_embedded')
        logic.create_widget('foo', 'bar', 'data.csv', 0)
        logic.end_session('foo', 'bar')
        with self.assertRaises(LogicException):
            logic.end_session('foo', 'bar')
    
    def test_session_reuse(self):
        '''
        Demonstrates that there is no connection between an old and current session
        '''
        logic = MlLogic(self.async, self.persist)
        with self.assertRaises(LogicException):
            logic.create_widget('foo', 'bar', 'data.csv', 0)
        logic.begin_session('foo', 'bar', 'sklearn_embedded')
        logic.create_widget('foo', 'bar', 'data.csv', 0)
        logic.end_session('foo', 'bar')
        with self.assertRaises(LogicException):
            logic.end_session('foo', 'bar')
        logic.begin_session('foo', 'bar', 'sklearn_embedded')
        logic.create_widget('foo', 'bar', 'data.csv', 0)
    

class BasicAsyncTest(AsyncTestCase):
    
    def setUp(self):
        '''
        Creates mock objects
        '''
        super().setUp()
        self.async = mock.Mock()
        self.persist = mock.Mock()
        test_dir = os.path.dirname(os.path.realpath(__file__))
        self.test_file = os.path.join(test_dir,'test_data.csv')

    @gen_test
    def test_basic_use(self):
        '''
        Demonstrates that the async interface to ML Logic can be used in an IO Loop
        '''
        logic = MlLogic(self.async, self.persist)
        result = yield logic.async_method('begin_session', project_id='foo', model_id='bar', backend='sklearn_embedded')
        self.assertIs(result, None)
        result = yield logic.async_method('create_widget', project_id='foo', model_id='bar', widget_id='data.csv', widget_uid=0)
        self.assertEqual(result['widget_id'], 'data.csv')
        self.assertEqual(result['widget_uid'], 0)

    

if __name__ == '__main__':
    '''
    Test area
    '''
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    #suite.addTest(loader.loadTestsFromTestCase(BasicTest))
    suite.addTest(loader.loadTestsFromTestCase(BasicAsyncTest))
    unittest.TextTestRunner(verbosity=2).run(suite)