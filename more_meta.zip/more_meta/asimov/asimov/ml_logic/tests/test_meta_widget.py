# -*- coding: utf-8 -*-
"""
Provides tests for the meta widget class
"""
import unittest
import os
from asimov.ml_logic.meta_widget import MetaWidget
from asimov.ml_logic.meta_error import WidgetException, DataUnavailable, InvalidConnection, NotConnected
from asimov.ml_logic.backend_interface import SklearnEmbeddedInterface


class BasicTest(unittest.TestCase):

    def setUp(self):
        '''
        Creates mock objects
        '''
        self.skbackend = SklearnEmbeddedInterface()
        test_dir = os.path.dirname(os.path.realpath(__file__))
        self.test_file = os.path.join(test_dir,'test_data.csv')
        self.iris_file = os.path.join(test_dir,'iris.csv')
 
    def test_basic_operations(self):
        '''
        Tests create widget API
        '''
        # nonexistant widgets will raise
        with self.assertRaises(WidgetException):
            MetaWidget.create_widget('foo', 0, self.skbackend)
        # create csv widget. creating widget with same UID will raise
        csv_widget = MetaWidget.create_widget('data.csv', 0, self.skbackend)
        with self.assertRaises(WidgetException):
            MetaWidget.create_widget('data.csv', 0, self.skbackend)
        # widget which is deleted will no longer exist and thus cannot evaluate
        csv_widget.delete()
        with self.assertRaises(WidgetException):
            csv_widget.evaluate()
        # recreate widget. verify basic attributes
        csv_widget = MetaWidget.create_widget('data.csv', 0, self.skbackend)
        self.assertEqual(csv_widget.widget_id, 'data.csv')
        self.assertEqual(csv_widget.widget_uid, 0)
        self.assertFalse(csv_widget.sources)
        # widget cannot evaluate without required parameters
        with self.assertRaises(WidgetException):
            csv_widget.evaluate()
        # with parameters added, evaluation is successful
        csv_widget.apply_parameters({'separator': ',', 'filepath': self.test_file})
        csv_widget.evaluate()

    def test_basic_chain(self):
        '''
        Connects multiple widgets together
        '''
        # create and evaluate
        csv_widget = MetaWidget.create_widget('data.csv', 0, self.skbackend)
        csv_widget.apply_parameters({'separator': ',', 'filepath': self.test_file})
        csv_widget.evaluate()
        # create and try to evaluate without a connection
        drop_widget = MetaWidget.create_widget('data.drop_column', 1, self.skbackend)
        with self.assertRaises(NotConnected):
            drop_widget.evaluate()
        # single sink raises exception
        drop_widget.add_source(source_widget_uid=0, source_port=0, sink_port_id=0)        
        with self.assertRaises(InvalidConnection):
            drop_widget.add_source(source_widget_uid=0, source_port=0, sink_port_id=0)
        # create and evaluate however no data is available
        pca_widget = MetaWidget.create_widget('decomposition.pca', 2, self.skbackend)
        pca_widget.add_source(source_widget_uid=1, source_port=0, sink_port_id=0)
        with self.assertRaises(DataUnavailable):
            pca_widget.evaluate()
        # evaluate in order
        drop_widget.evaluate()
        pca_widget.evaluate()
    
    def test_load_widget(self):
        '''
        Loads a widget on the backend from previously saved model
        '''
        # create a csv widget correctly
        csv_widget = MetaWidget.create_widget('data.csv', 0, self.skbackend)
        csv_widget.apply_parameters({'separator': ',', 'filepath': self.test_file})
        csv_widget.evaluate()
        # extract the model and rebuild from the model alone
        csv_model = csv_widget.model
        csv_widget.delete()
        csv_widget = MetaWidget.load_widget(csv_model, self.skbackend)
        csv_widget.evaluate()
    
    def test_multiple_input_sources(self):
        '''
        Tests widgets which create a Y structure
        '''
        csv_widget = MetaWidget.create_widget('data.csv', 0, self.skbackend)
        csv_widget.apply_parameters({'separator': ',', 'filepath': self.iris_file})
        csv_widget.evaluate()

        select_target_widget = MetaWidget.create_widget('data.select_target', 1, self.skbackend)
        select_target_widget.add_source(source_widget_uid=0, source_port=0, sink_port_id=0)
        select_target_widget.apply_parameters({'target': 'Species', 'domain': 'domain.classification'})
        select_target_widget.evaluate()
        
        gbc_widget = MetaWidget.create_widget('supervised.gradient_boosting_classifier', 2, self.skbackend)
        gbc_widget.evaluate()
        
        cv_widget = MetaWidget.create_widget('evaluation.cross_validate', 3, self.skbackend)
        cv_widget.add_source(source_widget_uid=1, source_port=0, sink_port_id=0)
        cv_widget.add_source(source_widget_uid=2, source_port=0, sink_port_id=1)
        cv_widget.evaluate()
        
        roc_widget = MetaWidget.create_widget('viz.roc_curve', 4, self.skbackend)
        roc_widget.add_source(source_widget_uid=3, source_port=0, sink_port_id=0)
        roc_widget.evaluate()
        
    def test_multiple_output_sources(self):
        '''
        Tests widgets which create a V structure
        '''
        csv_widget = MetaWidget.create_widget('data.csv', 0, self.skbackend)
        csv_widget.apply_parameters({'separator': ',', 'filepath': self.iris_file})
        csv_widget.evaluate()
        
        split_widget = MetaWidget.create_widget('data.dataframe_split', 1, self.skbackend)
        split_widget.add_source(source_widget_uid=0, source_port=0, sink_port_id=0)
        split_widget.evaluate()
        
        split_a_sampler = MetaWidget.create_widget('data.dataframe_sampler', 2, self.skbackend)
        with self.assertRaises(NotConnected):
            split_a_sampler.evaluate()
        self.assertEqual(split_a_sampler.model['attributes']['samples']['value'], None)
        split_a_sampler.add_source(source_widget_uid=1, source_port=0, sink_port_id=0)
        split_a_sampler.evaluate()
        self.assertNotEqual(split_a_sampler.model['attributes']['samples']['value'], None)

        split_b_sampler = MetaWidget.create_widget('data.dataframe_sampler', 3, self.skbackend)
        with self.assertRaises(NotConnected):
            split_b_sampler.evaluate()
        self.assertEqual(split_b_sampler.model['attributes']['samples']['value'], None)
        split_b_sampler.add_source(source_widget_uid=1, source_port=1, sink_port_id=0)
        split_b_sampler.evaluate()
        self.assertNotEqual(split_b_sampler.model['attributes']['samples']['value'], None)


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)