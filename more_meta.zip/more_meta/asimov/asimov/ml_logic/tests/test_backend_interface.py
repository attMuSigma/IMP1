# -*- coding: utf-8 -*-
"""
Provides tests for the backend interface class
"""
import unittest
import os
from asimov.ml_logic.backend_interface import SklearnEmbeddedInterface, SklearnJupyterInterface


class BasicTest(unittest.TestCase):

    def setUp(self):
        '''
        Creates mock objects
        '''
        test_dir = os.path.dirname(os.path.realpath(__file__))
        self.test_file = os.path.join(test_dir,'test_data.csv')

    def test_embedded_basic_chain(self):
        '''
        Connects multiple widgets together
        '''
        backend = SklearnEmbeddedInterface()
        # create CSV reader widget
        self.assertTrue(backend.create_widget('data.csv', 0)['success'])
        self.assertTrue(backend.apply_parameters(0, {'separator': ',', 'filepath': self.test_file})['success'])
        self.assertTrue(backend.evaluate(0)['success'])
        # connect and evaluate drop column widget
        self.assertTrue(backend.create_widget('data.drop_column', 1,)['success'])
        self.assertFalse(backend.evaluate(1)['success'])
        self.assertTrue(backend.create_connection(0, 0, 1, 0)['success'])
        self.assertTrue(backend.evaluate(1)['success'])

    def test_jupyter_basic_chain(self):
        '''
        Connects multiple widgets together
        '''
        backend = SklearnJupyterInterface()
        # create CSV reader widget
        self.assertTrue(backend.create_widget('data.csv', 0)['success'])
        self.assertTrue(backend.apply_parameters(0, {'separator': ',', 'filepath': self.test_file})['success'])
        self.assertTrue(backend.evaluate(0)['success'])
        # connect and evaluate drop column widget
        self.assertTrue(backend.create_widget('data.drop_column', 1,)['success'])
        self.assertFalse(backend.evaluate(1)['success'])
        self.assertTrue(backend.create_connection(0, 0, 1, 0)['success'])
        self.assertTrue(backend.evaluate(1)['success'])


if __name__ == '__main__':
    '''
    Test area
    '''
    suite = unittest.TestLoader().loadTestsFromTestCase(BasicTest)
    unittest.TextTestRunner(verbosity=2).run(suite)