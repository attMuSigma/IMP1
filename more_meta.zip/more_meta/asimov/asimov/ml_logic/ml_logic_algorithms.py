# -*- coding: utf-8 -*-
"""
Provides a set of algorithms for ML Logic
"""
from networkx.algorithms.traversal import bfs_successors
from networkx.algorithms import topological_sort
from asimov.ml_logic.meta_widget import MetaWidget
from asimov.ml_logic.meta_error import State, WidgetException, state_lookup


def create_widget(widget_id, widget_uid, session):
    '''
    Creates a new widget for the provided session and persist it to the database
    '''
    widget = MetaWidget.create_widget(widget_id, widget_uid, session.backend)
    session.graph.add_node(widget_uid, widget=widget)
    evaluate_widget(widget_uid, session)
    session.persist.create_widget(session.project_id, session.model_id, widget_uid, widget.model)


def delete_widget(widget_uid, session):
    '''
    Deletes a new widget from the provided session and removes it from the database
    '''
    disconnect_children(widget_uid, session)  # deletes connections in backend
    for child in session.graph.successors(widget_uid):
        evaluate(child, session)  # evaluate descendants without connection
    session.graph.node[widget_uid]['widget'].delete()  # deletes widget in backend
    session.graph.remove_node(widget_uid)  # deletes widget and edges in DAG
    session.persist.delete_widget(session.project_id, session.model_id, widget_uid)


def disconnect_children(widget_uid, session):
    '''
    Deletes the connections between the specified widget and its children
    '''
    for child in session.graph.successors(widget_uid):
        child_widget = session.graph.node[child]['widget']
        for connection in child_widget.sources:
            if connection.source_wuid == widget_uid:
                child_widget.remove_source(connection.source_wuid, connection.source_pid, connection.sink_pid)


def evaluate(widget_uid, session):
    '''
    Evaluates all descendants of the specified widget 
    '''
    flush(widget_uid, session)  # clear previous state and outputs
    evaluate_widget(widget_uid, session)
    for node_idx, children in bfs_successors(session.graph, widget_uid).items():
        for child in children:
            evaluate_widget(child, session)


def flush(widget_uid, session):
    '''
    Flushes all descendants of the specified widget 
    '''
    session.graph.node[widget_uid]['widget'].flush()
    for node_idx, children in bfs_successors(session.graph, widget_uid).items():
        for child in children:
            session.graph.node[child]['widget'].flush()


def evaluate_widget(widget_uid, session):
    '''
    Evaluates a single widget and sends the appropriate notifications and model updates
    '''
    try:
        notify_widget_state(widget_uid, session, State.WORKING)
        session.graph.node[widget_uid]['widget'].evaluate()
        notify_widget_state(widget_uid, session, State.EVALUATED)
    except WidgetException as e:
        notify_widget_state(widget_uid, session, state_lookup[type(e)], str(e))
    finally:
        notify_widget_model(widget_uid, session)


def notify_widget_state(widget_uid, session, state, message='Ready'):
    '''
    Notifies the session of a widget state change using async bus
    '''
    session.async.notify_widget_state(session.project_id, session.model_id, widget_uid, state.value, message)


def notify_widget_model(widget_uid, session):
    '''
    Notifies the session with new widget model data, and persists the model to the database
    '''
    widget_model = session.graph.node[widget_uid]['widget'].model
    session.async.notify_widget_model(session.project_id, session.model_id, widget_uid, widget_model)
    session.persist.update_widget(session.project_id, session.model_id, widget_uid, widget_model)


def load_session(widget_models, session):
    '''
    Recreates a session from a previously saved session model
    '''
    # ensure widget UID keys are indeed integers and add all nodes to DAG
    widget_models = {int(key): val for key, val in widget_models.items()}
    session.graph.add_nodes_from(widget_models.keys())
    # then add in the edges by iterating over widget connections
    for widget_model in widget_models.values():
        dummy = MetaWidget(widget_model, session.backend)
        for connection in dummy.sources:
            session.graph.add_edge(connection.source_wuid, connection.sink_wuid)
    # send a default status for all widgets
    for widget_uid in topological_sort(session.graph):
        notify_widget_state(widget_uid, session, State.NOT_CONNECTED)
    # sort and load each widget in the correct order (ensures dependencies exist)
    for widget_uid in topological_sort(session.graph):
        session.graph.node[widget_uid]['widget'] = MetaWidget.load_widget(widget_models[widget_uid], session.backend)
        evaluate_widget(widget_uid, session)


def create_connection(source_wuid, source_pid, sink_wuid, sink_pid, session):
    '''
    Creates a connection and updates the DAG
    '''
    session.graph.node[sink_wuid]['widget'].add_source(source_wuid, source_pid, sink_pid)
    session.graph.add_edge(source_wuid, sink_wuid)
    evaluate(sink_wuid, session)


def delete_connection(source_wuid, source_pid, sink_wuid, sink_pid, session):
    '''
    Deletes a connection and updates the DAG
    '''
    session.graph.node[sink_wuid]['widget'].remove_source(source_wuid, source_pid, sink_pid)
    session.graph.remove_edge(source_wuid, sink_wuid)
    evaluate(sink_wuid, session)


def apply_parameters(widget_uid, parameters, session):
    '''
    Sets the parameters of a specified widget
    '''
    session.graph.node[widget_uid]['widget'].apply_parameters(parameters)
    evaluate(widget_uid, session)


def get_widget_models(session):
    '''
    Returns a dictionary representation of all widgets in the session
    '''
    return {widget_uid: session.graph.node[widget_uid]['widget'].model for widget_uid in session.graph}


def get_widget_model(widget_uid, session):
    '''
    Returns a dictionary representation of the specified widget
    '''
    return session.graph.node[widget_uid]['widget'].model
    