# -*- coding: utf-8 -*-
"""
Provides the Meta Widget class

Meta widgets are abstract representations of widgets on a specific backend.
The widget's identity and behavior depend entirely on their internal widget
state dict and backend interface
"""
from asimov.ml_logic.meta_error import WidgetException, exception_lookup, ConnectionException
from asimov.ml_logic.backend_interface import BackendInterfaceException


class Connection(object):
    def __init__(self, source_wuid, source_pid, sink_wuid, sink_pid):
        self._source_wuid = source_wuid
        self._source_pid = source_pid
        self._sink_wuid = sink_wuid
        self._sink_pid = sink_pid
    
    @property
    def source_wuid(self):
        return self._source_wuid
    
    @property
    def source_pid(self):
        return self._source_pid
    
    @property
    def sink_wuid(self):
        return self._sink_wuid
    
    @property
    def sink_pid(self):
        return self._sink_pid


class MetaWidget(object):

    def __init__(self, model, backend):
        self._meta = dict()
        self._model = model
        self._backend = backend

    @staticmethod
    def create_widget(widget_id, widget_uid, backend):
        '''
        Returns a newly created meta widget
        '''
        output = backend.create_widget(widget_id, widget_uid)
        MetaWidget._verify_success(output)
        output = backend.get_model(widget_uid)
        MetaWidget._verify_success(output)
        widget_model = output['result']
        return MetaWidget(widget_model, backend)
    
    @staticmethod
    def load_widget(widget_model, backend):
        '''
        Returns a newly recreated widget in an unevaluated state
        '''
        dummy = MetaWidget(widget_model, backend)
        meta_widget = MetaWidget.create_widget(dummy.widget_id, dummy.widget_uid, backend)
        for connection in dummy.sources:
            meta_widget.add_source(connection.source_wuid, connection.source_pid, connection.sink_pid)
        meta_widget.apply_parameters(dummy.parameters)
        return meta_widget

    @property
    def widget_id(self):
        return self._model['widget_id']
    
    @property
    def widget_uid(self):
        return self._model['widget_uid']
    
    @property
    def model(self):
        return self._model.copy()
    
    @property
    def sources(self):
        '''
        Returns a sequence of source connections
        '''
        sources = set()
        for port_id, port in self._model['sink_ports'].items():
            if port['type'] == 'single':
                if port['source'] is not None:
                    sources.add(Connection(port['source']['widget_uid'], port['source']['port_id'], self.widget_uid, int(port_id)))
            elif port['type'] == 'multiple':
                sources.update(Connection(source['widget_uid'], source['port_id'], self.widget_uid, int(port_id)) for source in port['source'])
            else:
                raise ConnectionException("Invalid sink type {:} for port ID {:} specified".format(port['type'], int(port_id)))
        return sources
    
    @property
    def parameters(self):
        '''
        Returns a dictionary of parameters
        '''
        return {name: param['value'] for name, param in self._model['parameters'].items()}
    
    def delete(self):
        '''
        Deletes this widget on the backend
        '''
        try:
            output = self._backend.delete_widget(self.widget_uid)
            MetaWidget._verify_success(output)
        except BackendInterfaceException as e:
            MetaWidget._reraise_backend(e)
    
    def evaluate(self):
        '''
        Evaluates the widget and updates the state
        '''
        try:
            output = self._backend.evaluate(self.widget_uid)
            MetaWidget._verify_success(output)
        except BackendInterfaceException as e:
            MetaWidget._reraise_backend(e)
        finally:
            self._update_model()

    def flush(self):
        '''
        Clears this widget's outputs
        '''
        try:
            output = self._backend.flush_widget(self.widget_uid)
            MetaWidget._verify_success(output)
        except BackendInterfaceException as e:
            MetaWidget._reraise_backend(e)
        finally:
            self._update_model()

    def add_source(self, source_widget_uid, source_port, sink_port_id):
        '''
        Connects a source and sink widget, and updates the sink widget's model
        
        Parameters
        ----------
        source_widget_uid : int
            Unique ID which specifies the source widget
        source_port: int
            Port of the source widget to connect to this widget
        sink_port: int
            Port of this widget's sink which is being connected to the source port
        
        Raises
        -------
        WidgetException
            If the operation is unsuccessful
        '''
        try:
            output = self._backend.create_connection(source_widget_uid, source_port, self.widget_uid, sink_port_id)
            MetaWidget._verify_success(output)
        except BackendInterfaceException as e:
            MetaWidget._reraise_backend(e)
        finally:
            self._update_model()

    def remove_source(self, source_widget_uid, source_port, sink_port_id):
        '''
        Disconnects a source and sink widget, and updates the sink widget's model
        
        Parameters
        ----------
        source_widget_uid : int
            Unique ID which specifies the source widget
        source_port: int
            Port of the source widget to connect to this widget
        sink_port: int
            Port of this widget's sink which is being connected to the source port
        
        Raises
        -------
        WidgetException
            If the operation is unsuccessful
        '''
        try:
            output = self._backend.delete_connection(source_widget_uid, source_port, self.widget_uid, sink_port_id)
            MetaWidget._verify_success(output)
        except BackendInterfaceException as e:
            MetaWidget._reraise_backend(e)
        finally:
            self._update_model()
    
    def apply_parameters(self, parameters):
        '''
        Applies new parameters to the specified widget and updates its model
        
        Parameters
        ----------
        parameters : dict
            A dict with structured defined in http://wiki.web.att.com/display/AVP/Sprint+1+JSON+Schema+-+Widget+Parameter
        
        Raises
        -------
        WidgetException
            If the operation is unsuccessful
        '''
        try:
            output = self._backend.apply_parameters(self.widget_uid, parameters)
            MetaWidget._verify_success(output)
        except BackendInterfaceException as e:
            MetaWidget._reraise_backend(e)
        finally:
            self._update_model()

    def _update_model(self):
        '''
        Updates internal state dict to reflect backend widget state
        '''
        try:
            output = self._backend.get_model(self.widget_uid)
            MetaWidget._verify_success(output)
            self._model = output['result']
        except BackendInterfaceException as e:
            MetaWidget._reraise_backend(e)

    @staticmethod
    def _verify_success(output):
        '''
        Raises if the output from an operation is not successful
        '''
        try:
            success = output['success']
        except KeyError as e:
            raise WidgetException("Backend response missing field {:}".format(e))
        if not success:
            try:
                error_type = output['error']
                error_message = output['message']
            except KeyError as e:
                raise WidgetException("Backend response missing field {:}".format(e))
            try:
                raise exception_lookup[error_type](error_message)
            except KeyError:
                raise WidgetException("An undefined error occurred: {:} : {:}".format(error_type, error_message))

    @staticmethod
    def _reraise_backend(e):
        '''
        Reraises the exception as a WidgetException with the original traceback intact
        '''
        raise WidgetException("Widget failed due to kernel error: {:}".format(e)).with_traceback(e.__traceback__)
