# -*- coding: utf-8 -*-
"""
Provides widget errors
"""
from enum import Enum


class WidgetException(Exception):
    pass


class EvaluationError(WidgetException):
    pass


class ConnectionException(WidgetException):
    pass


class NotConnected(ConnectionException):
    pass


class InvalidConnection(ConnectionException):
    pass


class DataUnavailable(ConnectionException):
    pass


class Error(Enum):
    GENERAL = 'widget.general'
    WIDGET_EVALUATION = 'widget.evaluation'
    INVALID_CONNECTION = 'widget.connection.invalid_connection'
    NOT_CONNECTED = 'widget.connection.not_connected'
    DATA_UNAVAILABLE = 'widget.connection.data_unavailable'
    def __str__(self):
        return self.value
    def __repr__(self):
        return self.value


class State(Enum):
    EVALUATED = 'state.evaluated'
    WORKING = 'state.working'
    ERROR = 'state.error'
    INVALID_CONNECTION = 'state.invalid_connection'
    NOT_CONNECTED = 'state.not_connected'
    DATA_UNAVAILABLE = 'state.data_unavailable'


exception_lookup = {Error.GENERAL.value: WidgetException, Error.WIDGET_EVALUATION.value: EvaluationError,
                    Error.INVALID_CONNECTION.value: InvalidConnection, Error.NOT_CONNECTED.value: NotConnected,
                    Error.DATA_UNAVAILABLE.value: DataUnavailable}

error_lookup = {val: key for key, val in exception_lookup.items()}

state_lookup = {WidgetException: State.ERROR, EvaluationError: State.ERROR, InvalidConnection: State.INVALID_CONNECTION,
                NotConnected: State.NOT_CONNECTED, DataUnavailable: State.DATA_UNAVAILABLE}
