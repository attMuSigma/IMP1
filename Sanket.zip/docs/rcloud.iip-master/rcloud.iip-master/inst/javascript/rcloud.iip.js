((function() {
    // tell requireJS where to find iip modules
    var requirejs_config_obj = {
        paths: {
            "iip": "../../shared.R/rcloud.iip/js/iip",
            "oneSlide": "../../shared.R/rcloud.iip/js/oneSlide"
        }
    };

    requirejs.config(requirejs_config_obj);


    // this css should be fine to load late
    // http://requirejs.org/docs/faq-advanced.html#css
    function loadCss(url) {
        var link = document.createElement("link");
        link.type = "text/css";
        link.rel = "stylesheet";
        link.href = url;
        document.getElementsByTagName("head")[0].appendChild(link);
    }

return {
    init: function(ocaps, k) {
        ["iipslidechooser.css", "slideChooser.css", "editslide.css"]
            .forEach(function(file) {
                var url = window.location.protocol + '//' + window.location.host +
                        '/shared.R/rcloud.iip/css/' + file;
                if (!window.location.href.match("/viewiip.html")) {
                loadCss(url);
                }
            });

        require(["iip"], function(iip) {
            RCloud.UI.cell_commands.add({
                iipWizard: {
                    area: 'cell',
                    sort: 1100, // right after language chooser
                    create: function(cell_model,cell_view) {
                        // choosing a random icon from http://fontawesome.io/3.2.1/icons/
                        // if none of them work, we can add an option to use bitmap
                        // or other custom button control
                        return RCloud.UI.cell_commands.create_button("icon-bolt", "iip wizard", function() {
                            iip.launchIIPWizard(cell_model);
                        });
                    }
                }
            });
            RCloud.UI.share_button.add({
                'viewiip.html': {
                    sort: 1000,
                    page: 'shared.R/rcloud.iip/viewiip.html'
                }
            });
            // modify device_pixel_ratio cell postprocessor
            var dpr_post = Notebook.Cell.postprocessors.get('device_pixel_ratio');
            if(dpr_post && !dpr_post.disable)
                Notebook.Cell.postprocessors.disable('device_pixel_ratio');
            else
                dpr_post = null;
            Notebook.Cell.postprocessors.add({
                iip_images: {
                    sort: 1000,
                    process: function(div) {
                        var iip_cell = div.find('.iipcell');
                        if(iip_cell.size())
                            iip_cell.find('img').addClass("img-responsive slideimg");
                        else if(dpr_post)
                            dpr_post.process(div); // not an iip cell
                    }
                }
            });
        });

        k();
    }
};
})()) /*jshint -W033 */ // no semi; this is an expression not a statement
