(function() {
function _oneSlide(d3) {

var oneSlide = {};

var makeSVG = function(id){
 var svg = d3.select("#"+id)
 .append("svg")
 .attr({"height": 465, "width": 750, "id": "slideChooser"});

 svg.append("rect")
 .attr({"x": 5, "y": 5, "rx": 10, "ry": 10, "width": 740, "height": 455})
 .attr("class", "background")

 svg.append("text")
 .text("Choose an IIP Slide")
 .attr({"x": 260, "y": 50}).attr("class", "title")

 svg.append("text")
 .text("Click on a slide to add it to your presentation")
 .attr({"x": 25, "y": 80}).attr("class", "guide")

 svg.append("text")
 .text("A Title Slide")
 .attr({"x": 55, "y": 115}).attr("class", "subtitle")

 svg.append("text")
 .text("A Text Slide")
 .attr({"x": 230, "y": 115}).attr("class", "subtitle")

 svg.append("text")
 .text("Text & Plot Slide")
 .attr({"x": 390, "y": 115}).attr("class", "subtitle")

 svg.append("text")
 .text("Shiny Slide")
 .attr({"x": 600, "y": 115}).attr("class", "subtitle")

 svg.append("text")
 .text("Edit Slide Text:")
 .attr({"x": 25, "y": 270}).attr("class", "subtitle")

 svg.append("text")
 .text("Click on the slide to remove it")
 .attr({"x": 25, "y": 440}).attr("class", "guide")

 svg.append("rect")
 .attr({"x": 25, "y": 280, "rx": 10, "ry": 10, "width": 200, "height": 140})
 .attr("class", "presentation");

 svg.append("svg:image")
 .attr({"x":600, "y":25, "width":100, "height":79, "xlink:href": "shared.R/rcloud.iip/img/rcloud_mid.png"})

  svg.append("rect").attr({"x":640, "y":230, "width":90, "height":45, "rx":5, "ry":5, "class":"buttonBox"});
  svg.append("text").attr({"x":660, "y":257, "class":"buttonBox"}).text("Cancel");
  svg.append("rect").attr({"x":640, "y":230, "width":90, "height":45, "rx":5, "ry":5, "fill-opacity":0, "id":"cancelBox"});

  svg.append("rect").attr({"x":480, "y":230, "width":140, "height":45, "rx":5, "ry":5, "class":"buttonBox"});
  svg.append("text").attr({"x":500, "y":257, "class":"buttonBox"}).text("Insert into Cell");
  svg.append("rect").attr({"x":480, "y":230, "width":140, "height":45, "rx":5, "ry":5, "fill-opacity":0, "id":"buttonBox"});

 return(svg);

};

var makeTitle = function(svg, x, y, id){

 id = "title" + id;
 var g = svg.append("svg").attr({"id": id, "height": 100, "width": 160, "x": x, "y": y})
 .attr("class", "slide titleSlide");

 g.append("rect").attr({"rx": 0, "ry": 0, "width": 160, "height": 100}).attr("class", "slide titleSlide")

 g.append("text").text("Title here")
 .attr("x", 20).attr("y", 20)
 .attr("class", "slideTitle")
 .attr("id", "slideTitle");

 g.append("text").text("Sub Title here")
 .attr("x", 20).attr("y", 30)
 .attr("class", "slideSubTitle")
 .attr("id", "slideSubTitle");

 g.append("text").text("Name here")
 .attr("x", 100).attr("y", 80)
 .attr("class", "slideName")
 .attr("id", "slideName");

 g.append("text").text("Date here")
 .attr("x", 100).attr("y", 90)
 .attr("class", "slideDate")
 .attr("id", "slideDate");
 return(g);
};

var makeText = function(svg, x, y, id){

  id = "text" + id;

  var g = svg.append("svg").attr({"id": id, "height": 100, "width": 160, "x": x, "y": y})
  .attr("class", "slide textSlide")

  g.append("rect").attr({"rx": 0, "ry": 0, "width": 160, "height": 100}).attr("class", "slide textSlide");

  g.append("text").text("Title Text")
  .attr({"x":15, "y":20, "class":"slideTitle", "id": "slideTitle"});

  textData = ["- Markdown text",
              "- Goes here"];

  for(i = 0; i <= textData.length; i++){
    g.append("text").text(textData[i]).attr({"x": 15, "y": 35 + (i * 10), "class": "slideText", "id":"slideText"+(i+1)});
  }
  return(g);
};

var makePlot = function(svg, x, y, id){
  id = "plot" + id;

  var g = svg.append("svg").attr({"id": id, "height": 100, "width": 160, "x": x, "y": y})
  .attr("class", "slide plotSlide")

  g.append("rect").attr({"rx": 0, "ry": 0, "width": 160, "height": 100}).attr("class", "slide plotSlide")

  g.append("text").text("Title Text")
  .attr({"x": 15, "y": 20, "class": "slideTitle", "id": "slideTitle"})

  var textData = ["- Markdown body text", "* Example bullet points", "* More bullet points"];

  var text = {};

  for(i = 0; i <= textData.length; i++){
    text[i] = g.append("text")
               .text(textData[i])
               .attr({"x": 15, "y": 35 + (i * 10), "class": "slideText", "id":"slideText"+(i+1)});
  }

  piChart = g.append("svg").attr({"x":90, "y":30, "height":40, "width":40, "id":"piChart"});
  piChart.append("circle").attr({"cx": 20, "cy": 20, "r": 20, "fill": "green"});
  var piOver180 = 0.0174532925199
  var arc1 = d3.svg.arc().innerRadius(0)
                         .outerRadius(20)
                         .startAngle(0)
                         .endAngle(60 * piOver180);
  var arc2 = d3.svg.arc().innerRadius(0)
                         .outerRadius(20)
                         .startAngle(60 * piOver180)
                         .endAngle(200 * piOver180);
  piChart.append("path").attr("d", arc1)
                        .attr("transform", "translate(20, 20)")
                        .attr("fill", "red");
  piChart.append("path").attr("d", arc2)
                        .attr("transform", "translate(20, 20)")
                        .attr("fill", "blue");
  //switchPlot(g, false, 500);
  return(g);
};

var switchPlot = function(slide, time){
  text = slide.text;
  var keys = Object.keys(text);
  piChart = slide.select("#piChart");
  var plotIsRight = piChart.attr("x") != 90;
  if(plotIsRight){
    piChart.transition()
           .duration(time)
           .ease("linear")
           .attr("x", 90);
  }else{
    piChart.transition()
           .duration(time)
           .ease("linear")
           .attr("x", 20);
  }
  var i = 0;
  selection = slide.select("#slideText"+(i+1));
  while(!selection.empty()){
    if(plotIsRight){
      selection.transition()
           .duration(time)
           .ease("linear")
           .attr("x", 15);
    }else{
      selection.transition()
           .duration(time)
           .ease("linear")
           .attr("x", 80);
    }
    i++;
    selection = slide.select("#slideText"+(i+1));
  }
};

var makeSlidy = function(svg, x, y, id, pointDat, pathDat){

  id = "slidy" + id;

 var g = svg.append("svg").attr({"id": id, "height": 100, "width": 160, "x": x, "y": y})
 .attr("class", "slide shinySlide")

 g.append("rect").attr({"rx": 0, "ry": 0, "width": 160, "height": 100}).attr("class", "slide shinySlide")

 g.append("text").text("Title Text")
 .attr({"x": 15, "y": 20})
 .attr("class", "slideTitle").attr("id", "slideTitle");

 // Axes
 g.append("line").attr({"x1": 20,"y1": 30,"x2": 20,"y2": 80}).attr("class", "shinyAxes")
 g.append("line").attr("x1", 20).attr("y1", 80).attr("x2", 120).attr("y2", 80).attr("class", "shinyAxes")

 // Slider
 g.append("line").attr("x1", 140).attr("y1", 40).attr("x2", 140).attr("y2", 60)
 .attr("class", "shinySlide");

 g.append("line")
 .attr("x1", 135).attr("y1", 42).attr("x2", 145).attr("y2", 42)
 .attr("id", "slider")
 .attr("class", "slidySlider shinySlide");

  // Points
  g.selectAll(".slidyPoint")
  .data(pointDat).enter()
  .append("circle")
  .attr({"r": 2, "class": "slidyPoint" + id})
  .attr('cx', function(d, i){return (i * 2) + 20;})
  .attr('cy', function(d){return d + 30;});

  lineFun = d3.svg.line()
  .x(function(d,i){return (i * 2) + 20;})
  .y(function(d,i){return  d + 30;})
  .interpolate("linear");

  g.append("path").attr("d", lineFun(pathDat[0]))

  .attr({"class": "slidyPath", "id": "smoother"});
  return(g);
};

var moveShiny = function(){

  var slider = d3.selectAll(".slidySlider");
  var startY = 42;
  var endY = 58;
  var startPath = 0;
  var endPath = 1;
  var startW = 10;
  var endW = 2;

  if(!slider.empty()){

  if(Math.max(slider.attr("y1")) == 58){
    startY = 58;
    endY = 42;
    startPath = 1;
    endPath = 0;
    startW = 2;
    endW = 10;
  }

  slider.attr({"y1": startY, "y2": startY})
   .transition()
   .duration(2000)
   .ease("linear")
   .attr({"y1": endY, "y2": endY});

  d3.selectAll(".slidyPath")
    .attr({"d": lineFun(pathDat[startPath]), "stroke-width": startW})
    .transition()
    .duration(2000)
    .ease("linear")
    .attr({"d": lineFun(pathDat[endPath]), "stroke-width": endW})
    .each("end", moveShiny);
  }
};

var popupInfo = function(url){
  newwindow = window.open(url,'name','height=200,width=150');
  if (window.focus){newwindow.focus();}
  return false;
};

var moveSlide = function(newSlide, x, y){
  newSlide.transition()
  .duration(250)
  .ease("linear")
  .attr({"x": x, "y": y});
};

var rearrangeSlides = function(){
  var keys = Object.keys(slideDeck);
  var delta = 660/(keys.length + 1);
  for(i = 0; i < keys.length; i++){
    var myX = delta + (delta * i) + 45 - 80;
    moveSlide(slideDeck[keys[i]], myX, 300);
  }
};

var makeNewTitle = function(svg, id){
  var newSlide = makeTitle(svg, 25, 120, id);
  slideDeck["title" + id] = newSlide;
  newSlide.on({"click":
  function(){
    clearDeck();
    newSlide.remove();
  }})
  moveSlide(newSlide, 45, 300);
  return(newSlide);
};

var makeNewText = function(svg, id){
  var newSlide = makeText(svg, 205, 120, id);
  slideDeck["text" + id] = newSlide;
  newSlide.on({"click":
  function(){
    clearDeck();
    newSlide.remove();
  }})
  moveSlide(newSlide, 45, 300);
  return(newSlide);
};

var makeNewPlot = function(svg, id){
  var newSlide = makePlot(svg, 385, 120, id);
  slideDeck["plot" + id] = newSlide;
  newSlide.on({"click":
  function(){
    clearDeck();
    newSlide.remove();
  }})
  moveSlide(newSlide, 45, 300);
  return(newSlide);
};

var makeNewSlidy = function(svg, id, pointDat, pathDat){
  var newSlide = makeSlidy(svg, 565, 120, id, pointDat, pathDat);
  slideDeck["slidy" + id] = newSlide;
  newSlide.on({"click":
  function(){
    clearDeck();
    newSlide.remove();
  }})
  moveSlide(newSlide, 45, 300);
  return(newSlide);
};

function clearDeck(){
  var keys = Object.keys(slideDeck);
  for(i = 0; i < keys.length; i++){
    slideDeck[keys[i]].remove();
    d3.select("#Entry").remove();
  }
  oneSlide.slideDeck = slideDeck = {};
}

function addInput(svg, x, y, id, slideTextId, slideId, placeHold){
  svg.append("foreignObject")
     .attr("class", "externalObject")
     .attr({"x":x,"y":y,"height":25,"width":250})
     .append("xhtml:div")
     .append('input')
     .attr('type', 'text')
     .attr('id', id)
     .attr('placeholder', placeHold)
     .on('change', function() {
        update(slideTextId, id, slideId);
     });
     //.html("<input type='text' id=" + id + " placeholder='" + placeHold + "' onchange=update('" + slideTextId + "','" + id + "','" + slideId + "')></input>");
}

function onBlur(textArea){
  if(textArea.value == ''){
    textArea.value = textArea.placeholder;
  }
}

function onFocus(textArea){
  if(textArea.value == textArea.placeholder){
    textArea.value = '';
  }
}

function addTextArea(svg, x, y, id, slideTextId, slideId, placeHold){
  svg.append("foreignObject")
     .attr("class", "externalObject")
     .attr({"x":x,"y":y,"height":100,"width":450})
     .append("xhtml:div")
     .append('textarea')
     .attr('rows', 5)
     .attr('cols', 50)
     .classed('guide', true)
     .attr('id', id)
     .attr('placeholder', placeHold)
     .on('change', function() {
         update(slideTextId, id, slideId);
     })
     .on('blur', function() {
         onBlur(this);
     })
     .on('focus', function() {
         onFocus(this);
     });
     // .html("<textarea rows='5' class='guide' cols='50' id=" + id + " placeholder='"+placeHold+"' onchange=update('" + slideTextId + "','" + id + "','" + slideId + "') onblur=onBlur(this) onfocus=onFocus(this)>" + placeHold + "</textarea>");
}

function makeTitleEntry(svg, newS){
  var newSid = newS.attr("id");
  var g = svg.append("svg").attr({"id":"Entry", "x":210, "y":280, "width":500, "height":200})
  g.append("text").text("Title:").attr({"x":25, "y":25, "class":"guide"});
  addInput(g, 120, 15, "titleTitle", "slideTitle", newSid, "Title here");
  g.append("text").text("Subtitle:").attr({"x":25, "y":55, "class":"guide"});
  addInput(g, 120, 45, "titleSubtitle", "slideSubTitle", newSid, "Sub-title here");
  g.append("text").text("Presenters:").attr({"x":25, "y":85, "class":"guide"});
  addInput(g, 120, 75, "titleName", "slideName", newSid, "Name here");
  g.append("text").text("Date:").attr({"x":25, "y":115, "class":"guide"});
  addInput(g, 120, 105, "titleDate", "slideDate", newSid, "Date here");
  return(g);
}

function makeTextEntry(svg, newS){
  var newSid = newS.attr("id");
  var g = svg.append("svg").attr({"id":"Entry", "x":210, "y":280, "width":500, "height":200})
  g.append("text").text("Title:").attr({"x":25, "y":25, "class":"guide"});
  addInput(g, 120, 15, "titleTitle", "slideTitle", newSid, "Enter a title");
  g.append("text").text("Text:").attr({"x":25, "y":55, "class":"guide"});
  addTextArea(g, 120, 45, "titleText", "slideText", newSid, "Enter the slide text");
  return(g);
}

function makePlotEntry(svg, newS){
  var newSid = newS.attr("id");
  var g = svg.append("svg").attr({"id":"Entry", "x":210, "y":280, "width":500, "height":200})
  g.append("text").text("Title:").attr({"x":25, "y":25, "class":"guide"});
  addInput(g, 120, 15, "titleTitle", "slideTitle", newSid, "Enter a title");
  g.append("text").text("Text:").attr({"x":25, "y":55, "class":"guide"});
  addTextArea(g, 120, 45, "titleText", "slideText", newSid, "Enter the slide text");
  g.append("text").text("Add R code for the Plot where noted in the cell").attr({"x":125, "y":150, "class":"guide"})
  g.append("rect").attr({"x":320, "y":10, "width":110, "height":25, "rx":5, "ry":5, "class":"buttonBox"});
  g.append("text").text("Switch plot side").attr({"x":324, "y":27, "class":"buttonBox"});
  var button = g.append("rect").attr({"x":320, "y":10, "width":110, "height":25, "rx":5, "ry":5, "fill-opacity":0, "id":"switchPlot"});
  button.on("click", function(){switchPlot(newS, 250);});
  return(g);
}

function makeShinyEntry(svg, newS){
  var newSid = newS.attr("id");
  var g = svg.append("svg").attr({"id":"Entry", "x":210, "y":280, "width":500, "height":200})
  g.append("text").text("Title:").attr({"x":25, "y":25, "class":"guide"});
  addInput(g, 120, 15, "titleTitle", "slideTitle", newSid, "Enter a title");
  return(g);
}

function update(id, entryId, slideId) {
  var text = $("#" + entryId).val().split("\n");
  var slide = d3.select("#"+slideId);
  var selection = slide.select("#"+id);

  if(!selection.empty()){
    selection.text(text[0]);
  }else{
    var i = 1;
    var x = 0;
    var y = 0;
    var delta = 0;
    var cls = "";
    selection = slide.select("#"+id+i);
    while(!selection.empty()){
      x = selection.attr("x");
      y = selection.attr("y");
      cls = selection.attr("class");
      if(i == 2){
        delta = selection.attr("y") - x;
      }
      if(i <= text.length){
        selection.text(text[i-1]);
      }else{
        selection.remove();
      }
      i++;
      selection = slide.select("#"+id+i);
    }
    for(i; i <= text.length; i++){
      y = y + delta;
      slide.append("text").text(text[i-1]).attr({"x":x,"y":y,"class":cls, "id":id+i});
    }
  }
}

var ExtractInfo = function(){
	var keys = Object.keys(slideDeck);
	if(keys.length > 0){
	  var cls = d3.select("#"+keys[0]).attr("class");

	  if(cls == "slide titleSlide"){
		  var title = d3.select("#"+keys[0]).select("#slideTitle").text();
		  var subtitle = d3.select("#"+keys[0]).select("#slideSubTitle").text();
		  var date = d3.select("#"+keys[0]).select("#slideDate").text();
		  var name = d3.select("#"+keys[0]).select("#slideName").text();
	  }

	  if(cls == "slide textSlide"){
		  var title = d3.select("#"+keys[0]).select("#slideTitle").text();
		  var i = 1;
		  var text = [];
		  while(!d3.select("#"+keys[0]).select("#slideText"+i).empty()){
  		  text[i-1] = d3.select("#"+keys[0]).select("#slideText"+i).text();
		    i++;
		  }
	  }

	  if(cls == "slide plotSlide"){
		  var title = d3.select("#"+keys[0]).select("#slideTitle").text();
		  var text = [];
		  var i = 1;
		  while(!d3.select("#"+keys[0]).select("#slideText"+i).empty()){
  		  text[i - 1] = d3.select("#"+keys[0]).select("#slideText"+i).text();
		    i++;
		  }
      var plotSide = "right";
      if(d3.select("#"+keys[0]).select("#piChart").attr("x") == 20){
        plotSlide = "left";
      }
	  }

	  if(cls == "slide shinySlide"){
		  var title = d3.select("#"+keys[0]).select("#slideTitle").text();
	  }
  }
};


oneSlide.slideChooser = function(id){

  // The set up
  var svg = makeSVG(id);
  var titleX = makeTitle(svg, 25, 120, "X");
  var textX = makeText(svg, 205, 120, "X");
  var plotX = makePlot(svg, 385, 120, "X");
  var slidyX = makeSlidy(svg, 565, 120, "X", pointDat, pathDat);

  moveShiny();

  // Add event listners
  titleX.on({"click": function(){clearDeck(); newS = makeNewTitle(svg, Object.keys(slideDeck).length + 1); makeTitleEntry(svg, newS);}});
  textX.on({"click": function(){clearDeck(); newS = makeNewText(svg, Object.keys(slideDeck).length + 1); makeTextEntry(svg, newS);}});
  plotX.on({"click": function(){clearDeck(); newS = makeNewPlot(svg, Object.keys(slideDeck).length + 1); makePlotEntry(svg, newS);}});
  slidyX.on({"click": function(){clearDeck(); newS = makeNewSlidy(svg, Object.keys(slideDeck).length + 1, pointDat, pathDat); makeShinyEntry(svg, newS);}});
}

  // Container for information
  var slideDeck = {};
  oneSlide.slideDeck = slideDeck;

  // Path data
  var pathDat = [[20.75930, 21.00763, 21.25691, 21.50666, 21.75632, 22.00551, 22.25378, 22.50061, 22.74514,
     22.98647, 23.22388, 23.45688, 23.68497, 23.90796, 24.12614, 24.34011, 24.55065, 24.75889,
     24.96681, 25.17689, 25.39192, 25.61538, 25.85257, 26.11044, 26.39619, 26.60092, 26.67624,
     26.73875, 26.80054, 26.86437, 26.92965, 26.99492, 27.05872, 27.11970, 27.17694, 27.22965,
     27.27757, 27.32100, 27.36043, 27.39612, 27.42864, 27.45845, 27.48556, 27.50966, 27.53063,
     27.54806, 27.56157, 27.57115, 27.57725, 27.58067],
     [25.91777, 24.19974, 22.94173, 21.25086, 21.57925, 25.44635, 25.17197, 21.89545, 18.18239,
     16.31765, 14.67656, 14.67849, 15.03485, 18.99154, 22.50103, 24.46479, 28.39425, 33.02901,
     38.76965, 38.86833, 38.45712, 33.47370, 26.28097, 18.60747, 14.73747, 18.77383, 27.85605,
     32.76849, 35.00093, 35.15316, 34.26539, 32.49318, 30.68211, 24.09123, 18.56433, 15.89057,
     17.99152, 20.42408, 26.92201, 31.30576, 39.26663, 42.56280, 41.33118, 34.64393, 28.61673,
     19.91605, 16.76187, 23.55440, 29.66416, 36.67711]]

  var pointDat = [21, 34, 23,  8, 28, 20, 38, 22, 12, 11, 31,  7, 10, 18, 32, 25, 6, 39, 44, 45, 15, 47, 35, 2, 3, 26, 24,
     42, 33, 37, 30, 43, 19, 41, 14, 4, 17, 46, 1, 29, 49, 48, 9, 50, 27, 13, 16, 5, 40, 36]
return oneSlide;
}

define(["d3"], _oneSlide);
}
)();
