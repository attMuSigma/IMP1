//var nTotalCells=0;

function disableResetHref() {
  $("a").click(function(event){
    event.preventDefault();
    event.stopPropagation();
});
}

// Doug's slide copy funtion
function slide_extract() {

    setTimeout(function() {
    // Find all of the slide divs and copy them to the body
    //    $("div.slide").removeClass("r-result-div");

        $("div.slide").prependTo($("div#slideDeck"))
    

    //    for (var i=0; i<slideDivs.length;i++) {
    //        $("div#output").before(slideDivs[i]);
    //    }

        // Remove the native rcloud output
        $("div#output").remove()

        // Kick off the slidy init
        w3c_slidy.init();
    //    w3c_slidy.goto(0);

        // Weird glitch that added CSS tags to some of the slides, remove height styling.
        $("div.slide").css({height: ''});


        w3c_slidy.first_slide();
   
        // Fix a conflict between dc.js and slidy.js
        // Setting a timeout is *not* how I want to do it. We need to listen for all the dc events somehow.
        // Alternatively we can build it in slidy.js to do this every time you change slides or something.
        disableResetHref();
        console.log("Removed href from a.reset. Fast");
        setTimeout(function(){ disableResetHref(); console.log("Removed href from a.reset. Medium"); }, 5000);
        setTimeout(function(){ disableResetHref(); console.log("Removed href from a.reset. Slow"); }, 15000);  

        
    }, 500);
   

}

function main() {
    Promise.longStackTraces();

    function getURLParameter(name) {
        return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search)||[,""])[1].replace(/\+/g, '%20'))||null;
    }

    RCloud.UI.init();
    RCloud.session.init(true).then(function() {
        shell.init();
        RCloud.UI.advanced_menu.load('view');
        var notebook = getURLParameter("notebook"),
            version = getURLParameter("version"),
            quiet = getURLParameter("quiet");

        var promise = Promise.resolve(true);
        if (Number(quiet)) {
            promise = promise.then(function() {
                $(".navbar").hide();
                $("body").css("padding-top", "0");
                rcloud.api.disable_echo();
            });
        }
        if (notebook === null && getURLParameter("user")) {
            promise = promise.then(function() {
                return rcloud.get_notebook_by_name(getURLParameter("path"), getURLParameter("user"));
            }).then(function(result) {
                notebook = result[0];
            });
        }
        var tag = getURLParameter("tag");
        if(!version && tag) {
            promise = promise.then(function() {
                return rcloud.get_version_by_tag(notebook, tag)
                    .then(function(v) {
                        version = v;
                    });
            });
        };
        promise = promise.then(function() {
            return shell.load_notebook(notebook, version).then(
                function(result) {
                    document.title = result.description + " - RCloud";
                }
            );
        }).then(function() {
            //if (Number(quiet)) {
                $("#output > pre").first().hide();
            //}
            rcloud.install_notebook_stylesheets().then(function() {
                shell.notebook.controller.run_all().then(function() {
                    shell.notebook.controller.hide_r_source();
                }).then(function() {
                    nTotalCells = shell.notebook.model.cells.length;
                    slide_extract();
                    //alert(nTotalCells);
                });
                _.each(shell.notebook.view.sub_views, function(cell_view) {
                    cell_view.hide_buttons();
                });
            });
        });
        return promise;
    }).catch(function(err) {
        console.log(err.stack);
        RCloud.UI.session_pane.post_error(ui_utils.disconnection_error("Could not load notebook. You may need to login to see it.", "Login"));
    });
}
