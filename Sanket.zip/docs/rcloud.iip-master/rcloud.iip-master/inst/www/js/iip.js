(function() {
function _iip(d3, oneSlide) {

var iip = {};


function iipRemoveHeader(cellText) {
    // Remove iip header if present and cell title if present
    textLine = cellText.split('\n');
    textOut = ''
    var i;
    
    dashLines = [];
    outputLines = [];
    hashLines = [];

    // Record all the line numbers we're interested in
    for (i=0; i<textLine.length; i++) {
        lineWord = textLine[i].split(' ');

        if (lineWord[0]=="---") {
            dashLines.push(i);
        }
        
        if (lineWord[0]=="output:") {
            outputLines.push(i);
        }
        
        if (lineWord[0]=="#") {
            hashLines.push(i);
        }
    }

    var headStart = textLine.length + 1;
    var headStop = -1;

    if (dashLines.length>1 && outputLines > 0) {
        if (outputLines[0] > dashLines[0] && outputLines[0] < dashLines[1]) {
            // If we get here we've got a yaml header
           headStart = dashLines[0];
           headStop = dashLines[1];
           // Look for the title
           if (hashLines.length > 0) {
               if (hashLines[0] == headStop + 1) {
                   headStop ++;
               }
           }
        }
    }

    for (i=0; i<textLine.length; i++) {
        if (i > headStop || i < headStart) {
            // Backwards compatible, strip old iip headers
            lineWord = textLine[i].split(' ');
            if (lineWord[0] != "%iip:") {
                textOut += textLine[i] + '\n';
            }
        }
    }

    return(textOut);
}

function iipCancel(){
   $("#iipslidechooser").css("display", "none");
   $("#iipblackout").css("display", "none");
   d3.select("#slideChooser").remove();
}

function iipDone1(id) {
   
  // Switch off the iip wizard
  $("#iipslidechooser").css("display", "none");
  $("#iipblackout").css("display", "none");

  // Add the new code, rather than deleting old code.
  var oldContent = iipRemoveHeader(id.content());

  var keys = Object.keys(oneSlide.slideDeck);

  if(keys.length > 0){

    var cls = d3.select("#"+keys[0]).attr("class");
    var stuff = '';

    var metadata = {output: 'rcloud.iip:::iip_slide'};

    switch(cls){
	  case "slide titleSlide":
            metadata.classes = 'slide titlepage';
	    stuff += '# ' + d3.select("#"+keys[0]).select("#slideTitle").text() + '\n';
	    stuff += '## ' + d3.select("#"+keys[0]).select("#slideSubTitle").text() + '\n';
	    stuff += d3.select("#"+keys[0]).select("#slideName").text() + '\n\n';
	    stuff += 'date: ' + d3.select("#"+keys[0]).select("#slideDate").text() + '\n';
            stuff += "\n" + oldContent;
	    break;

	  case "slide plotSlide":
            metadata.classes = 'slide section level1';
	    var title = '# ' + d3.select("#"+keys[0]).select("#slideTitle").text() + '\n';
            stuff += title + '\n';

            var Rstuff = '\n```{r echo=FALSE}\n';
            Rstuff += '# R plot code goes here\n';
            Rstuff += oldContent + '\n';
            Rstuff += '```\n';

            var Tstuff = '';
            var i = 1;
            while(!d3.select("#"+keys[0]).select("#slideText"+i).empty()){
              Tstuff += d3.select("#"+keys[0]).select("#slideText"+i).text() + '\n';
              i++;
            }
            var plotLeft = d3.select("#"+keys[0]).select("#piChart").attr("x") != 90;
            if(plotLeft){
              stuff += Rstuff + '\n---\n' + Tstuff;
              metadata.width = "58%";
            }else{
              stuff += Tstuff + '\n---\n' + Rstuff;
              metadata.width = "42%";
            }


            break;
	  case "slide textSlide":
	  case "slide shinySlide":
            metadata.classes = 'slide section level1';
	    var title = '# ' + d3.select("#"+keys[0]).select("#slideTitle").text() + '\n';
            stuff += title + '\n';
            var i = 1;
	    while(!d3.select("#"+keys[0]).select("#slideText"+i).empty()){
              stuff += d3.select("#"+keys[0]).select("#slideText"+i).text() + '\n';
              i++;
	    }
            stuff += "\n" + oldContent;
	    break;

      default:
	    alert("Unsupported slideType:" + cls);
	    break;
     }


   }
   var header = '---\n';
   for(var attr in metadata)
       header += attr + ': ' + metadata[attr] + '\n';
   header += '---\n';
   stuff = header + stuff;

   d3.select("#slideChooser").remove();

    // save the cell and change its language if necessary
    var promise;
    if(id.language()!=="RMarkdown")
        promise = shell.notebook.controller.change_cell_language(id, "RMarkdown");
    else
        promise = shell.notebook.controller.update_cell(id); // pick up any unsaved changes to cell


    return promise.then(function() {

        id.content(stuff);

        return shell.notebook.controller.update_cell(id);
    });
};

iip.launchIIPWizard = function(cell_model) {
   // Open up the IIP Wizard and return content to the cell

    if($("#iipblackout").empty()) {
        $('body').prepend('<div id="iipblackout"></div><div id="iipslidechooser"></div>');
    }

    var wWidth = $(window).width();
    var wHeight = $(window).height();
    $("#iipblackout").css("display", "block");
    $("#iipslidechooser").css("display", "block");
    var dWidth = $("#iipslidechooser").width();
    var dHeight = $("#iipslidechooser").height();
    if(d3.select('#slideChooser').empty()){
      oneSlide.slideChooser("iipslidechooser");
    }
    d3.select("#buttonBox").on({"click": function(){iipDone1(cell_model);}});
    d3.select("#cancelBox").on({"click": function(){iipCancel();}});
}

return iip;
}

define(["d3", "oneSlide"], _iip);
}
)();
