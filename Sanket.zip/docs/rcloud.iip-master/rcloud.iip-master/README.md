# Internal Insight Publisher (IIP)

rcloud.iip is an extension to RCloud that allows users to convert Noteboooks to slideshow presentations that can be shared. The presentations are based on the <a href="http://www.w3.org/Talks/Tools/Slidy2">Slidy javascript library</a> with additional Markdown syntax to create bootstrap compatible layouts.

## Installation

Clone this repository into your rcloud.packages directory and include the package name in your rcloud.conf file: e.g.

```
rcs.system.config.addons: rcloud.viewer, rcloud.enviewer, rcloud.notebook.info, rcloud.iip
```

The rebuild the packages and restart Rserve.

## Creating Slides

To create a slide cell, click the IIP Wizard button (currently a lightning bolt) on the cell toolbar. This will bring up the IIP wizard. Select the type of slide you would like and fill in the title and other information. On clicking "Insert into Cell" the correct IIP code will be inserted and the cell language changed to RMarkdown.

A basic slide must contain the following yaml header:

```
---
output: rcloud.iip:::iip_slide
classes: slide section level1
---
```

where the slide class must always be there. For a title page use `classes: slide titlepage`. Executing the cell will return a rendered slide with the default background images.

## View mode

To view the slideshow click on the arrow next to the shareable link button at the top left and select `viewiip.html`. Clicking on the shareable link button will open the slide deck in view mode. Only slides with the correct yaml header will be displayed, but all cells will be executed. So if you have R cells to load libraries and run code they will essentially run in the backgroun.
