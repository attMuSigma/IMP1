#include <fst/arc.h>
#include <fst/closure.h>
#include <fst/compose.h>
#include <fst/fst.h>
#include <fst/mutable-fst.h>
#include <fst/intersect.h>
#include <fst/rational.h>
#include <fst/shortest-path.h>
#include <fst/topsort.h>
#include <fst/union.h>
#include <fst/vector-fst.h>
#include <iostream>
#include <list>
#include <map>
#include <string>
#include <vector>

using namespace std;
using namespace fst;

vector<string> split(string str, char delimiter) {
	vector<string> internal;
	stringstream ss(str); // Turn the string into a stream.
	string tok;

	while (getline(ss, tok, delimiter)) {
		internal.push_back(tok);
	}

	return internal;
}

//yet to complete
void checkInputs(char* argv[]) {
	//	for (int x = 1; x < 4; ++x) {
	//		string temp = argv[x];
	//		if (temp.find("-farfile") != std::string::npos) {
	//			vector<string> farFileVector = split(temp, '=');
	//			farFileInput = farFileVector[1];
	//		} else if (temp.find("-policies") != std::string::npos) {
	//			vector<string> policiesVector = split(temp, '=');
	//			policiesInput = policiesVector[1];
	//		} else if (temp.find("-symbols") != std::string::npos) {
	//			vector<string> symbolsVector = split(temp, '=');
	//			symbolsInputPath = symbolsVector[1];
	//		}
	//	}

}
//yet to implment
void printTheString(string text, string text2) {

}

int main(int argc, char* argv[]) {

	//	cout << "print argv first " << argv[1] << endl;
	//	cout << "print argv second " << argv[2] << endl;
	//	cout << "print argv third " << argv[3] << endl;

	string farFileInput;
	string policiesInput; // = "input string for policies";
	string symbolsInputPath;

	//move below loop to checkInputs function and call
	for (int x = 1; x < 4; ++x) {
		string temp = argv[x];
		if (temp.find("-farfile") != std::string::npos) {
			vector<string> farFileVector = split(temp, '=');
			farFileInput = farFileVector[1];
		} else if (temp.find("-policies") != std::string::npos) {
			vector<string> policiesVector = split(temp, '=');
			policiesInput = policiesVector[1];
		} else if (temp.find("-symbols") != std::string::npos) {
			vector<string> symbolsVector = split(temp, '=');
			symbolsInputPath = symbolsVector[1];
		}
	}
	vector<string> policiesVector = split(policiesInput, ',');

	//move to print the string
	cout << "Path of far/fst folder = " << farFileInput << endl
			<< "Number of Policies = " << policiesVector.size() << endl
			<< "Policies entered = " << policiesInput << endl
			<< "Symbols File Path = " << symbolsInputPath << endl;
	cout << "Output :" << endl;

	string str;
	getline(cin, str);

	map<string, int> symbols;
	map<int, string> rev_symbols;
	string line;
	ifstream file(symbolsInputPath);
	while (getline(file, line)) {
		istringstream tokens(line);
		string k;
		int v;
		tokens >> k;
		tokens >> v;
		symbols[k] = v;
		rev_symbols[v] = k;
	}

	StdVectorFst input;
	input.AddState();
	input.SetStart(0);

	int s = 0;
	int e = 1;
	for (string::size_type i = 0; i < str.size(); ++i, ++s, ++e) {
		string k;
		if (str[i] == ' ')
			k = "<space>";
		else if (str[i] == '\n')
			k = "<newline>";
		else
			k = str[i];

		input.AddState();
		input.AddArc(s, StdArc(symbols[k], symbols[k], 0, e));
	}

	//fst.AddState();
	input.SetFinal(str.length(), 0);

	//testing - uncomment it
	input.Write("fst/input.fst");

	//mutable fst
	string pathToModel1 = farFileInput + "/" + policiesVector[0] + ".fst";
	static MutableFst<StdArc> *model1 = fst::MutableFst<StdArc>::Read(
			pathToModel1);

	//	string pathToModel2 = farFileInput + "/" + policiesVector[1] + ".fst";
	//	StdVectorFst *model2; // = StdVectorFst::Read(pathToModel2);

	//commented as the functionality is not used
	//	std::unique_ptr<StdVectorFst> modelManager(model2);
	//    ArcSort(&input, StdOLabelCompare());
	//    ArcSort(model, StdILabelCompare());

	StdVectorFst result;

	for (int y = 1; y < policiesVector.size(); ++y) {
		string pathToModel2 = farFileInput + "/" + policiesVector[y] + ".fst";
		StdVectorFst* listStdVectorFst[policiesVector.size() - 1];
		listStdVectorFst[y]= {StdVectorFst::Read(pathToModel2)};
		StdVectorFst *model2;
		model2 = listStdVectorFst[y];

//		Intersect(*model2, *model1, &result);

		Union(model1, *model2);
	}

	////testing multiple unions. must create an iterator and comment this
	//
	//	if (policiesVector.size() == 3) {
	//		string pathToModel3 = farFileInput + "/" + policiesVector[2] + ".fst";
	//		StdVectorFst *model3 = StdVectorFst::Read(pathToModel3);
	//		Union(model1, *model3);
	//	} else if (policiesVector.size() == 4) {
	//		string pathToModel4 = farFileInput + "/" + policiesVector[3] + ".fst";
	//		StdVectorFst *model4 = StdVectorFst::Read(pathToModel4);
	//		Union(model1, *model4);
	//	} else if (policiesVector.size() == 5) {
	//		string pathToModel5 = farFileInput + "/" + policiesVector[4] + ".fst";
	//		StdVectorFst *model5 = StdVectorFst::Read(pathToModel5);
	//		Union(model1, *model5);
	//	} else if (policiesVector.size() == 6) {
	//		string pathToModel6 = farFileInput + "/" + policiesVector[5] + ".fst";
	//		StdVectorFst *model6 = StdVectorFst::Read(pathToModel6);
	//		Union(model1, *model6);
	//	}

	Closure(model1, CLOSURE_STAR);

	//testend

	Compose(input, *model1, &result);

	//    Project(&result, PROJECT_OUTPUT);

	StdVectorFst result2;
	ShortestPath(result, &result2, 1);
	TopSort(&result2);

	result2.Write("fst/output.fst");

	for (StateIterator<StdFst> siter(result2); !siter.Done(); siter.Next()) {
		int state_id = siter.Value();
		for (ArcIterator<StdFst> aiter(result2, state_id); !aiter.Done();
				aiter.Next()) {
			const StdArc &arc = aiter.Value();
			int ol = arc.olabel;
			string s = rev_symbols[ol];
			if (s == "<epsilon>")
				s = "";
			else if (s == "<space>")
				s = " ";
			else if (s == "<newline>")
				s = "\n";

			cout << s;
		}
	}
	cout << "\n";
	return 0;
}
