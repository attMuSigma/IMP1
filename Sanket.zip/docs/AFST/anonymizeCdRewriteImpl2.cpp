#include <fst/arc.h>
#include <fst/arcsort.h>
#include <fst/compose.h>
#include <fst/extensions/far/far.h>
#include <fst/fst.h>
#include <fst/mutable-fst.h>
#include <fst/shortest-path.h>
#include <fst/symbol-table.h>
#include <fst/topsort.h>
#include <fst/vector-fst.h>
#include <iostream>
#include <string>
#include <vector>
#include <thrax/cdrewrite.h>

/***
 *
 *Checks for the input parameters like far file path, symbols file path , policies. reads the far file checks for the fst's in the far file and compares with the input *policies. masks the text and prints the output
 *
 *PS: Code cleaning and modularization is in progress
 *
 */

using namespace std;
using namespace fst;

SymbolTable *syms;

vector<string> split(string str, char delimiter) {
	vector<string> internal;
	stringstream ss(str); // Turn the string into a stream.
	string tok;

	while (getline(ss, tok, delimiter)) {
		internal.push_back(tok);
	}

	return internal;
}

//reAd input text and create input fst implementation
void createInputFst(char* argv[]) {

	//handle input and create input fst
	//should transfer the code from main to here

}
//yet to implment
void printTheString(const char text, ...) {

	//will handle the printing of the logs
	//should transfer the code from main to here

}

//this function is not yet called.
void printOutputString(StdVectorFst result2) {
	for (StateIterator<StdFst> siter(result2); !siter.Done(); siter.Next()) {
		int state_id = siter.Value();
		for (ArcIterator<StdFst> aiter(result2, state_id); !aiter.Done();
				aiter.Next()) {
			const StdArc &arc = aiter.Value();
			int ol = arc.olabel;
			//			string s = rev_symbols[ol];
			string s = syms->Find(arc.olabel);
			if (s == "<epsilon>")
				s = "";
			else if (s == "<space>")
				s = " ";
			else if (s == "<newline>")
				s = "\n";

			cout << s;
		}
	}
	cout << "\n";
}
//yet to complete
void makeModel() {
	//this function will have the model manipulation
	//should transfer the code from main to here

}
//yet to complete
void farRead() {

	//will handle the far read operations
	//should transfer the code from main to here

}

int main(int argc, char* argv[]) {

	string farFileInput;
	string policiesInput; // = "input string for policies";
	string symbolsFilePath;

	//move below loop to checkInputs function and call it
	for (int x = 1; x < 4; ++x) {
		string temp = argv[x];
		if (temp.find("-farfile") != std::string::npos) {
			vector<string> farFileVector = split(temp, '=');
			farFileInput = farFileVector[1];
		} else if (temp.find("-policies") != std::string::npos) {
			vector<string> policiesVector = split(temp, '=');
			policiesInput = policiesVector[1];
		} else if (temp.find("-symbols") != std::string::npos) {
			vector<string> symbolsVector = split(temp, '=');
			symbolsFilePath = symbolsVector[1];
		}
	}
	vector<string> policiesVector = split(policiesInput, ',');

	vector<string> farFilesVector = split(farFileInput, ',');

	//move to print the string
	cout << "Number of Far files = " << farFilesVector.size() << endl
			<< "Number of Policies = " << policiesVector.size() << endl
			<< "Policies entered = " << policiesInput << endl
			<< "Symbols File Path = " << symbolsFilePath << endl;

	//below statements to be moved to createinputfst function
	//change and clean the below code(implemented symbol table)
	string str;
	getline(cin, str);
	string line;
	ifstream file(symbolsFilePath);
	while (getline(file, line)) {
		istringstream tokens(line);
		string k;
		int v;
		tokens >> k;
		tokens >> v;
	}
	syms = SymbolTable::ReadText(symbolsFilePath);
	StdVectorFst input;
	input.AddState();
	input.SetStart(0);
	//
	int s = 0;
	int e = 1;
	for (string::size_type i = 0; i < str.size(); ++i, ++s, ++e) {
		string k;
		if (str[i] == ' ')
			k = "<space>";
		else if (str[i] == '\n')
			k = "<newline>";
		else
			k = str[i];

		input.AddState();
		input.AddArc(s, StdArc(syms->Find(k), syms->Find(k), 0, e));

	}

	input.SetInputSymbols(syms);
	input.SetOutputSymbols(syms);

	input.SetFinal(str.length(), 0);

	input.Write("fst/input.fst");

	//farread operations block to be moved to farRead function

	string firstFarFilename = farFilesVector[0];
	FarReader<StdArc> *firstFar_reader = FarReader<StdArc>::Open(
			firstFarFilename);

	if (!firstFar_reader) {
		cout << "First Far File Path: " << firstFarFilename;
		cout << "Unable to read First far file ... \n";
		return 1;
	}

	//model manipulations will be moved to the make model method

	StdVectorFst* firstFst;

	for (int i = 1; !firstFar_reader->Done(); firstFar_reader->Next(), ++i) {
		string key = firstFar_reader->GetKey();
		for (int y = 0; y < policiesVector.size(); ++y) {

			if (policiesVector[y] == key) {
				const Fst<StdArc> &fst1 = firstFar_reader->GetFst();
				firstFst = (StdVectorFst*) &fst1;
			}
		}
	}

	StdVectorFst result;
	result.SetInputSymbols(syms);
	result.SetOutputSymbols(syms);
	firstFst->SetInputSymbols(syms);
	firstFst->SetOutputSymbols(syms);
	ArcSort(&input, StdOLabelCompare());

	ArcSort(firstFst, StdILabelCompare());

//	Compose(input, *firstFst, &result);

	for (int y = 1; y < farFilesVector.size(); ++y) {
		string farFilename = farFilesVector[y];
		FarReader<StdArc> *far_reader = FarReader<StdArc>::Open(farFilename);

		if (!far_reader) {
			cout << "File Path: " << firstFarFilename;
			cout << "Unable to read far file ... \n";
			return 1;
		}

		for (int i = 1; !far_reader->Done(); far_reader->Next(), ++i) {
			string key = far_reader->GetKey();
			for (int y = 0; y < policiesVector.size(); ++y) {

				if (policiesVector[y] == key) {
					const Fst<StdArc> &fst3 = far_reader->GetFst();

					StdVectorFst* modelFst = (StdVectorFst*) &fst3;

					modelFst->SetInputSymbols(syms);
					modelFst->SetOutputSymbols(syms);

					Union(firstFst, *modelFst);

//					Compose(result, *modelFst, &result);

				}

			}

		}

	}
	StdVectorFst* emptyFstTemp = StdVectorFst::Read("fst/empty.fst");
	StdVectorFst* sigmaStarFstTemp = StdVectorFst::Read("fst/sigma_star.fst");

	(*sigmaStarFstTemp).SetInputSymbols(syms);
	(*sigmaStarFstTemp).SetOutputSymbols(syms);

	(*emptyFstTemp).SetInputSymbols(syms);
	(*emptyFstTemp).SetOutputSymbols(syms);

	(*firstFst).SetInputSymbols(syms);
	(*firstFst).SetOutputSymbols(syms);

	const Fst<StdArc> &emptyFst = *(Fst<StdArc>*) emptyFstTemp;
	const Fst<StdArc> &sigmaStarFst = *(Fst<StdArc>*) sigmaStarFstTemp;
	static Fst<StdArc> &output = *(Fst<StdArc>*) emptyFstTemp;
	const Fst<StdArc> &cDRewriteFst = *(Fst<StdArc>*) firstFst;

	cout << "Doing CD Rewrite \n";

	ContextDependentRewriteCompile(cDRewriteFst, emptyFst, emptyFst,
			sigmaStarFst, (MutableFst<StdArc>*) &output, SIMULTANEOUS,
			OBLIGATORY);

	cout << "CD Rewrite Done \n";

	Compose(input, output, &result);

	StdVectorFst result2;
	ShortestPath(result, &result2, 1);
	TopSort(&result2);
	cout << "Output :" << endl;

	result2.Write("fst/output.fst");

	//implementation to be removed and moved to printOutputString

	for (StateIterator<StdFst> siter(result2); !siter.Done(); siter.Next()) {
		int state_id = siter.Value();
		for (ArcIterator<StdFst> aiter(result2, state_id); !aiter.Done();
				aiter.Next()) {
			const StdArc &arc = aiter.Value();
			int ol = arc.olabel;
			//			string s = rev_symbols[ol];
			string s = syms->Find(arc.olabel);
			if (s == "<epsilon>")
				s = "";
			else if (s == "<space>")
				s = " ";
			else if (s == "<newline>")
				s = "\n";

			cout << s;
		}
	}
	cout << "\n";
	return 0;
}
